
import static org.junit.Assert.*;
import imkerapp.activities.AnmerkungActivity;
import imkerapp.database.Config;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import android.widget.EditText;

import com.example.imkerapp.R;

@RunWith (RobolectricTestRunner.class)
public class AnmerkungActivityTextfeldTest {
    
     AnmerkungActivity anmActivity;
     EditText textfeld;
    

    @Before
    public  void setUp() throws Exception {
        Config.getConfig().setBeutenId((long)20);
        
                
        anmActivity = Robolectric.buildActivity(AnmerkungActivity.class).create().get();
        textfeld = (EditText) anmActivity.findViewById(R.id.anmerkungTexte);

    }
    
    
    
    @Test
    public void Testtextfeld() {
        
        CharSequence text = "futter";
        
        textfeld.setText(text);
        
        assertEquals("futter", textfeld.getText().toString());

    }
    
    
    
    
}


