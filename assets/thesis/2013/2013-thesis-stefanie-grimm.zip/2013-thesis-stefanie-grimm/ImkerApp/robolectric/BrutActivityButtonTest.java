
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import imkerapp.activities.BrutActivity;
import imkerapp.activities.BrutHistorieActivity;
import imkerapp.database.Config;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.shadows.ShadowActivity;
import org.robolectric.shadows.ShadowIntent;

import android.content.Intent;
import android.widget.Button;
import com.example.imkerapp.R;

@RunWith (RobolectricTestRunner.class)
public class BrutActivityButtonTest {
    
     BrutActivity brutActivity;
     Button historie;
    

    @Before
    public  void setUp() throws Exception {
        Config.getConfig().setBeutenId((long)20);
        
                
        brutActivity = Robolectric.buildActivity(BrutActivity.class).create().get();
        historie = (Button) brutActivity.findViewById(R.id.Bruthistorie);

    }
    
    
    
    @Test
    public void pressButton() {
        
        // Klick auf Button
        historie.performClick();
        // AnmerkungActivity als shadow Instanz
        ShadowActivity shadowActivity = Robolectric.shadowOf(brutActivity);
        Intent startedIntent = shadowActivity.getNextStartedActivity();
        // n�chste Activity als shadow Instanz
        ShadowIntent shadowIntent = Robolectric.shadowOf(startedIntent);
        
        // Pr�fen, ob die gestartete Activity die richtige ist        
        assertThat(shadowIntent.getComponent().getClassName(), equalTo(BrutHistorieActivity.class.getName()));

    }
    
    
    
    
}

