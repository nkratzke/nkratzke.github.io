
import static org.junit.Assert.*;
import imkerapp.activities.AnmerkungActivity;
import imkerapp.activities.BrutActivity;
import imkerapp.database.Config;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import android.widget.EditText;

import com.example.imkerapp.R;

@RunWith (RobolectricTestRunner.class)
public class BrutActivityTextfeldEierTest {
    
     BrutActivity brutActivity;
     EditText textfeldEier;
    

    @Before
    public  void setUp() throws Exception {
        Config.getConfig().setBeutenId((long)20);
        
                
        brutActivity = Robolectric.buildActivity(BrutActivity.class).create().get();
        textfeldEier = (EditText) brutActivity.findViewById(R.id.Bruteier);

    }
    
    
    
    @Test
    public void Testtextfeld() {
        
        CharSequence text = "3";
        
        textfeldEier.setText(text);
        
        assertEquals("3", textfeldEier.getText().toString());

    }
    
    
    
    
}



