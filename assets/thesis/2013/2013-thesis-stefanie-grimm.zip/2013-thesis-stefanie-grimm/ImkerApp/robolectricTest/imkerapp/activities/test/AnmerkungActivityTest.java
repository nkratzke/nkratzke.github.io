package imkerapp.activities.test;


import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import imkerapp.activities.AnmerkungActivity;
import imkerapp.activities.AnmerkungenHistorieActivity;
import imkerapp.database.Config;
import imkerapp.database.daoobjekte.Anmerkung;
import imkerapp.database.daoobjekte.Beute;
import imkerapp.database.daoobjekte.Standort;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.shadows.ShadowActivity;
import org.robolectric.shadows.ShadowIntent;

import com.example.imkerapp.R;

import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;

@RunWith (RobolectricTestRunner.class)
public class AnmerkungActivityTest {
	
	AnmerkungActivity anmActivity;
	Button historie;
	Standort standort;
	Beute beute;
	Anmerkung anm;
	EditText textfeld;
	

	@Before
	public void setUp() throws Exception {
		Config.getConfig().setBeutenId((long)20);
		anmActivity = Robolectric.buildActivity(AnmerkungActivity.class).create().get();	 
		
		
		
		
	}
	
	@Test
	public void testText() {
		CharSequence text = "Futter";
		textfeld = (EditText) anmActivity.findViewById(R.id.anmerkungTexte);
		
		textfeld.setText(text);
		
		String result = "Futter";
		
		assertEquals(result, textfeld.getText().toString());
	}
	
	@Test
	public void pressButton() {
		
		
		historie = (Button) anmActivity.findViewById(R.id.anmerkungHistorie);
		
		historie.performClick();
		ShadowActivity shadowActivity = Robolectric.shadowOf(anmActivity);
		Intent startedIntent = shadowActivity.getNextStartedActivity();
		ShadowIntent shadowIntent = Robolectric.shadowOf(startedIntent);
		
		assertThat(shadowIntent.getComponent().getClassName(), equalTo(AnmerkungenHistorieActivity.class.getName()));
	
		

	}
}




