/**
 * Projekt:         ImkerApp
 * Autor:           Stefanie Grimm
 * Version:         1.3
 * Letzte �nderung: 28.04.2013
 * Beschreibung:    Diese Klasse verwaltet die Oberfl�che der Anmerkungen. 
 *                  Es wird festgelegt, welche Aktionen bei den einzelnen Button ausgef�hrt
 *                  werden sollen und was beim Start der Oberfl�che passieren soll.
 *
 */

package imkerapp.activities;


import imkerapp.database.daoobjekte.*;
import imkerapp.database.daos.*;
import imkerapp.database.Config;
import imkerapp.database.DaoMaster;
import imkerapp.database.DatabaseManager;

import java.util.Date;
import java.util.List;

import com.example.imkerapp.R;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;



public class AnmerkungActivity extends Activity {
    
    /*Nummer der aktuellen Beute */
    private long beutennummer;
    /*DAO f�r Anmerkung*/
    private AnmerkungDao anmerkungDao;
    /*zum �ffnen der Oberfl�che f�r Anmerkungenhistorie */
    private Intent nextScreenAnmerkungHistorie;
    /*Textfeld Text */
    private EditText text;
    /*Button zum Speichern*/
    private Button buttonSpeichern;
    /*Button f�r die Historie*/
    private Button buttonHistorie;
    /*Liste zum Speichern der Anmerkungen*/
    private List<Anmerkung> anmerkunglist;
    

    
    /**
     * Hier wird festgelegt, was beim Aufruf der Oberfl�che geschehen soll. So wird hier festgelegt, was beim Aufruf der Variablen 'nextScreenAnmerkungHistorie'
     * passieren soll. Zudem wird auf die Textfelder der zugeh�rigen Oberfl�che zugegriffen und die zuletzt eingegebenen Daten �ber den DAO aus der Datenbank in die 
     * jeweiligen Textfelder geschrieben. 
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anmerkung);
        

      // Wenn der Debugmodus auf true steht, wird die Datenbank einmal gel�scht und neu angelegt. Wird nur zum Testen der App ben�tigt.
      if(DatabaseManager.getDebug()){
            this.deleteDatabase("imker-db");
            DatabaseManager.getInstance(new DaoMaster.DevOpenHelper(this, "imker-db", null));            
        }
        
        /*Intent i = getIntent();
        Log.i("Sg","Beute"+i.getStringExtra("BeutenId")+"#");  
        beutennummer = Long.parseLong(i.getStringExtra("BeutenId"));*/
        
        
        Log.i("Sg","Beute"+Config.getConfig().getBeutenId()+"#");  
        beutennummer =Config.getConfig().getBeutenId();
        
        // Festlegung, das beim Aufruf von 'nextScreenAnmerkungHistorie' die Oberfl�che f�r die Historie der Anmerkung ge�ffnet werden soll.
        nextScreenAnmerkungHistorie = new Intent(getApplicationContext(), AnmerkungenHistorieActivity.class);
        nextScreenAnmerkungHistorie.putExtra("BeutenId", beutennummer+"");
        
        // Zugreifen auf Textfelder
        text = (EditText)findViewById(R.id.anmerkungTexte); 
        
     
        
        
        anmerkungDao  = DatabaseManager.getInstance().getAnmerkungDao();
        System.out.println(anmerkungDao);
        //F�r die aktuelle Beutennummer werden die Anmerkungen in einer Liste, dem Datum aufsteigend sortiert, eingetragen.
        anmerkunglist = anmerkungDao.queryBuilder().where(AnmerkungDao.Properties.BeutenId.eq(beutennummer)).orderAsc(AnmerkungDao.Properties.Date).limit(1).list();        
        // Befindet sich Inhalt der erstellten Liste, wird der jeweilige Inhalt in die Textfelder geschrieben.
        if(anmerkunglist.size()>0)
        {
            text.setText(anmerkunglist.get(0).getText());
           
        }
        
        ButtonListener();
    }

    
   
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.anmerkung, menu);
        return true;
    }
    
 
            
        
    
    /**
     * In dieser Methode wird zum einen auf die entsprechenden Button zugegriffen und ihnen Funktionen zugewiesen.
     */
    private void ButtonListener() {
         
          // Anlegen der Button
          buttonSpeichern = (Button) findViewById(R.id.anmerkungSpeichern);
          buttonHistorie = (Button) findViewById(R.id.anmerkungHistorie);
          
       // Erstellt einen Dialog
          AlertDialog.Builder builder = new AlertDialog.Builder(this);
          builder.setMessage("Ihre Daten wurden gespeichert!")
                 .setCancelable(false)
                 .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                     public void onClick(DialogInterface dialog, int id) {
                      
                     }
                 });
          final AlertDialog alertDialog = builder.create();
           
          // Dem Button Speichern wird zugewiesen, dass er beim Klicken alle eingegebene Daten �der den DAO in der Datenbank speichern soll.
         buttonSpeichern.setOnClickListener(new View.OnClickListener() {
           public void onClick(View v) {
                            
              Anmerkung anmerkung = new Anmerkung(null, new Date(), text.getText().toString(), beutennummer);
                
                
              anmerkungDao = DatabaseManager.getInstance().getAnmerkungDao();
              anmerkungDao.insert(anmerkung);  
              
              alertDialog.show();
              
           }
          });
            
         // Dem Button Historie wird zugewiesen, beim Klicken die Oberfl�che f�r die Historie der Anmerkungen zu �ffnen. 
            buttonHistorie.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {

                    startActivity(nextScreenAnmerkungHistorie);
                }
                });
    }
  }


