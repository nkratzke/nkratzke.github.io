/**
 * Projekt:         ImkerApp
 * Autor:           Stefanie Grimm
 * Version:         1.0
 * Letzte �nderung: 26.04.2013
 * Beschreibung:    Diese Klasse verwaltet die Oberfl�che der Brut. Es wird festgelegt, was beim Start der Oberfl�che passieren soll.
 * 
 */


package imkerapp.activities;

import imkerapp.database.daoobjekte.*;
import imkerapp.database.daos.*;
import imkerapp.database.Config;
import imkerapp.database.DaoMaster;
import imkerapp.database.DatabaseManager;

import java.util.Date;
import java.util.List;

import com.example.imkerapp.R;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class BrutActivity extends Activity {

    /*Nummer der aktuellen Beute */
	private long beutennummer;
	/*Dao f�r die Brut*/
	BrutDao brutDao;
	 /*zum �ffnen der Oberfl�che Bruthistorie*/
	private Intent nextScreenBrutHistorie;
	 /*Textfeld Eier*/
	private EditText eier;
	 /*Textfeld offene Brut*/
	private EditText offen;
	 /*Textfeld verdeckelte Brut*/
	private EditText verdeckelt;
	 /*Textfeld Brutwaben*/
	private EditText waben;
	/*Button zum Speichern*/
	private Button buttonSpeichern;
	/*Button f�r Historie*/
	private Button buttonHistorie;
	/*Liste zum Speichern der Brut*/
	private List<Brut> brutlist;
	
	
	/**
	 * Hier wird festgelegt, was beim Aufruf der Oberfl�che geschehen soll. So wird hier festgelegt, was beim Aufruf der Variablen 'nextScreenBrutHistorie'
     * passieren soll. Zudem wird auf die Textfelder der zugeh�rigen Oberfl�che zugegriffen und die zuletzt eingegebenen Daten �ber den DAO aus der Datenbank in die 
     * jeweiligen Textfelder geschrieben. 
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_brut);
		
		// Wenn der Debugmodus auf true steht, wird die Datenbank einmal gel�scht und neu angelegt. Wird nur zum Testen der App ben�tigt.
	      if(DatabaseManager.getInstance().getDebug()){
	            this.deleteDatabase("imker-db");
	            DatabaseManager.getInstance(new DaoMaster.DevOpenHelper(this, "imker-db", null));
	        }
		
		
		
		
//		Intent i = getIntent();
//		Log.i("Sg","Beute"+i.getStringExtra("BeutenId")+"#");  
	      beutennummer =Config.getConfig().getBeutenId();
		
		// Festlegung, das beim Aufruf von 'nextScreenBrutHistorie' die Oberfl�che f�r die Historie der Brut ge�ffnet werden soll.
		nextScreenBrutHistorie = new Intent(getApplicationContext(), BrutHistorieActivity.class);
		nextScreenBrutHistorie.putExtra("BeutenId", beutennummer+"");
		
		// Zugreifen auf Textfelder
		waben = (EditText)findViewById(R.id.Brutwaben); 
		verdeckelt = (EditText)findViewById(R.id.BrutVerdeckelt); 
		offen = (EditText)findViewById(R.id.Brutoffen); 
		eier = (EditText)findViewById(R.id.Bruteier); 
		
		brutDao  = DatabaseManager.getInstance().getBrutDao();
		//F�r die aktuelle Beutennummer werden die Brutdaten in einer Liste, dem Datum aufsteigend sortiert, eingetragen.
		brutlist = brutDao.queryBuilder().where(BrutDao.Properties.BeutenId.eq(beutennummer)).orderAsc(BrutDao.Properties.Date).limit(1).list();
		// Befindet sich Inhalt der erstellten Liste, wird der jeweilige Inhalt in die Textfelder geschrieben.
		if(brutlist.size()>0)
		{
			waben.setText(brutlist.get(0).getWaben()+"");
			verdeckelt.setText(brutlist.get(0).getVerdaekeltebrut()+"");
			offen.setText(brutlist.get(0).getOffnebrut()+"");	
			eier.setText(brutlist.get(0).getEier()+"");	
		}
		
		ButtonListener();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.brut, menu);
		return true;
	}
	/**
     * In dieser Methode wird zum einen auf die entsprechenden Button zugegriffen und ihnen Funktionen zugewiesen.
     */
	private void ButtonListener() {
		
	    // Anlegen der Button
    	 buttonSpeichern = (Button) findViewById(R.id.brutspeichern);
    	 buttonHistorie = (Button) findViewById(R.id.Bruthistorie);
    	 
    	// Erstellt einen Dialog
         AlertDialog.Builder builder = new AlertDialog.Builder(this);
         builder.setMessage("Ihre Daten wurden gespeichert!")
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                     
                    }
                });
         final AlertDialog alertDialog = builder.create();
    	
    	// Dem Button Speichern wird zugewiesen, dass er beim Klicken alle eingegebene Daten �der den DAO in der Datenbank speichern soll.
    	buttonSpeichern.setOnClickListener(new View.OnClickListener() {
    	public void onClick(View v) {
    		    		
    		Brut brut = new Brut(null, new Date(), 
    				Integer.parseInt(waben.getText().toString()), 
    				Integer.parseInt(verdeckelt.getText().toString()), 
    				Integer.parseInt(offen.getText().toString()), 
    				Integer.parseInt(offen.getText().toString()), 
    				beutennummer);
    		
    		brutDao = DatabaseManager.getInstance().getBrutDao();
    		brutDao.insert(brut); 
    		
    		alertDialog.show();
    	}
    	});
    	
    	// Dem Button Historie wird zugewiesen, beim Klicken die Oberfl�che f�r die Historie der Anmerkungen zu �ffnen. 
    	buttonHistorie.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {

        		startActivity(nextScreenBrutHistorie);
        	}
        	});
}

}
