/**
 * Projekt:         ImkerApp
 * Autor:           Stefanie Grimm
 * Version:         2.0
 * Letzte �nderung: 29.04.2013
 * Beschreibung:    Diese Klasse verwaltet die Oberfl�che der K�nigin. Es wird festgelegt, welche Aktionen bei den einzelnen Button ausgef�hrt
 *                  werden sollen und was beim Start der Oberfl�che passieren soll.
 * 
 */

package imkerapp.activities;

import imkerapp.database.Config;
import imkerapp.database.DaoMaster;
import imkerapp.database.DatabaseManager;
import imkerapp.database.daoobjekte.*;
import imkerapp.database.daos.*;
import java.util.Date;
import java.util.List;

import com.example.imkerapp.R;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class KoeniginActivity extends Activity {

    /*Nummer der aktuellen Beute*/
	private long beutennummer;
	/*DAO f�r K�nigin*/
	private KoeniginDao koeniginDao;
	/*zum �ffnen der Oberfl�che der K�niginhistorie*/
	private Intent nextScreenKoeniginHistorie;
	/*Textfeld Jahrgang*/
	private EditText jahr;
	/*Textfeld Rasse*/
	private EditText rasse;
	/*Textfeld Zeichen*/
	private EditText zeichen;
	/*Textfeld Z�chter*/
	private EditText zuechter;
	/*Button zum Speichern*/
	private Button buttonSpeichern;
	/*Button f�r Historie*/
	private Button buttonHistorie;
	/*Liste zum Speichern der K�nigin*/
	private List<Koenigin> koeniginlist;
	
	
	/**
    * Hier wird festgelegt, was beim Aufruf der Oberfl�che geschehen soll. So wird hier festgelegt, was beim Aufruf der Variablen 'nextScreenKoeniginHistorie'
    * passieren soll. Zudem wird auf die Textfelder der zugeh�rigen Oberfl�che zugegriffen und die zuletzt eingegebenen Daten �ber den DAO aus der Datenbank in die 
    * jeweiligen Textfelder geschrieben. 
    */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_koenigin);
		
		// Wenn der Debugmodus auf true steht, wird die Datenbank einmal gel�scht und neu angelegt. Wird nur zum Testen der App ben�tigt.
	      if(DatabaseManager.getInstance().getDebug()){
	            this.deleteDatabase("imker-db");
	            DatabaseManager.getInstance(new DaoMaster.DevOpenHelper(this, "imker-db", null));
	        }
		
//		Intent i = getIntent();
//		Log.i("Sg","Beute"+i.getStringExtra("BeutenId")+"#");  
	      beutennummer =Config.getConfig().getBeutenId();
		
		// Festlegung, das beim Aufruf von 'nextScreenKoeniginHistorie' die Oberfl�che f�r die Historie der K�nigin ge�ffnet werden soll.
		nextScreenKoeniginHistorie = new Intent(getApplicationContext(), KoeniginHistorieActivity.class);
		nextScreenKoeniginHistorie.putExtra("BeutenId", beutennummer+"");
		
		// Zugreifen auf Textfelder
		jahr = (EditText)findViewById(R.id.Koeniginjahr); 
		rasse = (EditText)findViewById(R.id.Koeniginrasse); 
		zeichen = (EditText)findViewById(R.id.KoeniginZeichen); 
		zuechter = (EditText)findViewById(R.id.Koeniginzuechter); 
		
		koeniginDao = DatabaseManager.getInstance().getKoeniginDao();
		//F�r die aktuelle Beutennummer werden die K�niginnen in einer Liste, dem Datum aufsteigend sortiert, eingetragen.
		koeniginlist = koeniginDao.queryBuilder().where(KoeniginDao.Properties.BeutenId.eq(beutennummer)).orderAsc(KoeniginDao.Properties.Date).limit(1).list();
		// Befindet sich Inhalt der erstellten Liste, wird der jeweilige Inhalt in die Textfelder geschrieben.
		if(koeniginlist.size()>0)
		{
			jahr.setText(koeniginlist.get(0).getJahrgang()+"");
			rasse.setText(koeniginlist.get(0).getRasse()+"");
			zeichen.setText(koeniginlist.get(0).getZeichen()+"");	
			zuechter.setText(koeniginlist.get(0).getZuechter()+"");	
		}
		ButtonListener();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.koenigin, menu);
		return true;
	}
	
	
	/**
     * In dieser Methode wird zum einen auf die entsprechenden Button zugegriffen und ihnen Funktionen zugewiesen.
     */
	private void ButtonListener() {
	    
	    // Anlegen der Button
         buttonSpeichern = (Button) findViewById(R.id.koeniginSpeichern);        
         buttonHistorie =   (Button) findViewById(R.id.koeniginHistorie);
         
      // Erstellt einen Dialog
         AlertDialog.Builder builder = new AlertDialog.Builder(this);
         builder.setMessage("Ihre Daten wurden gespeichert!")
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                     
                    }
                });
         final AlertDialog alertDialog = builder.create();
        
         // Dem Button Speichern wird zugewiesen, dass er beim Klicken alle eingegebene Daten �der den DAO in der Datenbank speichern soll.
        buttonSpeichern.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
                        
            Koenigin koenigin = new Koenigin(null, new Date(), zeichen.getText().toString(), rasse.getText().toString(),
                                zuechter.getText().toString(), new Date(), beutennummer);
            
            koeniginDao = DatabaseManager.getInstance().getKoeniginDao();
            koeniginDao.insert(koenigin);   
            
            alertDialog.show();
        }
        });
        
     // Dem Button Historie wird zugewiesen, beim Klicken die Oberfl�che f�r die Historie der K�nigin zu �ffnen. 
        buttonHistorie.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                startActivity(nextScreenKoeniginHistorie);
            }
            });        
       
    }

}
