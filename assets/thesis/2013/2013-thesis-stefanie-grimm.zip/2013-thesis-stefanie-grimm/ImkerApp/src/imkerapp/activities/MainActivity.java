/**
 * Projekt:         ImkerApp
 * Autor:           Stefanie Grimm
 * Version:         1.4
 * Letzte �nderung: 08.04.2013
 * Beschreibung:    Diese Klasse verwaltet die Oberfl�che der Hauptoberfl�che. Es wird festgelegt, welche Aktionen bei den einzelnen Button ausgef�hrt
 *                  werden sollen und was beim Start der Oberfl�che passieren soll.
 * 
 */

package imkerapp.activities;

import java.util.List;

import imkerapp.database.daoobjekte.*;
import imkerapp.database.daos.*;
import imkerapp.database.daos.StandortDao.Properties;
import imkerapp.database.Config;
import imkerapp.database.DaoMaster;
import imkerapp.database.DatabaseManager;


import com.example.imkerapp.R;

import android.os.Bundle;
import android.os.Debug;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {
	
    /*zum �ffnen der Oberfl�che der Beutenliste*/
    private Intent nextScreenBeutenList;
    /*zum �ffnen der Oberfl�che zum Anlegen einer Beute*/
    private Intent nextScreenBeuteAnlegen;
    /*zum �ffnen der Oberfl�che der Beute*/
    private Intent nextScreenBeute;
    /*DAO f�r den Standort*/
	private StandortDao standortDao;
	/*DAO f�r Beute*/
	private BeuteDao beutenDao;
	/*Button Beute anlegen*/
	private Button buttonBeuteanlegen;
	/*Button OK*/
	private Button buttonOK;
	/*Textfeld Standortname*/
	private EditText standortname;
	/*Textfeld Beutennummer*/
	private EditText beutennummer;
	/*Liste zum Speichern der Standorte*/
	private List<Standort> standortlist;
	/*f�r Erstellung Dialog Leer*/
	private AlertDialog alertDialogLeer;
	/*f�r Erstellug Dialog keine Beute*/
	private AlertDialog alertDialogKeineBeute;
	/*f�r Erstellug Dialog kein STandort*/
    private AlertDialog alertDialogKeinStandort;
	
	
	/**
     * Hier wird festgelegt, was beim Aufruf der Oberfl�che geschehen soll. So wird hier die zu verwende Datenbank 'imker-db' geholt. 
     * Zudem wird auf die Textfelder der zugeh�rigen Oberfl�che zugegriffen.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {  
        
        // traceview starten
        //Debug.startMethodTracing("main");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
          
     // Wenn der Debugmodus auf true steht, wird die Datenbank einmal gel�scht und neu angelegt. Wird nur zum Testen der App ben�tigt.
        if(DatabaseManager.getInstance().getDebug()){
              this.deleteDatabase("imker-db");
              //DatabaseManager.getInstance(new DaoMaster.DevOpenHelper(this, "imker-db", null));
          }
        
        //this.deleteDatabase("imker-db");        
        // �bergeben der zu nutzenden Datenbank
        DatabaseManager.getInstance(new DaoMaster.DevOpenHelper(this, "imker-db", null));

        
     // Festlegung, das beim Aufruf von 'nextScreenAnmerkungHistorie' die Oberfl�che f�r die Historie der Anmerkung ge�ffnet werden soll.
        nextScreenBeuteAnlegen = new Intent(getApplicationContext(), NeueBeuteActivity.class);
        
        nextScreenBeutenList = new Intent(getApplicationContext(), UebersichtBeutenActivity.class);
        nextScreenBeute = new Intent(getApplicationContext(), MenuActivity.class);
        
       
     // Zugreifen auf Textfelder
        standortname = (EditText)findViewById(R.id.standort);    
        beutennummer = (EditText)findViewById(R.id.beutennummer);
        
        // Erstellt einen Dialog
        AlertDialog.Builder builderLeer = new AlertDialog.Builder(this);
        builderLeer.setMessage("Bitte geben Sie eine Beutennummer oder einen Standort ein!")
               .setCancelable(false)
               .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {
                    
                   }
               });
        alertDialogLeer = builderLeer.create();
        
        // Erstellt einen Dialog
        AlertDialog.Builder builderKeineBeute = new AlertDialog.Builder(this);
        builderKeineBeute.setMessage("Es wurde keine Beute mit der Nummer gefunden!")
               .setCancelable(false)
               .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {
                    
                   }
               });
        alertDialogKeineBeute = builderKeineBeute.create();
        
     // Erstellt einen Dialog
        AlertDialog.Builder builderKeinStandort = new AlertDialog.Builder(this);
        builderKeinStandort.setMessage("Es wurde kein Standort  gefunden!")
               .setCancelable(false)
               .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {
                    
                   }
               });
        alertDialogKeinStandort = builderKeinStandort.create();
    	
    	ButtonListener();
         
    	
              
        
       
      
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
        
        
    }  
    
    /**
    * In dieser Methode wird zum einen auf die entsprechenden Button zugegriffen und ihnen Funktionen zugewiesen. 
    */
   private void ButtonListener() {
       
    // Anlegen der Button
       buttonBeuteanlegen = (Button) findViewById(R.id.buttonBeuteanlegen);
       buttonOK = (Button) findViewById(R.id.buttonOK);  
        
      
    // Dem Button Beute anlegen wird zugewiesen, eim Klicken die Oberfl�che f�r das Anlegen einer Beute zu �ffnen. 
      buttonBeuteanlegen.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
          
          startActivity(nextScreenBeuteAnlegen);
      }
      });
      
      
      
      // Dem Button OK wird zugewiesen, was beim Klcik passieren soll, wenn die beiden Eingabefelder Beutennummer und Standortname 
      // leer sind, bzw. wenn nur eines der beiden einen Wert enth�lt.
      buttonOK.setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
                  
          
//        startActivity(myIntent);
           
          // Wenn beide Eingabefelder leer sind, soll ein Dialog erscheinen.
          if(beutennummer.getText().toString().equals("") && standortname.getText().toString().equals(""))
          {
              alertDialogLeer.show();
              
          }
          // Ist nur die Beutennummer leer, wird eine Liste des Standortes erstellt, welche den eingegeben Namen haben. 
          else if(beutennummer.getText().toString().equals(""))
          {               
              standortDao = DatabaseManager.getInstance().getStandortDao();
              standortlist = standortDao.queryBuilder().where(Properties.Name.eq(standortname.getText().toString())).list();
              // Befindet sich Inhalt in der Liste, wird die Oberfl�che mit der Beutenliste zu diesem Standort ge�ffnet.
              if(standortlist.size()>0)
              {
              Log.i("Sg",standortlist.get(0).getName());
                  nextScreenBeutenList.putExtra("standortname", standortlist.get(0).getName());
                  //nextScreenBeutenList.putExtra("standortID", standortlist.get(0).getId());   
                  Config.getConfig().setStandort(standortlist.get(0).getId());
                  startActivity(nextScreenBeutenList);
                  
              }
              // Ist die Liste leer, wurde der eingegebene Standort nicht gefunden.
              else
              {
                  Log.i("Sg","Kein standort gefunden");
                  alertDialogKeinStandort.show();
                  
              }
          
              // Ist nur der Standortname leer, wird eine Liste erstellt, welche die Beute mit der eingegeben Nummer enth�lt.
          }else{
              beutenDao= DatabaseManager.getInstance().getBeuteDao();
              List<Beute> beutelist = beutenDao.queryBuilder().where(BeuteDao.Properties.Id.eq(Long.parseLong(beutennummer.getText().toString()))).list();
              // Befindet sich Inhalt in der Liste, wird die Oberfl�che der Beute ge�ffnet.
              if(beutelist.size()>0)
              {
              Log.i("Sg",beutelist.get(0).getId()+"");
                  //nextScreenBeute.putExtra("BeutenId", beutelist.get(0).getId()+"");
                  //nextScreenBeute.putExtra("BeutenstandortID", beutelist.get(0).getStandortId()+"");  
                  Config.getConfig().setBeutenId(beutelist.get(0).getId());
                  Config.getConfig().setStandort(beutelist.get(0).getStandortId());
                  startActivity(nextScreenBeute);                 
              }
              // Ist die Liste leer, wurde die eingegebende Beute nicht gefunden.
              else
              {
                  Log.i("Sg","Keine Beute gefunden"); 
                  alertDialogKeineBeute.show();
              }
          }

          
      }
      });
        
        
    }
       /*// traceview beenden
       public void onDestroy() {
           Debug.stopMethodTracing();
       
       }*/
   
   
    	
}
 
