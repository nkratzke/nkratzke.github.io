/**
 * Projekt:         ImkerApp
 * Autor:           Stefanie Grimm
 * Version:         1.1
 * Letzte �nderung: 12.04.2013
 * Beschreibung:    Diese Klasse verwaltet die Oberfl�che des Men�s einer Beute. Es wird festgelegt, welche Aktionen bei den einzelnen Button ausgef�hrt
 *                  werden sollen und was beim Start der Oberfl�che passieren soll.
 * 
 */


package imkerapp.activities;

import imkerapp.database.Config;
import imkerapp.database.DaoMaster;
import imkerapp.database.DatabaseManager;

import com.example.imkerapp.R;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MenuActivity extends Activity {
    
    /*zum �ffnen der Oberfl�che Status*/
	private Intent nextScreenStatus;
	/*zum �ffnen der Oberfl�che Stockbau*/
	private Intent nextScreenStockbau;
	/*zum �ffnen der Oberfl�che Versorgung*/
	private Intent nextScreenVersorgung;
	/*zum �ffnen der Oberfl�che K�nigin*/
	private Intent nextScreenKoenigin;
	/*zum �ffnen der Oberfl�che Brut*/
	private Intent nextScreenBrut;
	/*zum �ffnen der Oberfl�che Anmerkung*/
	private Intent nextScreenAnmerkungen;
	/*Button Stockbau*/
	private Button buttonStockbau;
	/*Button Status*/
	private Button buttonStatus ;
	/*Button K�nigin*/
	private Button buttonKoenigin;
	/*Button Versorgung*/
	private Button buttonVersorgung ;
	/*Button Brut*/
	private Button buttonBrut;
	/*Button Anmerkung*/
	private Button buttonAnmerkung;

	
	/**
     * Hier wird festgelegt, was beim Aufruf der Oberfl�che geschehen soll. So wird hier festgelegt, was beim Aufruf der Intents passieren soll.
     *
     */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_beute);
		
		// Wenn der Debugmodus auf true steht, wird die Datenbank einmal gel�scht und neu angelegt. Wird nur zum Testen der App ben�tigt.
	      if(DatabaseManager.getInstance().getDebug()){
	            this.deleteDatabase("imker-db");
	            DatabaseManager.getInstance(new DaoMaster.DevOpenHelper(this, "imker-db", null));
	            Log.i("Sg","Beute clear#"); 
	        }
		
		final TextView beutennr = (TextView)findViewById(R.id.bnummer); 
//		Intent i = getIntent();
//		Log.i("Sg","Beute"+i.getStringExtra("BeutenId")+"#");  
//		beutennr.setText(i.getStringExtra("BeutenId"));
		
	      Log.i("Sg","Beute"+Config.getConfig().getBeutenId()+"#");  
	      beutennr.setText(Config.getConfig().getBeutenId().toString());
		
		 //Festlegung, das beim Aufruf von der Intents die jeweilige Oberfl�che ge�ffnet werden soll.
		 nextScreenStatus = new Intent(getApplicationContext(), StatusActivity.class);
		 nextScreenStockbau = new Intent(getApplicationContext(), StockbauActivity.class);
		 nextScreenVersorgung = new Intent(getApplicationContext(), VersorgungActivity.class);
		 nextScreenKoenigin = new Intent(getApplicationContext(), KoeniginActivity.class);		 
		 nextScreenBrut = new Intent(getApplicationContext(), BrutActivity.class);
		 nextScreenAnmerkungen = new Intent(getApplicationContext(), AnmerkungActivity.class);
		 
		
		 
		 nextScreenStatus.putExtra("BeutenId", beutennr.getText());
		 nextScreenStockbau.putExtra("BeutenId", beutennr.getText());
		 nextScreenVersorgung.putExtra("BeutenId", beutennr.getText());
		 nextScreenKoenigin.putExtra("BeutenId", beutennr.getText());
		 nextScreenBrut.putExtra("BeutenId", beutennr.getText());
		 nextScreenAnmerkungen.putExtra("BeutenId", beutennr.getText());
		
		 ButtonListener();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		
		return true;
	}
	
	
	/**
     * In dieser Methode wird zum einen auf die entsprechenden Button zugegriffen und ihnen Funktionen zugewiesen.
     */
	private void ButtonListener() {
		
	 // Anlegen der Button
    	buttonStockbau = (Button) findViewById(R.id.buttonStockbau);
        buttonStatus = (Button) findViewById(R.id.buttonStatus);
    	buttonKoenigin = (Button) findViewById(R.id.buttonKoenigin);
    	buttonVersorgung = (Button) findViewById(R.id.buttonVersorgung);
    	buttonBrut = (Button) findViewById(R.id.buttonbrut);
    	buttonAnmerkung = (Button) findViewById(R.id.buttonanmerkung);
    	
    	// Dem Button Stockbau wird zugewiesen, beim Klicken die Oberfl�che f�r den Stockbau zu �ffnen.
    	buttonStockbau.setOnClickListener(new View.OnClickListener() {
    	public void onClick(View v) {

    		startActivity(nextScreenStockbau);
    	}
    	});
    	
    	// Dem Button Status wird zugewiesen, beim Klicken die Oberfl�che f�r den Status zu �ffnen.
    	buttonStatus.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {

        		startActivity(nextScreenStatus);
        	}
        	});
    	
    	// Dem Button K�nigin wird zugewiesen, beim Klicken die Oberfl�che f�r die K�nigin zu �ffnen.
    	buttonKoenigin.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {

        		startActivity(nextScreenKoenigin);
        	}
        	});
    	
    	// Dem Button Versorgung wird zugewiesen, beim Klicken die Oberfl�che f�r die Versorgung zu �ffnen.
    	buttonVersorgung.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {

        		startActivity(nextScreenVersorgung);
        	}
        	});
    	
    	// Dem Button Brut wird zugewiesen, beim Klicken die Oberfl�che f�r die Brut zu �ffnen.
    	buttonBrut.setOnClickListener(new View.OnClickListener() {
    	public void onClick(View v) {

    		startActivity(nextScreenBrut);
    	}
    	});
	
    	// Dem Button Anmerkung wird zugewiesen, beim Klicken die Oberfl�che f�r die Anmerkungen zu �ffnen.
    	buttonAnmerkung.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {

            startActivity(nextScreenAnmerkungen);
        }
        });
	

//buttonAnmerkung.setOnClickListener(new View.OnClickListener() {
//	public void onClick(View v) {
//
//		startActivity(nextScreenAnmerkung);
//	}
//	});
}

}
