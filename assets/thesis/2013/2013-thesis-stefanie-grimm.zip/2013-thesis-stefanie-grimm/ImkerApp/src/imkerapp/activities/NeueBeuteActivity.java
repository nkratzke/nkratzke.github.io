/**
 * Projekt:         ImkerApp
 * Autor:           Stefanie Grimm
 * Version:         1.7
 * Letzte �nderung: 16.04.2013
 * Beschreibung:    Diese Klasse verwaltet die Oberfl�che von dem Anlegen einer neuen Beute. Es wird festgelegt, welche Aktionen bei den einzelnen Button ausgef�hrt
 *                  werden sollen und was beim Start der Oberfl�che passieren soll.
 * 
 */

package imkerapp.activities;

import java.util.Date;
import java.util.List;

import imkerapp.database.daoobjekte.*;
import imkerapp.database.daos.*;
import imkerapp.database.DaoMaster;
import imkerapp.database.DatabaseManager;


import com.example.imkerapp.R;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

public class NeueBeuteActivity extends Activity {
    
    
    /*DAO f�r Standort*/
    private StandortDao standortDao;
    /*zum �ffnen der Oberfl�che des Hauptmen�s*/
    private Intent nextScreenMainActivity;
    /*DAO f�r Beuten*/
    private BeuteDao beutenDao;
    /*DAO f�r K�nigin*/
    private KoeniginDao koeniginDao;
    /* Liste zum Speichern der Standorte*/
    private List<Standort> liststandort;
    /*Textfeld Standort*/
    private EditText neueBeuteStandort;
    /*Textfeld Zeichen*/
    private EditText neueBeuteZeichen;
    /*Textfeld Z�chter*/
    private EditText neueBeuteZuechter;
    /*Textfeld Beutennummer*/
    private EditText neueBeutebeutennummer;
    /*Textfeld Rasse*/
    private EditText neueBeuteRasse;
    /*Textfeld Jahrgang*/
    private EditText neueBeuteJahrgang;
    /*Button Datum f�r Jahrgang ausw�hlen*/
    private Button neueBeuteJahrgangButton;
    /*Button Speichern*/
    private Button speichern;    
    /*Dateum des Jahgangs*/
    private Date jahrgang;
    /*ID Standort*/
    private Long StandortID;
    
    
    
    /**
     * Hier wird festgelegt, was beim Aufruf der Oberfl�che geschehen soll. Es wird auf die Textfelder der zugeh�rigen Oberfl�che zugegriffen 
     * und die zuletzt eingegebenen Daten �ber den DAO aus der Datenbank in die jeweiligen Textfelder geschrieben. Des Weiteren wird f�r die Eingabe
     * des Jahrgangs der K�nigin ein Dialog erstellt, mit welchem man das Datum ausw�hlen kann.
     */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_neue_beute);
		
		// Wenn der Debugmodus auf true steht, wird die Datenbank einmal gel�scht und neu angelegt. Wird nur zum Testen der App ben�tigt.
	      if(DatabaseManager.getInstance().getDebug()){
	            this.deleteDatabase("imker-db");
	            DatabaseManager.getInstance(new DaoMaster.DevOpenHelper(this, "imker-db", null));
	        }
		
		// Zugreifen auf Textfelder
		neueBeutebeutennummer = (EditText)findViewById(R.id.neueBeuteNummer);
		neueBeuteStandort = (EditText)findViewById(R.id.neueBeuteStandort);
		neueBeuteZeichen = (EditText)findViewById(R.id.neueBeuteKoeniginZeichen);
		neueBeuteRasse = (EditText)findViewById(R.id.neueBeuteKoeniginRasse);		
		neueBeuteJahrgang = (EditText)findViewById(R.id.neueBeuteKoeniginJahrgang);
		neueBeuteZuechter = (EditText)findViewById(R.id.neueBeuteKoeniginZuechter);
		
		// Anlegen der Button
		neueBeuteJahrgangButton = (Button)findViewById(R.id.neueBeuteDatumAuswaehlen);
        speichern = (Button)findViewById(R.id.neueBeutebuttonSpeichern);
        
     // Festlegung, das beim Aufruf von 'nextScreenMainActivity' die Oberfl�che f�r das Hauptmen� ge�ffnet werden soll.
        nextScreenMainActivity = new Intent(getApplicationContext(), MainActivity.class);
		
		
		OnDateSetListener onDateSetListener = new OnDateSetListener() {
            
		    /**
		     * Wurde ein Datum ausgew�hlt wird dieses in das Textfeld Jahrgang auf der Oberfl�che geschrieben.
		     */
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                    int dayOfMonth) {
                
                neueBeuteJahrgang.setText(dayOfMonth+"/"+monthOfYear+"/"+year);
                jahrgang = new Date(year,monthOfYear,dayOfMonth);
                
            }
        };
        
        
        jahrgang = new Date();
        jahrgang.setYear(2013);
        
        // Erstellt den Dialog zum Ausw�hlen des Datums
        final DatePickerDialog datedialog = new DatePickerDialog(this, onDateSetListener
                , jahrgang.getYear(), new Date().getMonth(), new Date().getDay());
        
		
     // Dem Button Jahrgang wird zugewiesen, dass er beim Klicken den Dialog zum Ausw�hlen des Datums anzeigen soll.
        neueBeuteJahrgangButton.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                
                datedialog.show();
                
            }
        });
        
        // Erstellt einen Dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Ihre Daten wurden gespeichert!")
               .setCancelable(false)
               .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {
                    // Nach Speichern zum Hauptmen� zur�ckkehren
                       startActivity(nextScreenMainActivity);
                   }
               });
        final AlertDialog alertDialog = builder.create();
                
                
                
		
		
		
        // Dem Button Speichern wird zugewiesen, dass er beim Klicken die eingegbenen Daten entsprechend der DAOs in der Datenbank speichern soll.
		speichern.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                /*SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                Date jahrgang = new Date();
                try {
                    jahrgang = sdf.parse(neueBeuteJahrgang.getText().toString());
                } catch (ParseException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }*/
                //StandortID;
                standortDao = DatabaseManager.getInstance().getStandortDao();
              //F�r den eingegebenen Standortnamen werden die Standorte mit dem Namen in eine Liste eingetragen.
                liststandort = standortDao.queryBuilder().where(StandortDao.Properties.Name.eq(neueBeuteStandort.getText().toString())).limit(1).list();
                // Befindet sich Inhalt in der Liste, wird die StandortID geholt. 
                if(liststandort.size()>0){
                    StandortID=liststandort.get(0).getId();
                    //Toast.makeText(getApplicationContext(), "vorhandener Standort"+ StandortID+"#", Toast.LENGTH_SHORT).show();
                }
                // Ist die Liste leer, wird ein neuer Standort angelegt.
                else
                {
                    Standort standort = new Standort(null, neueBeuteStandort.getText().toString());
                    standortDao.insert(standort);
                    StandortID=standort.getId();
                    //Toast.makeText(getApplicationContext(), " Standort suche"+ StandortID+"#", Toast.LENGTH_SHORT).show();
                    
                }
                
                // Neue Beute wird angelegt, welche die entsprechende StandortID erh�lt.
                beutenDao = DatabaseManager.getInstance().getBeuteDao();
                Beute beute = new Beute(Long.parseLong(neueBeutebeutennummer.getText().toString()), new Date(), StandortID);
                beutenDao.insert(beute);
                
                // Neue K�nigin wird angelegt, welche die entsprechende Beutennummer erh�lt.
                koeniginDao = DatabaseManager.getInstance().getKoeniginDao();
                Koenigin koenigin = new Koenigin(null, new Date(), neueBeuteZeichen.getText().toString(), neueBeuteRasse.getText().toString(), 
                        neueBeuteZuechter.getText().toString(), jahrgang, Long.parseLong(neueBeutebeutennummer.getText().toString()));
                koeniginDao.insert(koenigin);
               
             // Nachdem alles erfolgreich ausgef�hrt wurde, wird die Dialogbox angezeigt.
                alertDialog.show();
                
              
                
            }
        });
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.neue_beute, menu);
		return true;
	}

}
