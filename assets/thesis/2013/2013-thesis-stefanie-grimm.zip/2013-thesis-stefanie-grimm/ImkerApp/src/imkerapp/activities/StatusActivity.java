/**
 * Projekt:         ImkerApp
 * Autor:           Stefanie Grimm
 * Version:         1.0
 * Letzte �nderung: 30.04.2013
 * Beschreibung:    Diese Klasse verwaltet die Oberfl�che des Status. Es wird festgelegt, welche Aktionen bei den einzelnen Button ausgef�hrt
 *                  werden sollen und was beim Start der Oberfl�che passieren soll.
 * 
 */


package imkerapp.activities;



import imkerapp.database.Config;
import imkerapp.database.DaoMaster;
import imkerapp.database.DatabaseManager;
import imkerapp.database.daoobjekte.*;
import imkerapp.database.daos.*;

import java.util.Date;
import java.util.List;

import com.example.imkerapp.R;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class StatusActivity extends Activity {

    /*Nummer der aktuellen Beute*/
	private long beutennummer;
	/*zum �ffnen der Oberfl�che f�r Statushistorie*/
	Intent nextScreenStatusHistorie;
	/*Textfeld Futterwaben*/
	private EditText futter;
	/*Textfeld Sanftmut*/
	private EditText sanftmut;
	/*Textfeld Wabensitz*/
	private EditText wabensitz;
	/*Textfeld Honigleistung*/
	private EditText honigleistung;
	/*DAO f�r Status*/
	private StatusDao statusDao;
	/*DAO f�r VersorgungDao*/
    private VersorgungDao versorgungDao;
	/*Liste zum Speichern der Status*/
	private List<Status> statuslist;
	/*Button zum Speichern*/
	private Button buttonSpeichern;
	/*Button f�r Historie*/
	private Button buttonHistorie;
	/*Liste zum Speichern der Versorgung*/
	private List<Versorgung> versorgunglist;
	
	
	/**
     * Hier wird festgelegt, was beim Aufruf der Oberfl�che geschehen soll. So wird hier festgelegt, was beim Aufruf des Intents
     * passieren soll. Zudem wird auf die Textfelder der zugeh�rigen Oberfl�che zugegriffen und die zuletzt eingegebenen Daten �ber
     * den DAO aus der Datenbank in die jeweiligen Textfelder geschrieben. 
     */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_status);
		
		// Wenn der Debugmodus auf true steht, wird die Datenbank einmal gel�scht und neu angelegt. Wird nur zum Testen der App ben�tigt.
	      if(DatabaseManager.getInstance().getDebug()){
	            this.deleteDatabase("imker-db");
	            DatabaseManager.getInstance(new DaoMaster.DevOpenHelper(this, "imker-db", null));
	        }
	      
//		Intent i = getIntent();
//		Log.i("Sg","Beute"+i.getStringExtra("BeutenId")+"#");  
	      beutennummer =Config.getConfig().getBeutenId();
		
		// Festlegung, das beim Aufruf von 'nextScreenStatusHistorie' die Oberfl�che f�r die Historie der Status ge�ffnet werden soll.
		nextScreenStatusHistorie = new Intent(getApplicationContext(), StatusHistorieActivity.class);
		nextScreenStatusHistorie.putExtra("BeutenId", beutennummer+"");
		
		// Zugreifen auf Textfelder
		futter = (EditText)findViewById(R.id.Futter); 
		sanftmut = (EditText)findViewById(R.id.Sanftmut); 
		wabensitz = (EditText)findViewById(R.id.Wabensitz); 
		honigleistung = (EditText)findViewById(R.id.honigleistung);
		
		versorgungDao = DatabaseManager.getInstance().getVersorgungDao();
		//Es wird eine Liste der Versorgung anhand der Beutennummer erstellt.
		versorgunglist = versorgungDao.queryBuilder().where(VersorgungDao.Properties.BeutenId.eq(beutennummer)).list();
		// zum Aufaddieren der Honigleisutung
		int honig=0;
		// Jedes Element der Liste wird durchgegangen und dann die Werte, welche in Honig stehen, aufaddiert.
		for (Versorgung versorgung : versorgunglist) {
            honig += versorgung.getHonig();
        }
		
		
		statusDao= DatabaseManager.getInstance().getStatusDao();
		//Es wird eine Liste der Status erstellt, welche nach dem Datum aufteigend sortiert ist.
		statuslist = statusDao.queryBuilder().where(StatusDao.Properties.BeutenId.eq(beutennummer)).orderAsc(StatusDao.Properties.Date).limit(1).list();
		// Befindet sich Inhalt in der Liste wird dieser in die entsprechenden Textfelder geschrieben.
		if(statuslist.size()>0)
		{
//			Log.i("Sg","futterwaben"+statuslist.get(0).getFutterwaben());
//			Log.i("Sg","sanftmut"+statuslist.get(0).getSanftmut());
//			Log.i("Sg","wabensitz"+statuslist.get(0).getWabensitz());
//			Log.i("Sg","honigleistung"+statuslist.get(0).getHonigleistung());
			
			
			futter.setText(statuslist.get(0).getFutterwaben()+"");
			sanftmut.setText(statuslist.get(0).getSanftmut()+"");
			wabensitz.setText(statuslist.get(0).getWabensitz()+"");
			// Honigleistung bekommt aufaddierten Wert von Honig
			honigleistung.setText(honig+"");	
		}
		
		ButtonListener();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.status, menu);
		return true;
	}
	
	/**
     * In dieser Methode wird zum einen auf die entsprechenden Button zugegriffen und ihnen Funktionen zugewiesen.
     */
	private void ButtonListener() {
	    
	 // Anlegen der Button
    	buttonSpeichern = (Button) findViewById(R.id.statusSpeichern);
    	buttonHistorie = (Button) findViewById(R.id.statusHistorie);
    	
    	// Erstellt einen Dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Ihre Daten wurden gespeichert!")
               .setCancelable(false)
               .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {
                    
                   }
               });
        final AlertDialog alertDialog = builder.create();
    	
    	 // Dem Button Speichern wird zugewiesen, dass er beim Klicken alle eingegebene Daten �der den DAO in der Datenbank speichern soll.
    	buttonSpeichern.setOnClickListener(new View.OnClickListener() {
    	public void onClick(View v) {
    	    
    	    Status status = new Status(null, new Date(), Integer.parseInt(honigleistung.getText().toString()),
    	            Integer.parseInt(futter.getText().toString()), Integer.parseInt(wabensitz.getText().toString()),
    	            sanftmut.getText().toString(), beutennummer);
            
            StatusDao statusDao = DatabaseManager.getInstance().getStatusDao();
            statusDao.insert(status); 
            
            alertDialog.show();


    	}
    	});
    	
    	// Dem Button Historie wird zugewiesen, beim Klicken die Oberfl�che f�r die Historie der Status zu �ffnen.
    	buttonHistorie.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {

        	    startActivity(nextScreenStatusHistorie);
        	}
        	});
	}

}
