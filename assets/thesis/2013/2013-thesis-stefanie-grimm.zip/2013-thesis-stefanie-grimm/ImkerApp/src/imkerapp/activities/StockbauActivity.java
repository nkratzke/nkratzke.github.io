/**
 * Projekt:         ImkerApp
 * Autor:           Stefanie Grimm
 * Version:         1.3
 * Letzte �nderung: 17.04.2013
 * Beschreibung:    Diese Klasse verwaltet die Oberfl�che des Stockbaus. Es wird festgelegt, welche Aktionen bei den einzelnen Button ausgef�hrt
 *                  werden sollen und was beim Start der Oberfl�che passieren soll.
 * 
 */


package imkerapp.activities;

import imkerapp.database.Config;
import imkerapp.database.DaoMaster;
import imkerapp.database.DatabaseManager;
import imkerapp.database.daoobjekte.*;
import imkerapp.database.daos.*;

import java.util.Date;
import java.util.List;

import com.example.imkerapp.R;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class StockbauActivity extends Activity {

    /*Nummer der aktuellen Beute*/
	private long beutennummer;
	/*DAO Stockbau*/
	private StockbauDao stockbauDao;
	/*Liste zum Speichern der Stockbau*/
	private List<Stockbau> stockbaulist;
	/*zum �ffnen der Oberfl�che f�r Stockbauhistorie*/
	private Intent nextScreenStockbauHistorie;
	/*Textfeld Brutwaben*/
	private EditText brutwaben;
	/*Textfeld Mittelwaende*/
	private EditText mittelweande;
	/*Textfeld Waben*/
	private EditText waben;
	/*Button zum Speichern*/
	private Button buttonSpeichern;
	/*Button f�r Historie*/
	private Button buttonHistorie;
	
	
	 /**
     * Hier wird festgelegt, was beim Aufruf der Oberfl�che geschehen soll. So wird hier festgelegt, was beim Aufruf der Variablen 'nextScreenStockbauHistorie'
     * passieren soll. Zudem wird auf die Textfelder der zugeh�rigen Oberfl�che zugegriffen und die zuletzt eingegebenen Daten �ber den DAO aus der Datenbank in die 
     * jeweiligen Textfelder geschrieben. 
     */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_stockbau);
		
		// Wenn der Debugmodus auf true steht, wird die Datenbank einmal gel�scht und neu angelegt. Wird nur zum Testen der App ben�tigt.
	      if(DatabaseManager.getInstance().getDebug()){
	            this.deleteDatabase("imker-db");
	            DatabaseManager.getInstance(new DaoMaster.DevOpenHelper(this, "imker-db", null));
	        }
	      
//		Intent i = getIntent();
//		Log.i("Sg","Beute"+i.getStringExtra("BeutenId")+"#");  
	      beutennummer =Config.getConfig().getBeutenId();
		
		// Festlegung, das beim Aufruf von 'nextScreenAnmerkungHistorie' die Oberfl�che f�r die Historie der Anmerkung ge�ffnet werden soll.
		nextScreenStockbauHistorie = new Intent(getApplicationContext(), StockbauHistorieActivity.class);
		nextScreenStockbauHistorie.putExtra("BeutenId", beutennummer+"");
		
		// Zugreifen auf Textfelder
		brutwaben = (EditText)findViewById(R.id.StockbauBrutwabe); 
		mittelweande = (EditText)findViewById(R.id.Stockbaumittelwaende); 
		waben = (EditText)findViewById(R.id.Stockbauwaben); 
		
		stockbauDao = DatabaseManager.getInstance().getStockbauDao();
		//Es wird eine Liste der Stockbau erstellt, welche nach dem Datum aufteigend sortiert ist.
		stockbaulist = stockbauDao.queryBuilder().where(StockbauDao.Properties.BeutenId.eq(beutennummer)).orderDesc(StockbauDao.Properties.Date).limit(1).list();
		// Befindet sich Inhalt der erstellten Liste, wird der jeweilige Inhalt in die Textfelder geschrieben.
		if(stockbaulist.size()>0)
		{
			brutwaben.setText(stockbaulist.get(0).getBrutwaben()+"");
			mittelweande.setText(stockbaulist.get(0).getMittelwaende()+"");
			waben.setText(stockbaulist.get(0).getWaben()+"");						
		}
		
		ButtonListener();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.stockbau, menu);
		return true;
	}
	
	
	/**
     * In dieser Methode wird zum einen auf die entsprechenden Button zugegriffen und ihnen Funktionen zugewiesen.
     */
	private void ButtonListener() {
	    
	 // Anlegen der Button
    	buttonHistorie = (Button) findViewById(R.id.stockbauHistorie);
    	buttonSpeichern = (Button) findViewById(R.id.stockbauSpeichern);
    	
    	// Erstellt einen Dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Ihre Daten wurden gespeichert!")
               .setCancelable(false)
               .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {
                    
                   }
               });
        final AlertDialog alertDialog = builder.create();
    	
    	// Dem Button Historie wird zugewiesen, beim Klicken die Oberfl�che f�r die Historie der Stockbau zu �ffnen.
    	buttonHistorie.setOnClickListener(new View.OnClickListener() {
    	public void onClick(View v) {
    	    
    	    startActivity(nextScreenStockbauHistorie);


    	}
    	});
    	
    	// Dem Button Speichern wird zugewiesen, dass er beim Klicken alle eingegebene Daten �der den DAO in der Datenbank speichern soll.
    	buttonSpeichern.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                
                stockbauDao = DatabaseManager.getInstance().getStockbauDao();
                Stockbau stockbau = new Stockbau(null, new Date(), 
                        Integer.parseInt(waben.getText().toString()), 
                        Integer.parseInt(mittelweande.getText().toString()), 
                        Integer.parseInt(brutwaben.getText().toString()), beutennummer);

                stockbauDao.insert(stockbau);
                
                alertDialog.show();
            }
            });
	}

}
