/**
 * Projekt:         ImkerApp
 * Autor:           Stefanie Grimm
 * Version:         2.3
 * Letzte �nderung: 20.04.2013
 * Beschreibung:    Diese Klasse verwaltet die Oberfl�che der �bersicht aller Beuten eines Standorts. Es wird eine Tabelle zur Ansicht erstellt 
 *                  und ein Intent um anschlie�end auf eine Tabellenzeile zu klicken und dann zur entsprechenden Beutenoberfl�che zu gelangen.
 * 
 */

package imkerapp.activities;

import java.util.List;

import imkerapp.database.daoobjekte.*;
import imkerapp.database.daos.*;
import imkerapp.database.Config;
import imkerapp.database.DaoMaster;
import imkerapp.database.DatabaseManager;
import com.example.imkerapp.R;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class UebersichtBeutenActivity extends Activity {
	
    /*zum �ffnen der Oberfl�che einer Beute*/
	private Intent nextScreenBeute;
	/*Nummer der aktuellen Beute*/
	private String beutennummer;
	/*DAO Beute*/
	private BeuteDao beutenDao;
	/*Liste zum Speichern der Beuten*/
	private List<Beute> beutelist;
	/*Textfeld Standortname*/
	private EditText standortname;
	/*Tabelle Beuten*/
	private TableLayout table;

	
	/**
     * Hier wird festgelegt, was beim Aufruf der Oberfl�che geschehen soll. So wird hier festgelegt, was beim Aufruf der Variablen 'nextScreenBeute'
     * passieren soll. Zudem wird auf die Textfelder der zugeh�rigen Oberfl�che zugegriffen und eine Tabelle aller Beuten zu dem entsprechenden Standort angelget.
     */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_uebersicht_beuten);    
		
		// Wenn der Debugmodus auf true steht, wird die Datenbank einmal gel�scht und neu angelegt. Wird nur zum Testen der App ben�tigt.
	      if(DatabaseManager.getInstance().getDebug()){
	            this.deleteDatabase("imker-db");
	            DatabaseManager.getInstance(new DaoMaster.DevOpenHelper(this, "imker-db", null));
	        }

		// Festlegung, das beim Aufruf von 'nextScreenBeute' die Oberfl�che f�r die entsprechende Beute ge�ffnet werden soll.
        nextScreenBeute = new Intent(getApplicationContext(), MenuActivity.class);
       
        // Zugreifen auf Textfelder
        standortname = (EditText)findViewById(R.id.UebersichtStandort); 
//		Intent i = getIntent();
//		standortname.setText(i.getStringExtra("standortname"));
        standortname.setText(Config.getConfig().getStandort().toString());
        
		// Erstellen der Tabelle, welche in der zugeh�rigen XML-Datei schon angelegt wurde
		table = (TableLayout)findViewById(R.id.TableLayout01);
    	

    	beutenDao= DatabaseManager.getInstance().getBeuteDao();
    	// Es wird eine Liste mit allen Beuten erstellt.
		beutelist = beutenDao.loadAll();
		// Jedes Element der Liste wird durchgegangen und in die Tabelle eingef�gt
		for (Beute beute : beutelist) {
			addBeutenRow(table, beute.getId().toString());
		}		
	}

	
	/**
	 * F�gt eine neue Zeile in die Tabelle ein, wobei jede Zeile angeklickt werden kann.
	 * 
	 * @param table        aktuelle Tabelle
	 * @param Beutennummer aktuelle Beutennummer
	 */
	private void addBeutenRow(TableLayout table, String Beutennummer) {
		// Erstellt eine neue Tabellenzeile
        TableRow row = new TableRow(this);
        // Erstellt eine neuen Textview
        TextView t = new TextView(this);
        // Schreibt Text in die Textview
        t.setText(Beutennummer);    
        t.setBackgroundResource(R.drawable.cell_shape);
        // Textview kann angeklickt werden
        t.setClickable(true);
        // Beim Klick auf eine Textview wird die entsprechende Oberfl�che der Beute ge�ffnet.
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            	beutennummer = ((TextView)view).getText().toString();  
            	Log.i("Sg","Kein Beute gefunden"+beutennummer+"#");  
					nextScreenBeute.putExtra("BeutenId", beutennummer);
					startActivity(nextScreenBeute);					
				
            }
        });

        // add the TextView and the CheckBox to the new TableRow
        row.addView(t);        

        // add the TableRow to the TableLayout
        table.addView(row,new TableLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
	}

	


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.uebersicht_standorte, menu);
		return true;
	}

}
