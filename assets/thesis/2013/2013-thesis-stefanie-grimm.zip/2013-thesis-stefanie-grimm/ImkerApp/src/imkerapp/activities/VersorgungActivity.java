/**
 * Projekt:         ImkerApp
 * Autor:           Stefanie Grimm
 * Version:         1.0
 * Letzte �nderung: 30.04.2013
 * Beschreibung:    Diese Klasse verwaltet die Oberfl�che der Versorgung. Es wird festgelegt, welche Aktionen bei den einzelnen Button ausgef�hrt
 *                  werden sollen und was beim Start der Oberfl�che passieren soll.
 * 
 */

package imkerapp.activities;

import imkerapp.database.Config;
import imkerapp.database.DaoMaster;
import imkerapp.database.DatabaseManager;
import imkerapp.database.daoobjekte.*;
import imkerapp.database.daos.*;

import java.util.Date;
import java.util.List;

import com.example.imkerapp.R;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class VersorgungActivity extends Activity {
    
    /*Nummer der aktuellen Beute*/
	private long beutennummer;
	/*DAO Versorgung*/
	private VersorgungDao versorgungDao;
	/*Liste zum Speichern der Versorgung*/
	private List<Versorgung> versorgunglist;
	/*zum �ffnen der Oberfl�che f�r Versorgungshistorie*/
	private Intent nextScreenVersorgungHistorie;
	/*Textfeld Honig*/
	private EditText honig;
	/*Textfeld Zucker*/
	private EditText zucker;
	/*Textfeld Datum*/
	private TextView datum;
	/*Button zum Speichern*/
	private Button buttonSpeichern;
	/*Button f�r Historie*/
	private Button buttonHistorie;
	

	
	/**
     * Hier wird festgelegt, was beim Aufruf der Oberfl�che geschehen soll. So wird hier festgelegt, was beim Aufruf der Variablen 'nextScreenVersorgungHistorie'
     * passieren soll. Zudem wird auf die Textfelder der zugeh�rigen Oberfl�che zugegriffen und die zuletzt eingegebenen Daten �ber den DAO aus der Datenbank in die 
     * jeweiligen Textfelder geschrieben. 
     */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_versorgung);
		
//		Intent i = getIntent();
//        Log.i("Sg","Beute"+i.getStringExtra("BeutenId")+"#");  
		 beutennummer =Config.getConfig().getBeutenId();
        
     // Wenn der Debugmodus auf true steht, wird die Datenbank einmal gel�scht und neu angelegt. Wird nur zum Testen der App ben�tigt.
        if(DatabaseManager.getInstance().getDebug()){
              this.deleteDatabase("imker-db");
              DatabaseManager.getInstance(new DaoMaster.DevOpenHelper(this, "imker-db", null));
          }
        
        // Festlegung, das beim Aufruf von 'nextScreenVersorgungHistorie' die Oberfl�che f�r die Historie der Versorgung ge�ffnet werden soll.
        nextScreenVersorgungHistorie = new Intent(getApplicationContext(), VersorgungHistorieActivity.class);
        nextScreenVersorgungHistorie.putExtra("BeutenId", beutennummer+"");
        
     // Zugreifen auf Textfelder
        honig = (EditText)findViewById(R.id.versorgungHonig); 
        zucker = (EditText)findViewById(R.id.versorgungZucker);
        datum = (TextView)findViewById(R.id.versorgungDate);
        
        
        versorgungDao = DatabaseManager.getInstance().getVersorgungDao();
        //F�r die aktuelle Beutennummer werden die Versorgungen in einer Liste, dem Datum aufsteigend sortiert, eingetragen.
        versorgunglist = versorgungDao.queryBuilder().where(VersorgungDao.Properties.BeutenId.eq(beutennummer)).orderAsc(VersorgungDao.Properties.Date).limit(1).list();
     // Befindet sich Inhalt der erstellten Liste, wird der jeweilige Inhalt in die Textfelder geschrieben.
        if(versorgunglist.size()>0)
        {
            honig.setText(versorgunglist.get(0).getHonig()+"");
            zucker.setText(versorgunglist.get(0).getZucker()+"");
            datum.setText(versorgunglist.get(0).getDate()+"");
            
        }
        ButtonListener();
	}
	
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.versorgung, menu);
        return true;
    }
    
	/**
     * In dieser Methode wird zum einen auf die entsprechenden Button zugegriffen und ihnen Funktionen zugewiesen.
     */
	private void ButtonListener() {
       
	   // Anlegen der Button
       buttonSpeichern = (Button) findViewById(R.id.versorgungSpeichern);        
       buttonHistorie =   (Button) findViewById(R.id.versorgungHistorie);
       
    // Erstellt einen Dialog
       AlertDialog.Builder builder = new AlertDialog.Builder(this);
       builder.setMessage("Ihre Daten wurden gespeichert!")
              .setCancelable(false)
              .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                  public void onClick(DialogInterface dialog, int id) {
                   
                  }
              });
       final AlertDialog alertDialog = builder.create();
        
    // Dem Button Speichern wird zugewiesen, dass er beim Klicken alle eingegebene Daten �der den DAO in der Datenbank speichern soll.
        buttonSpeichern.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
                        
            Versorgung versorgung = new Versorgung(null, new Date(), Integer.parseInt(honig.getText().toString()), 
                    Integer.parseInt(zucker.getText().toString()), beutennummer);
            
            VersorgungDao versorgungDao = DatabaseManager.getInstance().getVersorgungDao();
            versorgungDao.insert(versorgung);      
            
            alertDialog.show();
        }
        });
        
        
        // Dem Button Historie wird zugewiesen, beim Klicken die Oberfl�che f�r die Historie der Versorgung zu �ffnen. 
        buttonHistorie.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                startActivity(nextScreenVersorgungHistorie);
            }
            });        
       
    }
	
	
    	
}
