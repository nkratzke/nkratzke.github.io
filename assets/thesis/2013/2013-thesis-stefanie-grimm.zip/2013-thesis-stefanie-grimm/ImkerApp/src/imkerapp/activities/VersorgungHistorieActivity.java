/**
 * Projekt:         ImkerApp
 * Autor:           Stefanie Grimm
 * Version:         1.0
 * Letzte �nderung: 26.04.2013
 * Beschreibung:    Diese Klasse verwaltet die Oberfl�che der Versorgunghisorie. Es wird festgelegt, was beim Start der Oberfl�che passieren soll.
 * 
 */

package imkerapp.activities;

import imkerapp.database.daoobjekte.*;
import imkerapp.database.daos.*;
import imkerapp.database.Config;
import imkerapp.database.DaoMaster;
import imkerapp.database.DatabaseManager;


import java.util.List;

import com.example.imkerapp.R;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.ViewGroup.LayoutParams;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class VersorgungHistorieActivity extends Activity {

    /*Tabelle Versorgung*/
    private TableLayout versorgungtable;
    /*DAO Versorgung*/
    private VersorgungDao versorgungDao;
    /*Liste zum Speichern der Versorgung*/
    List<Versorgung> versorgunglist;
    
    /**
     * Hier wird eine Tabelle f�r die Oberfl�che der Versorgunghistorie erstellt, welche dann mit den gespeicherten Daten 
     * �ber den DAO aus der Datenbank gef�llt wird.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_versorgung_historie);
        
     // Wenn der Debugmodus auf true steht, wird die Datenbank einmal gel�scht und neu angelegt. Wird nur zum Testen der App ben�tigt.
        if(DatabaseManager.getInstance().getDebug()){
              this.deleteDatabase("imker-db");
              DatabaseManager.getInstance(new DaoMaster.DevOpenHelper(this, "imker-db", null));
          }
        
//        Intent i = getIntent();
//        Log.i("Sg","Beute"+i.getStringExtra("BeutenId")+"#");  
          long beutennummer =Config.getConfig().getBeutenId();
        
     // Erstellen der Tabelle, welche in der zugeh�rigen XML-Datei schon angelegt wurde
        versorgungtable = (TableLayout)findViewById(R.id.VersorgungHistorieTable); 
        
        versorgungDao = DatabaseManager.getInstance().getVersorgungDao();
        //F�r die aktuelle Beutennummer werden die Versorgungen in einer Liste gespeichert
        versorgunglist = versorgungDao.queryBuilder().where(BrutDao.Properties.BeutenId.eq(beutennummer)).list();
        //Jedes Element der Liste wird durchgegangen und in die Tabelle eingetragen
        for (Versorgung versorgung : versorgunglist) {
            addRow(versorgungtable, versorgung);
        }
    }

    



    /**
     * Hier wird jeweils eine Zeile der Tabelle mit den zugeh�rigen Textviews angelegt und diese dann in die Tabelle eingef�gt.
     * 
     * @param table     aktuelle Tabelle
     * @param anmerkung aktuelles Element
     */
    private void addRow(TableLayout table, Versorgung versorgung) {
        // Erstellt eine neue Tabellenzeile
        TableRow row = new TableRow(this);
        
        //Erstellt neue Textviews
    addCell(row, versorgung.getDate().toString()); 
    addCell(row, versorgung.getHonig().toString());
    addCell(row, versorgung.getZucker().toString());   
  

 // f�gt die Zeile der Tabelle hinzu
    table.addView(row,new TableLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
}

    /**
     * Erstellung einer neuen Textview.
     * 
     * @param row   Tabellenzeile
     * @param name  Text, der in der Textview stehen soll
     */
private void addCell(TableRow row, String name) {
    TextView t = new TextView(this);
    t.setText(name);    
    t.setBackgroundResource(R.drawable.cell_shape);        
    row.addView(t);
}

@Override
public boolean onCreateOptionsMenu(Menu menu) {
    // Inflate the menu; this adds items to the action bar if it is present.
    getMenuInflater().inflate(R.menu.versorgung_historie, menu);
    return true;
}

}
