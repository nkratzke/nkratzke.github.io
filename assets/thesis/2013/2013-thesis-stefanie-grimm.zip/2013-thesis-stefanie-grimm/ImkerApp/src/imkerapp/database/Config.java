/**
 * Projekt:         ImkerApp
 * Autor:           Stefanie Grimm
 * Version:         1.0
 * Letzte �nderung: 13.05.2013
 * Beschreibung:    Diese Klasse beinhaltet die Getter- und Settermethoden f�r die StandortId und die BeutenId.
 * 
 */

package imkerapp.database;

public class Config {
    
    /*ID Standort*/
    private Long standortId;
    /*ID Beute*/
    private Long beutenId;
    /*Config*/
    private static Config config;
   
    /**
     * Kosntruktor.
     */
    private Config() {
        super();        
    }
    
    /**
     * Konstruktor.
     * 
     * @return      config
     */
    public static Config getConfig()
    {
        if(config==null)
        {
            config= new Config();
        }
        return config;
    }
    
    
    /**
     * Getter StandortID.
     * 
     * @return  standortID
     */
    public Long getStandort() {
        return standortId;
    }
    /**
     * Setter StandortID.
     * 
     * @param  standortID
     */
    public void setStandort(Long standortId) {
        this.standortId = standortId;
    }
    /**
     * Getter BeutenId.
     * 
     * @return  beutenId
     */
    public Long getBeutenId() {
        return beutenId;
    }
    /**
     * Setter BeutenId.
     * 
     * @param beutenId 
     */
    public void setBeutenId(Long beutenId) {
        this.beutenId = beutenId;
    }
    

}
