/**
 * Projekt:         ImkerApp
 * Autor:           Stefanie Grimm 
 * Version:         1.0
 * Letzte �nderung: 22.04.2013
 * Beschreibung:    Diese Klasse legt f�r die verwendete Datenbank Dummy-Daten an. Des Weiteren enth�lt sie getter- und setter-Methoden
 *                  f�r die DAO-Klassen.
 * 
 */
package imkerapp.database;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import imkerapp.database.DaoMaster.DevOpenHelper;
import android.database.sqlite.SQLiteDatabase;

import imkerapp.database.daos.*;
import  imkerapp.database.daoobjekte.*;

public class DatabaseManager {
	
    /*relationale Datenbank*/
	private SQLiteDatabase db;
	/*scheibender Zugriff auf Datenbank*/
    private DevOpenHelper helper;
    /*DAO-Objekte*/
    private DaoSession daoSession;
    /*DAO-Klassen*/
    private DaoMaster daoMaster;
    /*DAO Standort*/
    private StandortDao standortDao;
    /*DAO Beute*/
    private BeuteDao beuteDao;
    /*DAO Anmerkung*/
    private AnmerkungDao anmerkungDao;
    /*DAO Brut*/
    private BrutDao brutDao;
    /*DAO K�nigin*/
    private KoeniginDao koeniginDao;
    /*DAO Status*/
    private StatusDao statusDao;
    /*DAO Stockbau*/
    private StockbauDao stockbauDao;
    /*DAO Versorgung*/
    private VersorgungDao versorgungDao;    
    /*Datenbankmanager*/
    private static DatabaseManager databaseManager;
    /*f�r Debugmodus (true=testdaten, false=kein testen) */
    private static boolean debug = false;    
    /*f�r Debugmodus (true=testdaten, false=kein testdaten) */
    private boolean debugdata = false;

    /**
     * Konstruktor.
     * 
     * @param devOpenHelper
     */
	private DatabaseManager(DevOpenHelper devOpenHelper) {
		super();		
		
		helper = devOpenHelper;
        ini();
        
	}
	
	/**
	 * Gibt zur�ck, ob der Debugmodus auf true oder false steht. Nur f�r das Testen wichtig.
	 * 
	 * @return   true, false
	 */
	public static boolean getDebug()
    {
        return debug;
    }	
	
	/**
     * @return the debugdata
     */
    public boolean isDebugdata() {
        return debugdata;
    }

    /**
	 * Diese Methode initialisiert die Datenbank, �ergibt sie dem DAO-Master und holt sich alle ben�tigten DAO-Klassen.
	 * Des Weiteren werden hier die Dummy-Daten f�r die Datenbank angelegt.
	 */
	private void ini() {
		db = helper.getWritableDatabase();
        daoMaster = new DaoMaster(db);
        daoSession = daoMaster.newSession();  
        standortDao = daoSession.getStandortDao();
        beuteDao = daoSession.getBeuteDao();
        anmerkungDao =daoSession.getAnmerkungDao();
        brutDao = daoSession.getBrutDao();
        koeniginDao = daoSession.getKoeniginDao();
        statusDao = daoSession.getStatusDao();
        stockbauDao = daoSession.getStockbauDao();
        versorgungDao = daoSession.getVersorgungDao();
        
       
        if(debugdata){
        
            try{
                // Liste zum Speichern von Orten
                List<String> orte = new ArrayList<String>();
                // Orte werden der Liste hinzugef�gt
                orte.add("Hagenow");
                orte.add("Burg");
    			orte.add("Wenkendorf");
    			orte.add("Niendorf");
    			orte.add("Avendorf");
    			orte.add("Meeschendorf");
    			orte.add("Gammendorf");
    			orte.add("Landkirchen");
    			orte.add("Petersdorf");
                
                //List<Standort> standortliste = new ArrayList<Standort>();
                
    			// Jedes Element der Liste wird durchgegangen 
                for (String name : orte) {
                    // Anlegen eines neuen Standortes mit den vorher eingef�gte Namen 
                	Standort standort1 = new Standort(null, name);
                     standortDao.insert(standort1);                 
                     for(int i=0;i<20;i++)
                     {
                        // Neue Beuten werden angelegt
                     	Beute beute1 = new Beute((long)1+i, new Date(), standort1.getId());
                        beuteDao.insert(beute1);             
                        
                         // F�r jede DAO-Klasse werden Daten angelegt
                         for(int j=0;j<10;j++){
                        	 Status status = new Status(null, new Date(2013, 4, 1+j), 10, 1, 2, "gut", beute1.getId());
                        	 statusDao.insert(status);
                        	 
    	                     Stockbau stockbau = new Stockbau(null, new Date(2013, 4, 1+j), 10, 2, 10, beute1.getId());
    	                     stockbauDao.insert(stockbau);
    	                     
    	                     Koenigin koenigin = new Koenigin(null, new Date(2013, 4, 2+j), "Blau", "carnica", "Grimm", new Date(), beute1.getId());
    	                     koeniginDao.insert(koenigin);
    	                     
    	                     Versorgung versorgung = new Versorgung(null, new Date(2013, 4, 3+j), 10, 12, beute1.getId());
    	                     versorgungDao.insert(versorgung);
    	                     
    	                     Brut brut = new Brut(null, new Date(2013, 4, 4+j), 10, 100, 2, 10, beute1.getId());
    	                     brutDao.insert(brut);  
    	                     
    	                     Anmerkung anmerkung = new Anmerkung(null, new Date(2012, 3, 5+j), "gegen Varoa behandelt", beute1.getId());
                             anmerkungDao.insert(anmerkung);
    	                     
    	                     
    	                     
    	                     
                         }
                         
                     }
    			}
    
                }catch (Exception e) {
        			// TODO: handle exception
        		}
        }
	} 
	
	/**
	 * Getter Datenbankmanager
	 * 
	 * @return     databaseManager
	 */
	public static DatabaseManager getInstance()
	{		
		return databaseManager;
	}
	
	/**
	 * Wenn noch kein Datenbankmanager existiert, wird einer angelegt.
	 * 
	 * @param devOpenHelper
	 * @return             databaseManager
	 */
	public static DatabaseManager getInstance(DevOpenHelper devOpenHelper)
	{
		if(databaseManager==null)
		{
			databaseManager = new DatabaseManager(devOpenHelper);
		}
		return databaseManager;
	}
	
	
	/**
	 * Getter Datenbank
	 * 
	 * @return datenbank
	 */
	public SQLiteDatabase getDb() {
		return db;
	}
	
	/**
	 * Setter Datenbank
	 * 
	 * @param datenbank die gesetzt werden soll
	 */
	public void setDb(SQLiteDatabase db) {
		this.db = db;
	}
	
	
	/**
	 * Getter
	 * @return helper
	 */
	public DevOpenHelper getHelper() {
		return helper;
	}
	
	/**
	 * Setter
	 * @param helper der gesetzt werden soll
	 */
	public void setHelper(DevOpenHelper helper) {
		this.helper = helper;
	}
	
	
	/**
	 * Getter DAO-Session
	 * 
	 * @return daoSession
	 */
	public DaoSession getDaoSession() {
		return daoSession;
	}
	
	
	/**
	 * Setter DAO-Session
	 * 
	 * @param daoSession die gesetzt werden soll
	 */
	public void setDaoSession(DaoSession daoSession) {
		this.daoSession = daoSession;
	}
	/**
	 * Getter DAO-Master
	 * 
	 * @return daoMaster
	 */
	public DaoMaster getDaoMaster() {
		return daoMaster;
	}
	
	
	/**
	 * Setter DAO-Master
	 * 
	 * @param daoMaster der gesetzt werden soll
	 */
	public void setDaoMaster(DaoMaster daoMaster) {
		this.daoMaster = daoMaster;
	}
	
	
	/**
	 * Getter StandortDAO
	 * 
	 * @return standortDao
	 */
	public StandortDao getStandortDao() {
		return standortDao;
	}
	
	
	/**
	 * Setter StandortDAO
	 * 
	 * @param standortDao der gesetzt werden soll
	 */
	public void setStandortDao(StandortDao standortDao) {
		this.standortDao = standortDao;
	}
	
	
	/**
	 * Getter BeuteDAO
	 * 
	 * @return beuteDao
	 */
	public BeuteDao getBeuteDao() {
		return beuteDao;
	}
	
	
	/**
	 * Setter BeuteDAO
	 * 
	 * @param beuteDao der gesetzt werden soll
	 */
	public void setBeuteDao(BeuteDao beuteDao) {
		this.beuteDao = beuteDao;
	}
	

	/**
	 * Getter AnmerkungDAO
	 * 
	 * @return anmerkungDao
	 */
	public AnmerkungDao getAnmerkungDao() {
		return anmerkungDao;
	}
	

	/**
	 * Setter AnmerkungDAO
	 * 
	 * @param anmerkungDao der gesetzt werden soll
	 */
	public void setAnmerkungDao(AnmerkungDao anmerkungDao) {
		this.anmerkungDao = anmerkungDao;
	}

	/**
	 * Getter Brut DAO
	 * 
	 * @return brutDao
	 */
	public BrutDao getBrutDao() {
		return brutDao;
	}
	

	/**
	 * Setter BrutDAO
	 * 
	 * @param brutDao der gesetzt werden soll
	 */
	public void setBrutDao(BrutDao brutDao) {
		this.brutDao = brutDao;
	}
	

	/**
	 * Getter K�niginDAO
	 * 
	 * @return koeniginDao
	 */
	public KoeniginDao getKoeniginDao() {
		return koeniginDao;
	}
	

	/**
	 * Setter K�niginDAO
	 * 
	 * @param koeniginDao der gesetzt werden soll
	 */
	public void setKoeniginDao(KoeniginDao koeniginDao) {
		this.koeniginDao = koeniginDao;
	}

	
	/**
	 * Setter StatusDAO
	 * 
	 * @return statusDao
	 */
	public StatusDao getStatusDao() {
		return statusDao;
	}

	
	/**
	 * Setter StatusDAO
	 * 
	 * @param statusDao der gesetzt werden soll
	 */
	public void setStatusDao(StatusDao statusDao) {
		this.statusDao = statusDao;
	}
	

	/**
	 * Getter StockbauDAO
	 * 
	 * @return stockbauDao
	 */
	public StockbauDao getStockbauDao() {
		return stockbauDao;
	}
	

	/**
	 * Setter StockbauDAO
	 * 
	 * @param stockbauDao der gesetzt werden soll
	 */
	public void setStockbauDao(StockbauDao stockbauDao) {
		this.stockbauDao = stockbauDao;
	}

	/**
	 * Getter VersorgungDAO
	 * 
	 * @return versorgungDao
	 */
	public VersorgungDao getVersorgungDao() {
		return versorgungDao;
	}
	

	/**
	 * Setter VersorgungDAO
	 * 
	 * @param versorgungDao der gesetzt werden soll
	 */
	public void setVersorgungDao(VersorgungDao versorgungDao) {
		this.versorgungDao = versorgungDao;
	}

}
