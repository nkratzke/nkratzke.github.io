package imkerapp.activities.test;

import java.util.Date;
import java.util.List;

import com.example.imkerapp.R;
import imkerapp.activities.AnmerkungActivity;
import imkerapp.activities.AnmerkungenHistorieActivity;
import imkerapp.database.Config;
import imkerapp.database.DatabaseManager;
import imkerapp.database.daoobjekte.Anmerkung;
import imkerapp.database.daoobjekte.Beute;
import imkerapp.database.daoobjekte.Standort;
import imkerapp.database.daos.AnmerkungDao;
import android.app.Activity;
import android.app.Instrumentation.ActivityMonitor;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.Button;
import android.widget.EditText;

/**
 * @author Stefanie
 * 
 */
public class AnmerkungActivityTest extends
		ActivityInstrumentationTestCase2<AnmerkungActivity> {

	private EditText anmerkungText;
	Button historie;
	Button speichern;
	AnmerkungActivity anmerkungActivity;
	AnmerkungDao anmerkungDao;
	Anmerkung anmerkung;
	Standort standort;
	Beute beute;

	public AnmerkungActivityTest() {
		super(AnmerkungActivity.class);
	}

	/**
	 * @see android.test.ActivityInstrumentationTestCase2#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		// Beutennummer 20 �bergeben
		Config.getConfig().setBeutenId((long) 20);
		// Activity Anmerkung erstellen
		anmerkungActivity = this.getActivity();

		// zu testende Button und EditText-Felder erstellen
		historie = (Button) anmerkungActivity
				.findViewById(R.id.anmerkungHistorie);
		speichern = (Button) anmerkungActivity
				.findViewById(R.id.anmerkungSpeichern);
		anmerkungText = (EditText) anmerkungActivity
				.findViewById(R.id.anmerkungTexte);

	}

	/**
	 * Pr�ft, ob in das Textfeld Anmerkungtext richtig ein- und ausgelesen wird.
	 */
	public void testText() {
		// //Text
		// CharSequence text = "Honig";
		//
		// //Text in das Feld Anmerkungtext schreiben
		// anmerkungText.setText(text);

		// Pr�fen, ob es auch richtig wieder rausgelesen wird.
		assertEquals("gegen Varoa behandelt", anmerkungText.getText()
				.toString());

	}

	/**
	 * Pr�ft, ob der Button Historie auch die entsprechende Activity �ffnet.
	 */
	public void testButtonHistorie() {

		// registriert die n�chste Activity
		ActivityMonitor activityMonitor = getInstrumentation().addMonitor(
				AnmerkungenHistorieActivity.class.getName(), null, false);

		anmerkungActivity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// klick Button und �ffne n�chste Activity
				historie.performClick();

			}
		});

		Activity historieActivity = getInstrumentation().waitForMonitor(
				activityMonitor);
		// pr�ft, ob n�chste Activity ge�ffnet wird und schlie�t diese dann
		// wieder
		assertNotNull(historieActivity);
		historieActivity.finish();

	}

	/**
	 * Pr�ft, ob der Button Speichern die Daten richtig abspeichert.
	 */
	public void testButtonSpeichern() {

		anmerkungActivity.runOnUiThread(new Runnable() {

			@Override
			public void run() {

				boolean result = true;
				speichern.performClick();
				assertTrue(result);

			}
		});

		anmerkungDao = DatabaseManager.getInstance().getAnmerkungDao();

		String columnName = AnmerkungDao.Properties.BeutenId.columnName;

		List<Anmerkung> listresult = anmerkungDao.queryDeep("Where T."
				+ columnName + "=?", "20");

		assertEquals("Honig", listresult.get(0).getText().toString());

	}

	/**
	 * Pr�ft, ob der Text, welcher ge�ndert wurde, auch richtig abgespeichert
	 * wird.
	 */
	public void testAenderungen() {

		// setup
		anmerkungDao = DatabaseManager.getInstance().getAnmerkungDao();
		anmerkungDao.deleteAll();
		Anmerkung testanmerkung = new Anmerkung((long) 19, new Date(2013, 05,
				14), "Futter", 20);
		anmerkungDao.insert(testanmerkung);

		// change
		testanmerkung.setText("Honig");
		anmerkungDao.update(testanmerkung);

		// check
		String columnName = AnmerkungDao.Properties.Id.columnName;
		String text = anmerkungDao
				.queryDeep("Where T." + columnName + " =? ", "19").get(0)
				.getText();

		assertEquals("Honig", text);

	}

}
