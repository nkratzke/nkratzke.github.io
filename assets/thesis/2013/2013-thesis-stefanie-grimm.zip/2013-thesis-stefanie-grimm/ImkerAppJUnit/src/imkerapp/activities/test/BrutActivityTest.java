package imkerapp.activities.test;

import imkerapp.activities.BrutHistorieActivity;
import imkerapp.activities.BrutActivity;
import imkerapp.database.Config;
import imkerapp.database.DatabaseManager;
import imkerapp.database.daoobjekte.Beute;
import imkerapp.database.daoobjekte.Brut;
import imkerapp.database.daos.BrutDao;

import java.util.Date;
import java.util.List;

import com.example.imkerapp.R;

import android.app.Activity;
import android.app.Instrumentation.ActivityMonitor;
import android.test.ActivityInstrumentationTestCase2;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

public class BrutActivityTest extends
		ActivityInstrumentationTestCase2<BrutActivity> {

	private EditText eier;
	private EditText offen;
	private EditText verdeckelt;
	private EditText waben;
	Button historie;
	Button speichern;
	BrutActivity brutActivity;
	Beute beute;
	CharSequence textEier;
	CharSequence textOffen;
	CharSequence textVerdeckelt;
	CharSequence textWaben;
	BrutDao brutDao;
	
	public BrutActivityTest() {
		super(BrutActivity.class);		
	}

	/** 
	 * @see android.test.ActivityInstrumentationTestCase2#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();		
		Config.getConfig().setBeutenId((long)20);
		brutActivity=this.getActivity();	

		
		
		historie = (Button) brutActivity.findViewById(R.id.Bruthistorie);
		speichern = (Button) brutActivity.findViewById(R.id.brutspeichern);
		eier = (EditText) brutActivity.findViewById(R.id.Bruteier);
		offen = (EditText) brutActivity.findViewById(R.id.Brutoffen);
		verdeckelt = (EditText) brutActivity.findViewById(R.id.BrutVerdeckelt);
		waben = (EditText) brutActivity.findViewById(R.id.Brutwaben);
		
		
		
	}
	

	
	/**
	 * Pr�ft, ob in das Textfeld Eier richtig ein- und ausgelesen wird.
	 */
	public void testTexteier() {	
		
		final CharSequence text = "1";
		
		brutActivity.runOnUiThread(new Runnable() {
		    public void run() {
		    	
		    	eier.setText(text.toString());	     
		    }
		  });
		  getInstrumentation().waitForIdleSync();
		  
		 	
	  	  assertEquals("1", eier.getText().toString());	
		  
		
	}
	
	
	/**
	 * Pr�ft, ob in das Textfeld Offen richtig ein- und ausgelesen wird.
	 */
	public void testTextOffen() {	
		
		final CharSequence text = "2";
		
		brutActivity.runOnUiThread(new Runnable() {
		    public void run() {
		    	
		    	offen.setText(text.toString());	     
		    }
		  });
		  getInstrumentation().waitForIdleSync();
		  
		 	
	  	  assertEquals("2", offen.getText().toString());	
		  
		
	}
	
	
	/**
	 * Pr�ft, ob in das Textfeld Verdeckelt richtig ein- und ausgelesen wird.
	 */
	public void testTextVerdeckelt() {	
		
		final CharSequence text = "3";
		
		brutActivity.runOnUiThread(new Runnable() {
		    public void run() {
		    	
		    	verdeckelt.setText(text.toString());	     
		    }
		  });
		  getInstrumentation().waitForIdleSync();
		  
		 	
	  	  assertEquals("3", verdeckelt.getText().toString());	
		  
		
	}

	
	/**
	 * Pr�ft, ob in das Textfeld Waben richtig ein- und ausgelesen wird.
	 */
	public void testTextWaben() {	
		
		final CharSequence text = "4";
		
		brutActivity.runOnUiThread(new Runnable() {
		    public void run() {
		    	
		    	waben.setText(text.toString());	     
		    }
		  });
		  getInstrumentation().waitForIdleSync();
		  
		 	
	  	  assertEquals("4", waben.getText().toString());	
		  
		
	}
	
	/**
	 * Pr�ft, ob der Button Historie auch die entsprechende Activity �ffnet.
	 */
	public void testButtonHistorie() {
		// registriert die n�chste Activity
		ActivityMonitor activityMonitor = getInstrumentation().addMonitor(BrutHistorieActivity.class.getName(), null, false);
		
		brutActivity.runOnUiThread(new Runnable() {
			
			@Override
			public void run() {
				// klick Button und �ffne n�chste Activity
				historie.performClick();
				
			}
		});
		
		Activity historieActivity = getInstrumentation().waitForMonitor(activityMonitor);
		  // pr�ft, ob n�chste Activity ge�ffnet wird und schlie�t diese dann wieder
		  assertNotNull(historieActivity);
		  historieActivity .finish();
		
	}
	

	/**
	 * Pr�ft, ob der Butto Speichern die Daten richtig abspeichert.
	 */
	public void testButtonSpeichern() {	
		 
				
		brutActivity.runOnUiThread(new Runnable() {			
			
			@Override
			public void run() {	
	
				boolean result = true;
				speichern.performClick();	
				assertTrue(result);	
				
			}
		});
		
		brutDao = DatabaseManager.getInstance().getBrutDao();
		
		String columnName = BrutDao.Properties.BeutenId.columnName;
		
		List<Brut> listresult = brutDao.queryDeep("Where T."+ columnName +"=?", "20");
		
		String res = listresult.get(0).getEier().toString();
		
		Log.i("SG1", res);

		
		assertEquals("100", listresult.get(0).getEier().toString());
		assertEquals("10", listresult.get(0).getOffnebrut().toString());
		assertEquals("2", listresult.get(0).getVerdaekeltebrut().toString());
		assertEquals("10", listresult.get(0).getWaben().toString());
		
		
		
	}
	
	/**
	 * Pr�ft, ob der Text, welcher ge�ndert wurde, auch richtig abgespeichert
	 * wird.
	 */
	public void testAenderungen() {
		
		//setup
		brutDao = DatabaseManager.getInstance().getBrutDao();
		brutDao.deleteAll();
		Brut testbrut = new Brut((long)18, new Date(2013, 04, 13), 3, 5, 0, 1, 20);
		brutDao.insert(testbrut);
		
		//change
		testbrut.setEier(100);
		testbrut.setOffnebrut(10);
		testbrut.setVerdaekeltebrut(2);
		testbrut.setWaben(10);
		
		brutDao.update(testbrut);
		
		//check
		String columnName = BrutDao.Properties.Id.columnName;
		List<Brut> result = brutDao.queryDeep("Where T."+ columnName +" =? ", "18");
		
		assertEquals("100", result.get(0).getEier().toString());
		assertEquals("10", result.get(0).getOffnebrut().toString());
		assertEquals("2", result.get(0).getVerdaekeltebrut().toString());
		assertEquals("10", result.get(0).getWaben().toString());
		
		}
	
	

}
