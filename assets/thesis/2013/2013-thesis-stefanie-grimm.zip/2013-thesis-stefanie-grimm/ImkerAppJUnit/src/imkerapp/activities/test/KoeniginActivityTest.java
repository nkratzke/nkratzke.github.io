package imkerapp.activities.test;

import java.util.Date;
import java.util.List;

import com.example.imkerapp.R;

import imkerapp.activities.KoeniginActivity;
import imkerapp.activities.KoeniginHistorieActivity;
import imkerapp.database.Config;
import imkerapp.database.DatabaseManager;
import imkerapp.database.daoobjekte.Koenigin;
import imkerapp.database.daos.BrutDao;
import imkerapp.database.daos.KoeniginDao;
import android.app.Activity;
import android.app.Instrumentation.ActivityMonitor;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.Button;
import android.widget.EditText;

public class KoeniginActivityTest extends
		ActivityInstrumentationTestCase2<KoeniginActivity> {
	
	KoeniginActivity koeniginActivity;
	Button speichern;
	Button historie;
	EditText zeichen;
	EditText rasse;
    EditText zuechter;
    EditText jahr;
    KoeniginDao koeniginDao;

	public KoeniginActivityTest() {
		super(KoeniginActivity.class);
	}

	protected void setUp() throws Exception {
		super.setUp();
		Config.getConfig().setBeutenId((long)20);
		koeniginActivity = this.getActivity();
		
		speichern = (Button) koeniginActivity.findViewById(R.id.koeniginSpeichern);
		historie =  (Button) koeniginActivity.findViewById(R.id.koeniginHistorie);
		
		zeichen = (EditText) koeniginActivity.findViewById(R.id.KoeniginZeichen);
		rasse = (EditText) koeniginActivity.findViewById(R.id.Koeniginrasse);
		jahr = (EditText) koeniginActivity.findViewById(R.id.Koeniginjahr);
		zuechter = (EditText) koeniginActivity.findViewById(R.id.Koeniginzuechter);
		
	}
	
	/**
	 * Pr�ft, ob in das Textfeld Zeichen richtig ein- und ausgelesen wird.
	 */
	public void testZeichen() {			  
		 	
	  	  assertEquals("Blau", zeichen.getText().toString());			  
		
	}
	
	
	/**
	 * Pr�ft, ob in das Textfeld Rasse richtig ein- und ausgelesen wird.
	 */
	public void testRasse() {			  
		 	
	  	  assertEquals("carnica", rasse.getText().toString());			  
		
	}
	
	/**
	 * Pr�ft, ob in das Textfeld Zeichen richtig ein- und ausgelesen wird.
	 */
	public void testJahr() {	
		
		final Date date = new Date(2013, 05, 4);
		
		koeniginActivity.runOnUiThread(new Runnable() {
		    public void run() {
		    	
		    	jahr.setText(date.toString());	     
		    }
		  });
		  getInstrumentation().waitForIdleSync();		
		 	
	  	  assertEquals(date.toString(), jahr.getText().toString());			  
		
	}
	
	/**
	 * Pr�ft, ob in das Textfeld Zeichen richtig ein- und ausgelesen wird.
	 */
	public void testZuechter() {			  
		 	
	  	  assertEquals("Grimm", zuechter.getText().toString());			  
		
	}
	
	/**
	 * Pr�ft, ob der Button Historie auch die entsprechende Activity �ffnet.
	 */
	public void testButtonHistorie() {
		// registriert die n�chste Activity
		ActivityMonitor activityMonitor = getInstrumentation().addMonitor(KoeniginHistorieActivity.class.getName(), null, false);
		
		koeniginActivity.runOnUiThread(new Runnable() {
			
			@Override
			public void run() {
				// klick Button und �ffne n�chste Activity
				historie.performClick();
				
			}
		});
		
		Activity historieActivity = getInstrumentation().waitForMonitor(activityMonitor);
		  // pr�ft, ob n�chste Activity ge�ffnet wird und schlie�t diese dann wieder
		  assertNotNull(historieActivity);
		  historieActivity .finish();
		
	}
	
	/**
	 * Pr�ft, ob der Button Speichern die Daten richtig abspeichert.
	 */
	public void testButtonSpeichern() {	
				
		koeniginActivity.runOnUiThread(new Runnable() {			
			
			@Override
			public void run() {			
				

				boolean result = true;
				speichern.performClick();	
				assertTrue(result);	
				
			}
		});
		
		koeniginDao = DatabaseManager.getInstance().getKoeniginDao();
		
		String columnName = KoeniginDao.Properties.BeutenId.columnName;
		
		List<Koenigin> listresult = koeniginDao.queryDeep("Where T."+ columnName +"=?", "20");

		
	
		assertEquals("Blau", listresult.get(0).getZeichen().toString());
		assertEquals("Grimm", listresult.get(0).getZuechter().toString());
		assertEquals("carnica", listresult.get(0).getRasse().toString());
		
		
		
	}
	
	/**
	 * Pr�ft, ob der Text, welcher ge�ndert wurde, auch richtig abgespeichert
	 * wird.
	 */
	public void testAenderungen() {
		
		//setup
		koeniginDao = DatabaseManager.getInstance().getKoeniginDao();
		koeniginDao.deleteAll();
		Koenigin testkoenigin = new Koenigin((long)17, new Date(2012,8,13), "gr�n", "carnica", "Lustig", new Date(2012,7,3), 20);
		koeniginDao.insert(testkoenigin);
		
		//change
	    testkoenigin.setRasse("carnica");
	    testkoenigin.setZeichen("Blau");
	    testkoenigin.setZuechter("Grimm");
		
		koeniginDao.update(testkoenigin);
		
		//check
		String columnName = BrutDao.Properties.Id.columnName;
		List<Koenigin> result = koeniginDao.queryDeep("Where T."+ columnName +" =? ", "17");
		
		assertEquals("Blau", result.get(0).getZeichen().toString());
		assertEquals("Grimm", result.get(0).getZuechter().toString());
		assertEquals("carnica", result.get(0).getRasse().toString());
		
		}
	

}
