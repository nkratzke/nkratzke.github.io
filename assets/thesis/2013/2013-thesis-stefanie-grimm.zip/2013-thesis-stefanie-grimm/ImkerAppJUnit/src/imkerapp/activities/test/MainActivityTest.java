package imkerapp.activities.test;

import com.example.imkerapp.R;

import imkerapp.activities.MainActivity;
import imkerapp.activities.MenuActivity;
import imkerapp.activities.NeueBeuteActivity;
import imkerapp.activities.UebersichtBeutenActivity;
import android.app.Activity;
import android.app.Instrumentation.ActivityMonitor;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.Button;
import android.widget.EditText;

public class MainActivityTest extends
		ActivityInstrumentationTestCase2<MainActivity> {

	MainActivity mainActivity;
	Button beuteAnlegen;
	Button Ok;
	EditText beutennummer;
	EditText standort;
	CharSequence beutenummerText;
	CharSequence standortText;

	public MainActivityTest() {
		super(MainActivity.class);
	}

	protected void setUp() throws Exception {
		super.setUp();

		// Config.getConfig().setBeutenId((long)20);
		mainActivity = this.getActivity();

		beuteAnlegen = (Button) mainActivity
				.findViewById(R.id.buttonBeuteanlegen);
		Ok = (Button) mainActivity.findViewById(R.id.buttonOK);
		beutennummer = (EditText) mainActivity.findViewById(R.id.beutennummer);
		standort = (EditText) mainActivity.findViewById(R.id.standort);

	}

	/**
	 * Pr�ft, ob der Button Anlegen die richtige Activity �ffnet.
	 */
	public void testButtonBeuteAnlegen() {
		// registriert die n�chste Activity
		ActivityMonitor activityMonitor = getInstrumentation().addMonitor(
				NeueBeuteActivity.class.getName(), null, false);

		mainActivity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// klick Button und �ffne n�chste Activity
				beuteAnlegen.performClick();

			}
		});

		Activity beuteAnlegenActivity = getInstrumentation().waitForMonitor(
				activityMonitor);
		// pr�ft, ob n�chste Activity ge�ffnet wird und schlie�t diese dann
		// wieder
		assertNotNull(beuteAnlegenActivity);
		beuteAnlegenActivity.finish();

	}

	/**
	 * Pr�ft, ob der Button OK die richtige Activity �ffnet.
	 */
	public void testButtonOKBeute() {

		beutenummerText = "20";

		// registriert die n�chste Activity
		ActivityMonitor activityMonitor = getInstrumentation().addMonitor(
				MenuActivity.class.getName(), null, false);

		mainActivity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// klick Button und �ffne n�chste Activity
				beutennummer.setText(beutenummerText.toString());

				Ok.performClick();

			}
		});

		Activity menuActivity = getInstrumentation().waitForMonitor(
				activityMonitor);
		// pr�ft, ob n�chste Activity ge�ffnet wird und schlie�t diese dann
		// wieder
		assertNotNull(menuActivity);
		menuActivity.finish();

	}

	/**
	 * Pr�ft, ob der Button OK, wenn ein Standort eingetragen ist, die richtige
	 * Activity �ffnet.
	 */
	public void testButtonOKStandort() {

		standortText = "Hagenow";

		// registriert die n�chste Activity
		ActivityMonitor activityMonitor = getInstrumentation().addMonitor(
				UebersichtBeutenActivity.class.getName(), null, false);

		mainActivity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// klick Button und �ffne n�chste Activity
				standort.setText(standortText.toString());

				Ok.performClick();

			}
		});

		Activity uebersichtBeutenActivity = getInstrumentation()
				.waitForMonitor(activityMonitor);
		// pr�ft, ob n�chste Activity ge�ffnet wird und schlie�t diese dann
		// wieder
		assertNotNull(uebersichtBeutenActivity);
		uebersichtBeutenActivity.finish();

	}

	/**
	 * Pr�ft, ob der Button OK, wenn beide Textfelder leer sind, nichts tut.
	 */
	public void testButtonOKLeer() {
		mainActivity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				Ok.performClick();

			}
		});

		assertTrue(true);

	}

}
