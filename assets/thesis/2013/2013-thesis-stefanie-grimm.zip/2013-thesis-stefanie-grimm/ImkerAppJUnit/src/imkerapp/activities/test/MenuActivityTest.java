/**
 * 
 */
package imkerapp.activities.test;

import com.example.imkerapp.R;

import imkerapp.activities.AnmerkungActivity;
import imkerapp.activities.BrutActivity;
import imkerapp.activities.KoeniginActivity;
import imkerapp.activities.MenuActivity;
import imkerapp.activities.StatusActivity;
import imkerapp.activities.StockbauActivity;
import imkerapp.activities.VersorgungActivity;
import imkerapp.database.Config;
import android.app.Activity;
import android.app.Instrumentation.ActivityMonitor;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.Button;

/**
 * @author Stefanie
 * 
 */
public class MenuActivityTest extends
		ActivityInstrumentationTestCase2<MenuActivity> {

	MenuActivity menuActivity;
	/* Button Stockbau */
	private Button buttonStockbau;
	/* Button Status */
	private Button buttonStatus;
	/* Button K�nigin */
	private Button buttonKoenigin;
	/* Button Versorgung */
	private Button buttonVersorgung;
	/* Button Brut */
	private Button buttonBrut;
	/* Button Anmerkung */
	private Button buttonAnmerkung;

	public MenuActivityTest() {
		super(MenuActivity.class);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.test.ActivityInstrumentationTestCase2#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		Config.getConfig().setBeutenId((long) 20);

		menuActivity = this.getActivity();

		buttonStockbau = (Button) menuActivity
				.findViewById(R.id.buttonStockbau);
		buttonStatus = (Button) menuActivity.findViewById(R.id.buttonStatus);
		buttonKoenigin = (Button) menuActivity
				.findViewById(R.id.buttonKoenigin);
		buttonVersorgung = (Button) menuActivity
				.findViewById(R.id.buttonVersorgung);
		buttonBrut = (Button) menuActivity.findViewById(R.id.buttonbrut);
		buttonAnmerkung = (Button) menuActivity
				.findViewById(R.id.buttonanmerkung);

	}

	/**
	 * Pr�ft, ob der Button Stockbau die richtige Activity �ffnet.
	 */
	public void testButtonStockbau() {
		// registriert die n�chste Activity
		ActivityMonitor activityMonitor = getInstrumentation().addMonitor(
				StockbauActivity.class.getName(), null, false);

		menuActivity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// klick Button und �ffne n�chste Activity
				buttonStockbau.performClick();

			}
		});

		Activity stockbauActivity = getInstrumentation().waitForMonitor(
				activityMonitor);
		// pr�ft, ob n�chste Activity ge�ffnet wird und schlie�t diese dann
		// wieder
		assertNotNull(stockbauActivity);
		stockbauActivity.finish();

	}

	/**
	 * Pr�ft, ob der Button Status die richtige Activity �ffnet.
	 */
	public void testButtonStatus() {
		// registriert die n�chste Activity
		ActivityMonitor activityMonitor = getInstrumentation().addMonitor(
				StatusActivity.class.getName(), null, false);

		menuActivity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// klick Button und �ffne n�chste Activity
				buttonStatus.performClick();

			}
		});

		Activity statusActivity = getInstrumentation().waitForMonitor(
				activityMonitor);
		// pr�ft, ob n�chste Activity ge�ffnet wird und schlie�t diese dann
		// wieder
		assertNotNull(statusActivity);
		statusActivity.finish();

	}

	/**
	 * Pr�ft, ob der Button K�nigin die richtige Activity �ffnet.
	 */
	public void testButtonKoenigin() {
		// registriert die n�chste Activity
		ActivityMonitor activityMonitor = getInstrumentation().addMonitor(
				KoeniginActivity.class.getName(), null, false);

		menuActivity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// klick Button und �ffne n�chste Activity
				buttonKoenigin.performClick();

			}
		});

		Activity koeniginActivity = getInstrumentation().waitForMonitor(
				activityMonitor);
		// pr�ft, ob n�chste Activity ge�ffnet wird und schlie�t diese dann
		// wieder
		assertNotNull(koeniginActivity);
		koeniginActivity.finish();

	}

	/**
	 * Pr�ft, ob der Button Versorgung die richtige Activity �ffnet.
	 */
	public void testButtonVersorgung() {
		// registriert die n�chste Activity
		ActivityMonitor activityMonitor = getInstrumentation().addMonitor(
				VersorgungActivity.class.getName(), null, false);

		menuActivity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// klick Button und �ffne n�chste Activity
				buttonVersorgung.performClick();

			}
		});

		Activity versorgungActivity = getInstrumentation().waitForMonitor(
				activityMonitor);
		// pr�ft, ob n�chste Activity ge�ffnet wird und schlie�t diese dann
		// wieder
		assertNotNull(versorgungActivity);
		versorgungActivity.finish();

	}

	/**
	 * Pr�ft, ob der Button Brut die richtige Activity �ffnet.
	 */
	public void testButtonBrut() {
		// registriert die n�chste Activity
		ActivityMonitor activityMonitor = getInstrumentation().addMonitor(
				BrutActivity.class.getName(), null, false);

		menuActivity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// klick Button und �ffne n�chste Activity
				buttonBrut.performClick();

			}
		});

		Activity brutActivity = getInstrumentation().waitForMonitor(
				activityMonitor);
		// pr�ft, ob n�chste Activity ge�ffnet wird und schlie�t diese dann
		// wieder
		assertNotNull(brutActivity);
		brutActivity.finish();

	}

	/**
	 * Pr�ft, ob der Button Anmerkung die richtige Activity �ffnet.
	 */
	public void testButtonAnmerkung() {
		// registriert die n�chste Activity
		ActivityMonitor activityMonitor = getInstrumentation().addMonitor(
				AnmerkungActivity.class.getName(), null, false);

		menuActivity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// klick Button und �ffne n�chste Activity
				buttonAnmerkung.performClick();

			}
		});

		Activity anmerkungActivity = getInstrumentation().waitForMonitor(
				activityMonitor);
		// pr�ft, ob n�chste Activity ge�ffnet wird und schlie�t diese dann
		// wieder
		assertNotNull(anmerkungActivity);
		anmerkungActivity.finish();

	}

}
