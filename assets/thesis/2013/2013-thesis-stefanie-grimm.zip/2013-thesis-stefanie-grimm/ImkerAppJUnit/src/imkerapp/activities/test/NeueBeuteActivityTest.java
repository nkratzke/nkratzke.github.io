package imkerapp.activities.test;

import imkerapp.activities.NeueBeuteActivity;
import imkerapp.database.DatabaseManager;
import imkerapp.database.daoobjekte.Beute;
import imkerapp.database.daoobjekte.Koenigin;
import imkerapp.database.daos.BeuteDao;
import imkerapp.database.daos.KoeniginDao;
import imkerapp.database.daos.StandortDao;

import java.util.Date;
import java.util.List;

import com.example.imkerapp.R;

import android.test.ActivityInstrumentationTestCase2;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

public class NeueBeuteActivityTest extends
		ActivityInstrumentationTestCase2<NeueBeuteActivity> {

	
	/*Textfeld Standort*/
    private EditText neueBeuteStandort;
    /*Textfeld Zeichen*/
    private EditText neueBeuteZeichen;
    /*Textfeld Z�chter*/
    private EditText neueBeuteZuechter;
    /*Textfeld Beutennummer*/
    private EditText neueBeutebeutennummer;
    /*Textfeld Rasse*/
    private EditText neueBeuteRasse;
    /*Textfeld Jahrgang*/
    private EditText neueBeuteJahrgang;
    /*Button Speichern*/
    private Button speichern; 
	NeueBeuteActivity neueBeuteActivity;
	StandortDao standortDao;
	Button datum;
	
	Date jahrgang = new Date();
	

	public NeueBeuteActivityTest() {
		super(NeueBeuteActivity.class);		
	}

	/** 
	 * @see android.test.ActivityInstrumentationTestCase2#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();	
//		Config.getConfig().setBeutenId((long)20);
		neueBeuteActivity=this.getActivity();		
		
		speichern = (Button) neueBeuteActivity.findViewById(R.id.neueBeutebuttonSpeichern);
		neueBeuteStandort = (EditText) neueBeuteActivity.findViewById(R.id.neueBeuteStandort);
		neueBeuteZeichen = (EditText) neueBeuteActivity.findViewById(R.id.neueBeuteKoeniginZeichen);
		neueBeuteZuechter = (EditText) neueBeuteActivity.findViewById(R.id.neueBeuteKoeniginZuechter);
		neueBeutebeutennummer = (EditText) neueBeuteActivity.findViewById(R.id.neueBeuteNummer);
		neueBeuteRasse = (EditText) neueBeuteActivity.findViewById(R.id.neueBeuteKoeniginRasse);
		neueBeuteJahrgang = (EditText) neueBeuteActivity.findViewById(R.id.neueBeuteKoeniginJahrgang);	
		datum = (Button) neueBeuteActivity.findViewById(R.id.neueBeuteDatumAuswaehlen);
		 
	}

	

	/**
	 * Pr�ft, ob der Button Speichern die Daten richtig abspeichert.
	 */
	public void testButtonSpeichern() {		
		
		neueBeuteActivity.runOnUiThread(new Runnable() {			
			
			@Override
			public void run() {
				String standort = "Kiel";
				String zeichen = "Gr�n";
				String zuechter = "Grimm";
				String rasse ="carnica";
				String beutennummer = "21";				
				
				neueBeutebeutennummer.setText(beutennummer);

//				Log.i("Nummer", neueBeutebeutennummer.getText().toString());
				neueBeuteJahrgang.setText(jahrgang.toString());
				
				
				
//				neueBeuteActivity.runOnUiThread(new Runnable() {
//					
//					@Override
//					public void run() {
//						datum.performClick();						
//						
//					}
//			});
			
				Log.i("Jahr", neueBeuteJahrgang.getText().toString());
				neueBeuteRasse.setText(rasse);
				neueBeuteStandort.setText(standort);				
				neueBeuteZeichen.setText(zeichen);
				Log.i("Zeichen", neueBeuteZeichen.getText().toString());
				neueBeuteZuechter.setText(zuechter);
						
				
				
				boolean result = true;
				speichern.performClick();	
				assertTrue(result);	
				
			}
		});
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BeuteDao beuteDao = DatabaseManager.getInstance().getBeuteDao();		
		String columnName = BeuteDao.Properties.Id.columnName;		
		List<Beute> beuteresult = beuteDao.queryDeep("Where T."+ columnName +"=?", "21");
		
		assertEquals("21", beuteresult.get(0).getId().toString());	
		
		KoeniginDao koeniginDao = DatabaseManager.getInstance().getKoeniginDao();
		String columnNameKoenigin = KoeniginDao.Properties.BeutenId.columnName;
		List <Koenigin> koeniginres = koeniginDao.queryDeep("Where T."+ columnNameKoenigin + "=?", "21");
		
		assertEquals("Gr�n", koeniginres.get(0).getZeichen().toString());
		assertEquals("Grimm", koeniginres.get(0).getZuechter().toString());
		assertEquals("carnica", koeniginres.get(0).getRasse().toString());
	
	
		
		
		
				
		
	}

}
