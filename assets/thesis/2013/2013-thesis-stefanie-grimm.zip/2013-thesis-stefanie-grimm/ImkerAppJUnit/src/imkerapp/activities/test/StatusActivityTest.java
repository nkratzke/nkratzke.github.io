package imkerapp.activities.test;

import java.util.Date;
import java.util.List;

import com.example.imkerapp.R;

import imkerapp.activities.StatusActivity;
import imkerapp.activities.StatusHistorieActivity;
import imkerapp.database.Config;
import imkerapp.database.DatabaseManager;
import imkerapp.database.daoobjekte.Status;
import imkerapp.database.daos.BrutDao;
import imkerapp.database.daos.StatusDao;
import android.app.Activity;
import android.app.Instrumentation.ActivityMonitor;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.Button;
import android.widget.EditText;

public class StatusActivityTest extends ActivityInstrumentationTestCase2<StatusActivity> {

	private StatusActivity statusActivity;
	private Button historie;
	private Button speichern;
	/*Textfeld Futterwaben*/
	private EditText futter;
	/*Textfeld Sanftmut*/
	private EditText sanftmut;
	/*Textfeld Wabensitz*/
	private EditText wabensitz;
	/*Textfeld Honigleistung*/
	private EditText honigleistung;
	StatusDao statusDao;
	
	public StatusActivityTest() {
		super(StatusActivity.class);
	}

	protected void setUp() throws Exception {
		super.setUp();
		Config.getConfig().setBeutenId((long)20);		
		statusActivity=this.getActivity();	
		
		historie = (Button) statusActivity.findViewById(R.id.statusHistorie);
		speichern = (Button) statusActivity.findViewById(R.id.statusSpeichern);
		futter = (EditText) statusActivity.findViewById(R.id.Futter);
		sanftmut = (EditText) statusActivity.findViewById(R.id.Sanftmut);
		wabensitz = (EditText) statusActivity.findViewById(R.id.Wabensitz);
		honigleistung = (EditText) statusActivity.findViewById(R.id.honigleistung);
		
	}
	
	/**
	 * Pr�ft, ob in das Textfeld Futter richtig ausgelesen wird.
	 */
	public void testFutter() {		  
		 	
	  	  assertEquals("1", futter.getText().toString());			  
		
	}
	
	/**
	 * Pr�ft, ob in das Textfeld Sanftmut richtig ausgelesen wird.
	 */
	public void testSantmut() {		  
		 	
	  	  assertEquals("gut", sanftmut.getText().toString());			  
		
	}
	
	/**
	 * Pr�ft, ob in das Textfeld Wabensitz richtig ausgelesen wird.
	 */
	public void testWabensitz() {		  
		 	
	  	  assertEquals("2", wabensitz.getText().toString());			  
		
	}
	
	/**
	 * Pr�ft, ob in das Textfeld Honigleistung richtig ausgelesen wird.
	 */
	public void testHonigleistung() {		  
		 	
	  	  assertEquals("100", honigleistung.getText().toString());			  
		
	}
	

	/**
	 * Pr�ft, ob der Button Historie auch die entsprechende Activity �ffnet.
	 */
	public void testButtonHistorie() {
		// registriert die n�chste Activity
		ActivityMonitor activityMonitor = getInstrumentation().addMonitor(StatusHistorieActivity.class.getName(), null, false);
		
		statusActivity.runOnUiThread(new Runnable() {
			
			@Override
			public void run() {
				// klick Button und �ffne n�chste Activity
				historie.performClick();
				
			}
		});
		
		Activity historieActivity = getInstrumentation().waitForMonitor(activityMonitor);
		  // pr�ft, ob n�chste Activity ge�ffnet wird und schlie�t diese dann wieder
		  assertNotNull(historieActivity);
		  historieActivity .finish();
		
	}
	
	/**
	 * Pr�ft, ob der Button Speichern die Daten richtig abspeichert.
	 */
	public void testButtonSpeichern() {	
				
		statusActivity.runOnUiThread(new Runnable() {			
			
			@Override
			public void run() {	
				
				

				boolean result = true;
				speichern.performClick();	
				assertTrue(result);	
				
			}
		});
		
		statusDao = DatabaseManager.getInstance().getStatusDao();
		
		String columnName = StatusDao.Properties.BeutenId.columnName;
		
		List<Status> listresult = statusDao.queryDeep("Where T."+ columnName +"=?", "20");

		
		assertEquals("gut", listresult.get(0).getSanftmut().toString());
		assertEquals("1", listresult.get(0).getFutterwaben().toString());
		assertEquals("2", listresult.get(0).getWabensitz().toString());
		assertEquals("10", listresult.get(0).getHonigleistung().toString());
		
	}
	
	/**
	 * Pr�ft, ob der Text, welcher ge�ndert wurde, auch richtig abgespeichert
	 * wird.
	 */
	public void testAenderungen() {
		
		//setup
		statusDao = DatabaseManager.getInstance().getStatusDao();
		statusDao.deleteAll();
		Status teststatus = new Status((long)16, new Date(2013, 4, 4), 10, 3, 3, "befriedigend", 20);
		statusDao.insert(teststatus);
		
		//change
		teststatus.setFutterwaben(1);
		teststatus.setSanftmut("gut");
		teststatus.setWabensitz(2);
		teststatus.setHonigleistung(10);
		
		statusDao.update(teststatus);
		
		//check
		String columnName = BrutDao.Properties.Id.columnName;
		List<Status> result = statusDao.queryDeep("Where T."+ columnName +" =? ", "16");
		
		assertEquals("gut", result.get(0).getSanftmut().toString());
		assertEquals("1", result.get(0).getFutterwaben().toString());
		assertEquals("2", result.get(0).getWabensitz().toString());
		assertEquals("10", result.get(0).getHonigleistung().toString());
		
		}
	
	
	
	
	
}
