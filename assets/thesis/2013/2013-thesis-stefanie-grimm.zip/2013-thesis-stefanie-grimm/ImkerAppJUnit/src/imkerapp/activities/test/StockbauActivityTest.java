package imkerapp.activities.test;

import java.util.Date;
import java.util.List;

import com.example.imkerapp.R;

import imkerapp.activities.StockbauActivity;
import imkerapp.activities.StockbauHistorieActivity;
import imkerapp.database.Config;
import imkerapp.database.DatabaseManager;
import imkerapp.database.daoobjekte.Stockbau;
import imkerapp.database.daos.BrutDao;
import imkerapp.database.daos.StockbauDao;
import android.app.Activity;
import android.app.Instrumentation.ActivityMonitor;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.Button;
import android.widget.EditText;

public class StockbauActivityTest extends
		ActivityInstrumentationTestCase2<StockbauActivity> {

	StockbauActivity stockbauActivity;
	/* Textfeld Brutwaben */
	private EditText brutwaben;
	/* Textfeld Mittelwaende */
	private EditText mittelweande;
	/* Textfeld Waben */
	private EditText waben;
	/* Button zum Speichern */
	private Button speichern;
	/* Button f�r Historie */
	private Button historie;
	private StockbauDao stockbauDao;

	public StockbauActivityTest() {
		super(StockbauActivity.class);
	}

	protected void setUp() throws Exception {
		super.setUp();

		Config.getConfig().setBeutenId((long) 20);
		stockbauActivity = this.getActivity();

		historie = (Button) stockbauActivity
				.findViewById(R.id.stockbauHistorie);
		speichern = (Button) stockbauActivity
				.findViewById(R.id.stockbauSpeichern);
		brutwaben = (EditText) stockbauActivity
				.findViewById(R.id.StockbauBrutwabe);
		mittelweande = (EditText) stockbauActivity
				.findViewById(R.id.Stockbaumittelwaende);
		waben = (EditText) stockbauActivity.findViewById(R.id.Stockbauwaben);
	}

	/**
	 * Pr�ft, ob in das Textfeld Brutwaben richtig ein- und ausgelesen wird.
	 */
	public void testBrutwaben() {

		assertEquals("10", brutwaben.getText().toString());

	}

	/**
	 * Pr�ft, ob in das Textfeld Mittelwaende richtig ein- und ausgelesen wird.
	 */
	public void testMittelwaende() {

		assertEquals("2", mittelweande.getText().toString());

	}

	/**
	 * Pr�ft, ob in das Textfeld Waben richtig ein- und ausgelesen wird.
	 */
	public void testWaben() {

		assertEquals("10", waben.getText().toString());

	}

	/**
	 * Pr�ft, ob der Button Historie auch die entsprechende Activity �ffnet.
	 */
	public void testButtonHistorie() {
		// registriert die n�chste Activity
		ActivityMonitor activityMonitor = getInstrumentation().addMonitor(
				StockbauHistorieActivity.class.getName(), null, false);

		stockbauActivity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// klick Button und �ffne n�chste Activity
				historie.performClick();

			}
		});

		Activity historieActivity = getInstrumentation().waitForMonitor(
				activityMonitor);
		// pr�ft, ob n�chste Activity ge�ffnet wird und schlie�t diese dann
		// wieder
		assertNotNull(historieActivity);
		historieActivity.finish();

	}

	/**
	 * Pr�ft, ob der Button Speichern die Daten richtig abspeichert.
	 */
	public void testButtonSpeichern() {

		stockbauActivity.runOnUiThread(new Runnable() {

			@Override
			public void run() {

				boolean result = true;
				speichern.performClick();
				assertTrue(result);

			}
		});

		stockbauDao = DatabaseManager.getInstance().getStockbauDao();

		String columnName = StockbauDao.Properties.BeutenId.columnName;

		List<Stockbau> listresult = stockbauDao.queryDeep("Where T."
				+ columnName + "=?", "20");

		assertEquals("2", listresult.get(0).getMittelwaende().toString());
		assertEquals("10", listresult.get(0).getBrutwaben().toString());
		assertEquals("10", listresult.get(0).getWaben().toString());

	}

	/**
	 * Pr�ft, ob der Text, welcher ge�ndert wurde, auch richtig abgespeichert
	 * wird.
	 */
	public void testAenderungen() {

		// setup
		stockbauDao = DatabaseManager.getInstance().getStockbauDao();
		stockbauDao.deleteAll();
		Stockbau teststockbau = new Stockbau((long) 15, new Date(2012, 9, 11),
				4, 3, 8, 20);
		stockbauDao.insert(teststockbau);

		// change
		teststockbau.setBrutwaben(10);
		teststockbau.setMittelwaende(2);
		teststockbau.setWaben(10);

		stockbauDao.update(teststockbau);

		// check
		String columnName = BrutDao.Properties.Id.columnName;
		List<Stockbau> result = stockbauDao.queryDeep("Where T." + columnName
				+ " =? ", "15");

		assertEquals("2", result.get(0).getMittelwaende().toString());
		assertEquals("10", result.get(0).getBrutwaben().toString());
		assertEquals("10", result.get(0).getWaben().toString());

	}

}
