package imkerapp.activities.test;

import java.util.Date;
import java.util.List;

import com.example.imkerapp.R;

import imkerapp.activities.VersorgungActivity;
import imkerapp.activities.VersorgungHistorieActivity;
import imkerapp.database.Config;
import imkerapp.database.DatabaseManager;
import imkerapp.database.daoobjekte.Versorgung;
import imkerapp.database.daos.BrutDao;
import imkerapp.database.daos.StockbauDao;
import imkerapp.database.daos.VersorgungDao;
import android.app.Activity;
import android.app.Instrumentation.ActivityMonitor;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.Button;
import android.widget.EditText;

public class VersorgungActivityTest extends
		ActivityInstrumentationTestCase2<VersorgungActivity> {

	VersorgungActivity versorgungActivity;
	/* Textfeld Honig */
	private EditText honig;
	/* Textfeld Zucker */
	private EditText zucker;
	/* Button zum Speichern */
	private Button speichern;
	/* Button f�r Historie */
	private Button historie;
	VersorgungDao versorgungDao;

	public VersorgungActivityTest() {
		super(VersorgungActivity.class);
	}

	protected void setUp() throws Exception {
		super.setUp();
		Config.getConfig().setBeutenId((long) 20);
		versorgungActivity = this.getActivity();

		historie = (Button) versorgungActivity
				.findViewById(R.id.versorgungHistorie);
		speichern = (Button) versorgungActivity
				.findViewById(R.id.versorgungSpeichern);
		honig = (EditText) versorgungActivity
				.findViewById(R.id.versorgungHonig);
		zucker = (EditText) versorgungActivity
				.findViewById(R.id.versorgungZucker);
	}

	/**
	 * Pr�ft, ob in das Textfeld Honig richtig ein- und ausgelesen wird.
	 */
	public void testHonig() {

		assertEquals("10", honig.getText().toString());

	}

	/**
	 * Pr�ft, ob in das Textfeld Zucker richtig ein- und ausgelesen wird.
	 */
	public void testZucker() {

		assertEquals("12", zucker.getText().toString());

	}

	/**
	 * Pr�ft, ob der Button Historie auch die entsprechende Activity �ffnet.
	 */
	public void testButtonHistorie() {
		// registriert die n�chste Activity
		ActivityMonitor activityMonitor = getInstrumentation().addMonitor(
				VersorgungHistorieActivity.class.getName(), null, false);

		versorgungActivity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// klick Button und �ffne n�chste Activity
				historie.performClick();

			}
		});

		Activity historieActivity = getInstrumentation().waitForMonitor(
				activityMonitor);
		// pr�ft, ob n�chste Activity ge�ffnet wird und schlie�t diese dann
		// wieder
		assertNotNull(historieActivity);
		historieActivity.finish();

	}

	/**
	 * Pr�ft, ob der Button Speichern die Daten richtig abspeichert.
	 */
	public void testButtonSpeichern() {

		versorgungActivity.runOnUiThread(new Runnable() {

			@Override
			public void run() {

				boolean result = true;
				speichern.performClick();
				assertTrue(result);

			}
		});

		versorgungDao = DatabaseManager.getInstance().getVersorgungDao();

		String columnName = StockbauDao.Properties.BeutenId.columnName;

		List<Versorgung> listresult = versorgungDao.queryDeep("Where T."
				+ columnName + "=?", "20");

		assertEquals("10", listresult.get(0).getHonig().toString());
		assertEquals("12", listresult.get(0).getZucker().toString());

	}

	/**
	 * Pr�ft, ob der Text, welcher ge�ndert wurde, auch richtig abgespeichert
	 * wird.
	 */
	public void testAenderungen() {

		// setup
		versorgungDao = DatabaseManager.getInstance().getVersorgungDao();
		versorgungDao.deleteAll();
		Versorgung testversorgung = new Versorgung((long) 14, new Date(2012, 6,
				11), 5, 3, 20);
		versorgungDao.insert(testversorgung);

		// change
		testversorgung.setHonig(10);
		testversorgung.setZucker(12);

		versorgungDao.update(testversorgung);

		// check
		String columnName = BrutDao.Properties.Id.columnName;
		List<Versorgung> result = versorgungDao.queryDeep("Where T."
				+ columnName + " =? ", "14");

		assertEquals("10", result.get(0).getHonig().toString());
		assertEquals("12", result.get(0).getZucker().toString());

	}

}
