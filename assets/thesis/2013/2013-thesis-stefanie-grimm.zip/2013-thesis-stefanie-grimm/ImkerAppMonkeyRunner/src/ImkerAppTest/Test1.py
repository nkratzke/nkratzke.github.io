'''
Created on 02.08.2013

@author: Stefanie
'''

from com.android.monkeyrunner import MonkeyRunner, MonkeyDevice

device = MonkeyRunner.waitForConnection()

device.installPackage('C:/Users/Stefanie/Documents/Bachelorarbeit/TestenBA/ImkerApp/bin/ImkerApp.apk')

package = 'com.example.android.imkerapp.activities'

activity= 'com.example.android.imkerapp.activities.MenuActivity'

runComponent = package + '/' + activity

device.startActivity(component=runComponent)

device.press('KEYCODE_MENU', MonkeyDevice.DOWN_AND_UP)

result= device.takeSnapshot()

result.writeToFile('C:/Users/Stefanie/Documents/Bachelorarbeit/TestenBA/shot.png', 'png')

