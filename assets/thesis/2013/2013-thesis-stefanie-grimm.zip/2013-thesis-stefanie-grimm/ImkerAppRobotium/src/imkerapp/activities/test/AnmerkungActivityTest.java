package imkerapp.activities.test;

import com.example.imkerapp.R;
import com.jayway.android.robotium.solo.Solo;

import imkerapp.activities.AnmerkungActivity;
import imkerapp.activities.AnmerkungenHistorieActivity;
import imkerapp.database.Config;
import android.test.ActivityInstrumentationTestCase2;
import android.view.View;
import android.widget.EditText;

public class AnmerkungActivityTest extends
		ActivityInstrumentationTestCase2<AnmerkungActivity> {

	// Soloklasse von Robotium, um UI-Elemente zu testen
	private Solo solo;
	// Anmerkung Activity
	private AnmerkungActivity anmerkungActivity;

	public AnmerkungActivityTest() {
		super("imkerapp.activities", AnmerkungActivity.class);
	}

	/**
	 * Die setUp() Methode wird vor dem start jeder Testmthode ausgef�hrt. In
	 * diesem Fall bekommt die Klasse die BeutenID 20 �bergeben und es wird die
	 * zu testende Activity geholt und dem Klassenobjekt solo �bergeben.
	 */
	protected void setUp() throws Exception {
		super.setUp();
		Config.getConfig().setBeutenId((long) 20);

		anmerkungActivity = getActivity();
		solo = new Solo(getInstrumentation(), getActivity());
	}

	/**
	 * Die Methode pr�ft das Textfeld in welches die Anmerkungen geschreiebn
	 * werden. Es wird �berpr�ft, ob in das Textfeld geschrieben werden kann, ob
	 * dieses auch wieder ausgelesen werden kann und ob es auf der Oberfl�che
	 * �berhaupt sichtbar ist.
	 */
	public void testTextfeld() {
		// Textfeld holen
		EditText text = (EditText) solo.getView(R.id.anmerkungTexte);
		// Text l�schen, falls einer drin steht
		solo.clearEditText(text);
		// Text hineinschreiben
		solo.enterText(text, "gegen Varo behandelt");
		// Ist Textfeld auf Oberfl�che sichtbar?
		assertEquals(View.VISIBLE, text.getVisibility());
		// Ist der der Text der drin steht, auch der der reingeschrieben wurde?
		assertEquals("gegen Varo behandelt", text.getText().toString());

	}

	/**
	 * Diese Methode pr�ft den Button Historie, ob dieser auch wirklich die
	 * n�chste Activityy �ffnet.
	 */
	public void testButtonHistorie() {

		// Klcik auf mit Text "Historie"
		solo.clickOnButton("Historie");

		// Warte auf n�chste zu �ffnende Activity
		solo.waitForActivity("AnmerkungHistorieActivity");
		// Pr�fe, ob die ge�ffnete Activitx auch die richtige ist
		solo.assertCurrentActivity("AnmerkungHistorieActivity...",
				AnmerkungenHistorieActivity.class);

	}

	/**
	 * Diese Methode pr�ft, ob der Button seine Funktionalit�t erf�llt. Nachdem
	 * ein Klcik auf dem Button ausgef�hrt wurde, wird ein Dialogfenster
	 * ge�ffnet. Es wird also gepr�ft, ob der Text des Dialogfensters auch auf
	 * der oberfl�che erscheint.
	 */
	public void testSpeichern() {

		// pr�ft, ob die richtige Activity ausgew�hlt ist
		solo.assertCurrentActivity("wrong activity", AnmerkungActivity.class);
		// klick auf den Button Speichern
		solo.clickOnButton("Speichern");
		// Pr�fen, ob der erw�nschte Text auf der Oberfl�che erscheint
		assertTrue(solo.waitForText("Ihre Daten wurden gespeichert!"));

	}

	/**
	 * Beendet die gestartete Activity.
	 */
	@Override
	public void tearDown() throws Exception {

		solo.finishOpenedActivities();
		super.tearDown();

	}

}
