package imkerapp.activities.test;

import com.example.imkerapp.R;
import com.jayway.android.robotium.solo.Solo;

import imkerapp.activities.BrutActivity;
import imkerapp.activities.BrutHistorieActivity;
import imkerapp.database.Config;
import android.test.ActivityInstrumentationTestCase2;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;

public class BrutActivityTest extends
		ActivityInstrumentationTestCase2<BrutActivity> {

	private Solo solo;
	private BrutActivity brutActivity;

	public BrutActivityTest() {
		super("imkerapp.activities", BrutActivity.class);
	}

	/**
	 * Die setUp() Methode wird vor dem start jeder Testmthode ausgef�hrt. In
	 * diesem Fall bekommt die Klasse die BeutenID 20 �bergeben und es wird die
	 * zu testende Activity geholt und dem Klassenobjekt solo �bergeben.
	 */
	protected void setUp() throws Exception {
		super.setUp();
		Config.getConfig().setBeutenId((long) 20);

		brutActivity = getActivity();
		solo = new Solo(getInstrumentation(), getActivity());
	}

	/**
	 * Die Methode pr�ft das Textfeld in welches die Anzahl der Eier geschrieben
	 * werden. Es wird �berpr�ft, ob in das Textfeld geschrieben werden kann, ob
	 * dieses auch wieder ausgelesen werden kann und ob es auf der Oberfl�che
	 * �berhaupt sichtbar ist.
	 */
	public void testTextEier() {
		EditText eier = (EditText) solo.getView(R.id.Bruteier);

		solo.clearEditText(eier);

		solo.enterText(eier, "2");

		assertEquals(View.VISIBLE, eier.getVisibility());
		assertEquals("2", eier.getText().toString());

	}

	/**
	 * Die Methode pr�ft das Textfeld in welches die Anzahl der offenen Brut
	 * geschrieben werden. Es wird �berpr�ft, ob in das Textfeld geschrieben
	 * werden kann, ob dieses auch wieder ausgelesen werden kann und ob es auf
	 * der Oberfl�che �berhaupt sichtbar ist.
	 */
	public void testTextOffen() {
		EditText offen = (EditText) solo.getView(R.id.Brutoffen);

		solo.clearEditText(offen);

		solo.enterText(offen, "4");

		assertEquals(View.VISIBLE, offen.getVisibility());
		assertEquals("4", offen.getText().toString());

	}

	/**
	 * Die Methode pr�ft das Textfeld in welches die Anzahl der verdeckelten
	 * Brut geschrieben werden. Es wird �berpr�ft, ob in das Textfeld
	 * geschrieben werden kann, ob dieses auch wieder ausgelesen werden kann und
	 * ob es auf der Oberfl�che �berhaupt sichtbar ist.
	 */
	public void testTextVerdeckelt() {
		EditText verdeckelt = (EditText) solo.getView(R.id.BrutVerdeckelt);

		solo.clearEditText(verdeckelt);

		solo.enterText(verdeckelt, "7");

		assertEquals(View.VISIBLE, verdeckelt.getVisibility());
		assertEquals("7", verdeckelt.getText().toString());

	}

	/**
	 * Die Methode pr�ft das Textfeld in welches die Anzahl der Waben
	 * geschrieben werden. Es wird �berpr�ft, ob in das Textfeld geschrieben
	 * werden kann, ob dieses auch wieder ausgelesen werden kann und ob es auf
	 * der Oberfl�che �berhaupt sichtbar ist.
	 */
	public void testTextWaben() {
		EditText waben = (EditText) solo.getView(R.id.Brutwaben);

		solo.clearEditText(waben);

		solo.enterText(waben, "0");

		assertEquals(View.VISIBLE, waben.getVisibility());
		assertEquals("0", waben.getText().toString());

	}

	/**
	 * Diese Methode pr�ft den Button Historie, ob dieser auch wirklich die
	 * n�chste Activity �ffnet.
	 */
	public void testButtonHistorie() {
		solo.goBack();

		solo.clickOnButton("Historie");

		solo.waitForActivity("BrutHistorieActivity");
		solo.assertCurrentActivity("BrutHistorieActivity...",
				BrutHistorieActivity.class);

		this.sendKeys(KeyEvent.KEYCODE_DPAD_CENTER);

	}

	/**
	 * Diese Methode pr�ft, ob der Button seine Funktionalit�t erf�llt. Nachdem
	 * ein Klick auf dem Button ausgef�hrt wurde, wird ein Dialogfenster
	 * ge�ffnet. Es wird also gepr�ft, ob der Text des Dialogfensters auch auf
	 * der Oberfl�che erscheint.
	 */
	public void testButtonSpeichern() {
		solo.goBack();

		solo.assertCurrentActivity("wrong activity", BrutActivity.class);
		solo.clickOnButton("Speichern");
		this.sendKeys(KeyEvent.KEYCODE_DPAD_CENTER);
		assertTrue(solo.waitForText("Ihre Daten wurden gespeichert!"));

	}

	/**
	 * Schlie�t alle ge�ffenten Activities und beendet die setUp()-Methode.
	 */
	@Override
	public void tearDown() throws Exception {

		solo.finishOpenedActivities();
		super.tearDown();

	}
}
