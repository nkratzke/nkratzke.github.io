package imkerapp.activities.test;

import com.example.imkerapp.R;
import com.jayway.android.robotium.solo.Solo;

import imkerapp.activities.KoeniginActivity;
import imkerapp.activities.KoeniginHistorieActivity;
import imkerapp.database.Config;
import android.test.ActivityInstrumentationTestCase2;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;

public class KoeniginActivityTest extends
		ActivityInstrumentationTestCase2<KoeniginActivity> {

	private Solo solo;
	private KoeniginActivity koeniginActivity;
	
	public KoeniginActivityTest() {
		super("imkerapp.activities", KoeniginActivity.class);
	}

	
	/**
	 * Die setUp() Methode wird vor dem start jeder Testmthode ausgef�hrt. In
	 * diesem Fall bekommt die Klasse die BeutenID 20 �bergeben und es wird die
	 * zu testende Activity geholt und dem Klassenobjekt solo �bergeben.
	 */
	protected void setUp() throws Exception {
		super.setUp();
		Config.getConfig().setBeutenId((long)20);
		
		koeniginActivity = getActivity();
		solo = new Solo(getInstrumentation(), getActivity());
	}

	/**
	 * Die Methode pr�ft das Textfeld in welches das Jahr des Einsetzten der 
	 * K�nigin in de Beute geschrieben werden. Es wird �berpr�ft, ob in das 
	 * Textfeld geschrieben werden kann, ob dieses auch wieder ausgelesen werden
	 *  kann und ob es auf der Oberfl�che �berhaupt sichtbar ist.
	 */
	public void testTextJahr() {
		EditText jahr = (EditText) solo.getView(R.id.Koeniginjahr);
		
		solo.clearEditText(jahr);
		
		solo.enterText(jahr, "09/06/2013");
		
		assertEquals(View.VISIBLE, jahr.getVisibility());
		assertEquals("09/06/2013", jahr.getText().toString());
		
	}
	
	/**
	 * Die Methode pr�ft das Textfeld in welches die Rasse der 
	 * K�nigin geschrieben wird. Es wird �berpr�ft, ob in das 
	 * Textfeld geschrieben werden kann, ob dieses auch wieder ausgelesen werden
	 *  kann und ob es auf der Oberfl�che �berhaupt sichtbar ist.
	 */
	public void testTextRasse() {
		EditText rasse = (EditText) solo.getView(R.id.Koeniginrasse);
		
		solo.clearEditText(rasse);
		
		solo.enterText(rasse, "aca");
		
		assertEquals(View.VISIBLE, rasse.getVisibility());
		assertEquals("aca", rasse.getText().toString());
		
	}
	
	/**
	 * Die Methode pr�ft das Textfeld in welches der Z�chter der 
	 * K�nigin geschrieben wird. Es wird �berpr�ft, ob in das 
	 * Textfeld geschrieben werden kann, ob dieses auch wieder ausgelesen werden
	 *  kann und ob es auf der Oberfl�che �berhaupt sichtbar ist.
	 */
	public void testTextZuechter() {
		EditText zuechter = (EditText) solo.getView(R.id.Koeniginzuechter);
		
		solo.clearEditText(zuechter);
		
		solo.enterText(zuechter, "Grimm");
		
		assertEquals(View.VISIBLE, zuechter.getVisibility());
		assertEquals("Grimm", zuechter.getText().toString());
		
	}
	
	/**
	 * Die Methode pr�ft das Textfeld in welches das Zeichen der 
	 * K�nigin geschrieben wird. Es wird �berpr�ft, ob in das 
	 * Textfeld geschrieben werden kann, ob dieses auch wieder ausgelesen werden
	 *  kann und ob es auf der Oberfl�che �berhaupt sichtbar ist.
	 */
	public void testTextZeichen() {
		EditText zeichen = (EditText) solo.getView(R.id.KoeniginZeichen);
		
		solo.clearEditText(zeichen);
		
		solo.enterText(zeichen, "Rot2");
		
		assertEquals(View.VISIBLE, zeichen.getVisibility());
		assertEquals("Rot2", zeichen.getText().toString());
		
	}
		
	
	/**
	 * Diese Methode pr�ft, ob der Button seine Funktionalit�t erf�llt. Nachdem
	 * ein Klcik auf dem Button ausgef�hrt wurde, wird ein Dialogfenster
	 * ge�ffnet. Es wird also gepr�ft, ob der Text des Dialogfensters auch auf
	 * der oberfl�che erscheint.
	 */
	public void testButtonSpeichern() {
		solo.goBack();

		solo.assertCurrentActivity("wrong activity", KoeniginActivity.class);
		solo.clickOnButton("Speichern");	
		this.sendKeys(KeyEvent.KEYCODE_DPAD_CENTER);
		assertTrue(solo.waitForText("Ihre Daten wurden gespeichert!"));
		
		}
	
	/**
	 * Diese Methode pr�ft den Button Historie, ob dieser auch wirklich die
	 * n�chste Activity �ffnet.
	 */
	public void testButtonHistorie() {
		solo.goBack();
		
		solo.clickOnButton("Historie");
		
		solo.waitForActivity("KoeniginHistorieActivity");
		solo.assertCurrentActivity("KoeniginHistorieActivity...", KoeniginHistorieActivity.class);
		
		this.sendKeys(KeyEvent.KEYCODE_DPAD_CENTER);
		
	}
	
	/**
	 * Schlie�t die ge�ffnete Activity.
	 */
	@Override
	public void tearDown() throws Exception {

    solo.finishOpenedActivities();
	super.tearDown();
	
	}

}
