package imkerapp.activities.test;

import com.example.imkerapp.R;
import com.jayway.android.robotium.solo.Solo;

import imkerapp.activities.MainActivity;
import imkerapp.activities.MenuActivity;
import imkerapp.activities.NeueBeuteActivity;
import imkerapp.activities.UebersichtBeutenActivity;
import imkerapp.database.Config;
import android.test.ActivityInstrumentationTestCase2;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;

public class MainActivityTest extends
		ActivityInstrumentationTestCase2<MainActivity> {

	private Solo solo;
	private MainActivity mainActivity;
	EditText standort;
	EditText beutenNr;

	public MainActivityTest() {
		super("imkerapp.activities", MainActivity.class);
	}

	/**
	 * Die setUp() Methode wird vor dem start jeder Testmthode ausgef�hrt. In
	 * diesem Fall bekommt die Klasse die BeutenID 20 �bergeben und es wird die
	 * zu testende Activity geholt und dem Klassenobjekt solo �bergeben.
	 */
	protected void setUp() throws Exception {
		super.setUp();
		Config.getConfig().setBeutenId((long) 20);

		mainActivity = getActivity();
		solo = new Solo(getInstrumentation(), getActivity());

		beutenNr = (EditText) solo.getView(R.id.beutennummer);
		standort = (EditText) solo.getView(R.id.standort);
	}

	/**
	 * Die Methode pr�ft das Textfeld in welches die Beutennummer geschrieben
	 * wird. Es wird �berpr�ft, ob in das Textfeld geschrieben werden kann, ob
	 * dieses auch wieder ausgelesen werden kann und ob es auf der Oberfl�che
	 * �berhaupt sichtbar ist.
	 */
	public void testTextBeutenNr() {

		solo.clearEditText(beutenNr);

		solo.enterText(beutenNr, "20");

		assertEquals(View.VISIBLE, beutenNr.getVisibility());
		assertEquals("20", beutenNr.getText().toString());

	}

	/**
	 * Die Methode pr�ft das Textfeld in welches der Standort geschrieben wird.
	 * Es wird �berpr�ft, ob in das Textfeld geschrieben werden kann, ob dieses
	 * auch wieder ausgelesen werden kann und ob es auf der Oberfl�che �berhaupt
	 * sichtbar ist.
	 */
	public void testTextStandort() {

		solo.clearEditText(standort);

		solo.enterText(standort, "Burg");

		assertEquals(View.VISIBLE, standort.getVisibility());
		assertEquals("Burg", standort.getText().toString());

	}

	/**
	 * Diese Methode pr�ft den Button NeueBeuteAnlegen, ob dieser auch wirklich
	 * die n�chste Activity �ffnet.
	 */
	public void testButtonNeueBeuteAnlegen() {

		solo.assertCurrentActivity("wrong activity", MainActivity.class);
		solo.clickOnButton("neue Beute anlegen");

		solo.waitForActivity("NeueBeuteActivity");
		solo.assertCurrentActivity("NeueBeuteActivity...",
				NeueBeuteActivity.class);

		this.sendKeys(KeyEvent.KEYCODE_DPAD_CENTER);

		solo.goBack();

	}

	/**
	 * Diese Methode pr�ft den Button OK, ob dieser auch wirklich die n�chste
	 * Activity �ffnet, wenn nur der Standort eingegeben wurde.
	 */
	public void testButtonOKStandort() {

		solo.clearEditText(beutenNr);
		solo.clearEditText(standort);

		solo.assertCurrentActivity("wrong activity", MainActivity.class);
		solo.enterText(standort, "Burg");
		solo.clickOnButton("OK");

		solo.waitForActivity("UebersichtBeutenActivity");
		solo.assertCurrentActivity("UebersichtBeutenActivity...",
				UebersichtBeutenActivity.class);

		this.sendKeys(KeyEvent.KEYCODE_DPAD_CENTER);

	}

	/**
	 * Diese Methode pr�ft den Button OK, ob dieser auch wirklich die n�chste
	 * Activity �ffnet, wenn nur die Beutennummer eingegeben wurde.
	 */
	public void testButtonOKBeutenNr() {

		solo.clearEditText(beutenNr);
		solo.clearEditText(standort);

		solo.assertCurrentActivity("wrong activity", MainActivity.class);
		solo.enterText(beutenNr, "2");
		solo.clickOnButton("OK");

		solo.waitForActivity("MenuActivity");
		solo.assertCurrentActivity("MenuActivity...", MenuActivity.class);

		this.sendKeys(KeyEvent.KEYCODE_DPAD_CENTER);

	}

	/**
	 * Diese Methode pr�ft den Button OK, ob dieser auch wirklich die n�chste
	 * Activity �ffnet, wenn Standort und Beutennummer eingegeben wurden.
	 */
	public void testButtonOKBeutenNrStandort() {

		solo.clearEditText(beutenNr);
		solo.clearEditText(standort);

		solo.assertCurrentActivity("wrong activity", MainActivity.class);
		solo.enterText(beutenNr, "2");
		solo.enterText(standort, "Burg");
		solo.clickOnButton("OK");

		solo.waitForActivity("MenuActivity");
		solo.assertCurrentActivity("MenuActivity...", MenuActivity.class);

		this.sendKeys(KeyEvent.KEYCODE_DPAD_CENTER);

	}

	/**
	 * Schlie�t die ge�ffnete Activity.
	 */
	@Override
	public void tearDown() throws Exception {

		solo.finishOpenedActivities();
		super.tearDown();

	}

}
