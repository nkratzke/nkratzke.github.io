package imkerapp.activities.test;

import imkerapp.activities.AnmerkungActivity;
import imkerapp.activities.BrutActivity;
import imkerapp.activities.KoeniginActivity;
import imkerapp.activities.MenuActivity;
import imkerapp.activities.StatusActivity;
import imkerapp.activities.StockbauActivity;
import imkerapp.activities.VersorgungActivity;
import imkerapp.database.Config;

import com.jayway.android.robotium.solo.Solo;

import android.test.ActivityInstrumentationTestCase2;
import android.view.KeyEvent;

public class MenuActivityTest extends
		ActivityInstrumentationTestCase2<MenuActivity> {

	Solo solo;
	MenuActivity menuActivity;

	public MenuActivityTest() {
		super("imkerapp.activities", MenuActivity.class);
	}

	/**
	 * Die setUp() Methode wird vor dem start jeder Testmthode ausgef�hrt. In
	 * diesem Fall bekommt die Klasse die BeutenID 20 �bergeben und es wird die
	 * zu testende Activity geholt und dem Klassenobjekt solo �bergeben.
	 */
	protected void setUp() throws Exception {
		super.setUp();
		Config.getConfig().setBeutenId((long) 20);

		menuActivity = getActivity();
		solo = new Solo(getInstrumentation(), getActivity());
	}

	/**
	 * Diese Methode pr�ft den Button Status, ob dieser auch wirklich die
	 * n�chste Activity �ffnet.
	 */
	public void testButtonStatus() {
		solo.clickOnButton("Status");

		solo.waitForActivity("StatusActivity");
		solo.assertCurrentActivity("StatusActivity...", StatusActivity.class);

		this.sendKeys(KeyEvent.KEYCODE_DPAD_CENTER);

	}

	/**
	 * Diese Methode pr�ft den Button Stockbau, ob dieser auch wirklich die
	 * n�chste Activity �ffnet.
	 */
	public void testButtonStockbau() {
		solo.clickOnButton("Stockbau");

		solo.waitForActivity("StockbauActivity");
		solo.assertCurrentActivity("StockbauActivity...",
				StockbauActivity.class);

		this.sendKeys(KeyEvent.KEYCODE_DPAD_CENTER);

	}

	/**
	 * Diese Methode pr�ft den Button K�nigin, ob dieser auch wirklich die
	 * n�chste Activity �ffnet.
	 */
	public void testButtonKoenigin() {
		solo.clickOnButton("K�nigin");

		solo.waitForActivity("KoeniginActivity");
		solo.assertCurrentActivity("KoeniginActivity...",
				KoeniginActivity.class);

		this.sendKeys(KeyEvent.KEYCODE_DPAD_CENTER);

	}

	/**
	 * Diese Methode pr�ft den Button Versorgung, ob dieser auch wirklich die
	 * n�chste Activity �ffnet.
	 */
	public void testButtonVersorgung() {
		solo.clickOnButton("Versorgung");

		solo.waitForActivity("VersorgungActivity");
		solo.assertCurrentActivity("VersorgungActivity...",
				VersorgungActivity.class);

		this.sendKeys(KeyEvent.KEYCODE_DPAD_CENTER);

	}

	/**
	 * Diese Methode pr�ft den Button Brut, ob dieser auch wirklich die n�chste
	 * Activity �ffnet.
	 */
	public void testButtonBrut() {
		solo.clickOnButton("Brut");

		solo.waitForActivity("BrutActivity");
		solo.assertCurrentActivity("BrutActivity...", BrutActivity.class);

		this.sendKeys(KeyEvent.KEYCODE_DPAD_CENTER);

	}

	/**
	 * Diese Methode pr�ft den Button Anmerkung, ob dieser auch wirklich die
	 * n�chste Activity �ffnet.
	 */
	public void testButtonAnmerkung() {
		solo.clickOnButton("Anmerkung");

		solo.waitForActivity("AnmerkungActivity");
		solo.assertCurrentActivity("AnmerkungActivity...",
				AnmerkungActivity.class);

		this.sendKeys(KeyEvent.KEYCODE_DPAD_CENTER);

	}

	/**
	 * Schlie�t die ge�ffnete Activity.
	 */
	@Override
	public void tearDown() throws Exception {

		solo.finishOpenedActivities();
		super.tearDown();

	}

}
