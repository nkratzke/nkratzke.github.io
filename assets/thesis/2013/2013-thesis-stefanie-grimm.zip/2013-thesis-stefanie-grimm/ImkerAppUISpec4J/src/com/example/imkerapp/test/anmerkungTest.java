package com.example.imkerapp.test;

import org.uispec4j.Panel;
import org.uispec4j.UISpec4J;

import com.example.imkerapp.R;

import imkerapp.activities.AnmerkungActivity;
import imkerapp.database.Config;
import imkerapp.database.daoobjekte.Anmerkung;
import imkerapp.database.daoobjekte.Beute;
import imkerapp.database.daoobjekte.Standort;
import imkerapp.database.daos.AnmerkungDao;
import android.widget.Button;
import android.widget.EditText;
import junit.framework.TestCase;

public class anmerkungTest extends TestCase {
	
	private EditText anmerkungText;
	Button historie;
	Button speichern;
	AnmerkungActivity anmerkungActivity;
	AnmerkungDao anmerkungDao;
	Anmerkung anmerkung;
	Standort standort;
	Beute beute;
	
	Panel panel;
	
	static{
		UISpec4J.init();
	}

	

	/** 
	 * @see android.test.ActivityInstrumentationTestCase2#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();		
		Config.getConfig().setBeutenId((long)20);
		anmerkungActivity= new AnmerkungActivity();	
		
		panel = new Panel(anmerkungActivity);

		
		
		historie = (Button) anmerkungActivity.findViewById(R.id.anmerkungHistorie);
		speichern = (Button) anmerkungActivity.findViewById(R.id.anmerkungSpeichern);
		anmerkungText = (EditText) anmerkungActivity.findViewById(R.id.anmerkungTexte);
		
		
		
	}

	public void Buttonhistorie(){
		
		
	}

}
