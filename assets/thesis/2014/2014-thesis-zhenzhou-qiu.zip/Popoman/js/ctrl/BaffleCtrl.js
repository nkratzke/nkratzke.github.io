function BaffleCtrl(baffleModel, baffleView){

    this._baffleModel = baffleModel;
    this._baffleView = baffleView;

    this.initialize();
};
    
BaffleCtrl.prototype.initialize = function(){
    
    var arr = this._baffleModel.initialize(this);
    var i = arr[0];
    var j = arr[1];
    var type = arr[2];

    this._baffleView.initialize(i, j, type);


};



BaffleCtrl.prototype.destroy = function(){
    
    var arr = this._baffleModel.destroy();
    var i = arr[0];
    var j = arr[1];

    this._baffleView.destroy();

    if(Math.random() < 0.5){
        var powerupsModel = new PowerupsModel(i, j);
        var powerupsView = new PowerupsView();
        var powerupsCtrl = new PowerupsCtrl(powerupsModel,powerupsView);
    }


};


BaffleCtrl.prototype.shift = function(direction){

    var arr = this._baffleModel.shift(direction);
    var i = arr[0];
    var j = arr[1];
    var direction = arr[2];
    var type = arr[3];
    
    this._baffleView.shift(i,j,direction,type);
}