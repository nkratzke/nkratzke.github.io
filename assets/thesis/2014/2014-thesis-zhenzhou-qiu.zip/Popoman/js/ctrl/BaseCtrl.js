function BaseCtrl(baseModel,baseView){

    this._baseModel = baseModel;
    this._baseView = baseView;
    this.initialize();

}

BaseCtrl.prototype.initialize = function(){

    var arr = this._baseModel.initialize();
    var i = arr[0];
    var j = arr[1];
    var type = arr[2];
    
    this._baseView.initialize(i, j, type);

}