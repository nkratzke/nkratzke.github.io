function BombCtrl( bombModel, bombView){

    this._bombModel = bombModel;
    this._bombView = bombView;
    this.s = null;

}

BombCtrl.prototype.play = function(){

    var arr = this._bombModel.play(this);
    var i = arr[0];
    var j = arr[1];
    var type = arr[2];
    
    this._bombView.play(i,j,type);

    
    var me = this;
    this.s = setTimeout(function(){
		me.destroy();
	}, 3000);
};

BombCtrl.prototype.destroy = function(){
    
    clearTimeout(this.s);
    Sound.play("burstSound");
    
    this._bombModel.destroy();

    this._bombView.destroy();
    
};

