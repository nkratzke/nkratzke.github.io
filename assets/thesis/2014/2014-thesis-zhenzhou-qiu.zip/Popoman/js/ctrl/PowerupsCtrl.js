function PowerupsCtrl(powerupsModel, powerupsView){

    this._powerupsModel = powerupsModel;
    this._powerupsView = powerupsView;
    
    this.initialize();

}

PowerupsCtrl.prototype.initialize = function(){

    var arr = this._powerupsModel.initialize(this);
    var i = arr[0];
    var j = arr[1];
    var type = arr[2];
    
    this._powerupsView.initialize(i, j, type);

}


PowerupsCtrl.prototype.collect = function(roleModel){

    Sound.play("collectSound");
    
    this._powerupsModel.collect(roleModel);
    
    this._powerupsView.collect();
    

}

PowerupsCtrl.prototype.destroy = function(){

    this._powerupsModel.destroy();
    
    this._powerupsView.destroy();

}