function RoleCtrl(roleModel, roleView){

    this._roleModel = roleModel;
    this._roleView = roleView;
    this.initialize();

}

RoleCtrl.prototype.initialize = function(){
    
    var arr = this._roleModel.initialize(this);
    var i = arr[0];
    var j = arr[1];
    var type = arr[2];
    
    this._roleView.initialize(i, j, type);
    
    var me = this;
    defer = setTimeout(function(){   
        
        me.loop();
    
    },800);
    
        
    if(type=='mainRole'|type=='subRole'){

        document.addEventListener('keydown',function(e){ me.keydownEventBinding(e);},false);
        document.addEventListener('keyup',function(e){ me.keyupEventBinding(e);},false);

    }
    
   
    
}


RoleCtrl.prototype.loop = function(){

    var me = this;
    this.t=setInterval(function(){
            me.setMove();
    },17);

}


RoleCtrl.prototype.stopLoop = function(){

    clearInterval(this.t);

}

RoleCtrl.prototype.keydownEventBinding = function(e){
    
    var type = this._roleModel.getType();
    var state = this._roleModel.getState();
    var key = e.keyCode;

        if(key== Keyboard[type+'Left']|key== Keyboard[type + 'Right']|key==Keyboard[type + 'Up']|key==Keyboard[type + 'Down']){

            Keyboard[type + "Keyboard"][key] = true;

            if(key == Keyboard[type + 'Left']) var direction = 'Left';
            if(key == Keyboard[type + 'Right']) var direction = 'Right';
            if(key == Keyboard[type + 'Up']) var direction = 'Up';
            if(key == Keyboard[type + 'Down']) var direction = 'Down';

            this._roleModel.setDirection(direction);
            if(state!='lock'){
                this._roleModel.setState('Move');
            }



        }

        if(key==Keyboard[type + 'Bomb']){
            this.placeBomb();
        }


}


RoleCtrl.prototype.keyupEventBinding = function(e){
    
    var type = this._roleModel.getType();
    var key = e.keyCode;
    var state = this._roleModel.getState();


    var flag =false;
    if(key== Keyboard[type+'Left']|key== Keyboard[type + 'Right']|key==Keyboard[type + 'Up']|key==Keyboard[type + 'Down']){
    
        Keyboard[type + 'Keyboard'][key] = false;

        for(var key in Keyboard[type + 'Keyboard']){

            if(Keyboard[type + 'Keyboard'][key]==true){

                if(key == Keyboard[type + 'Left']) var direction = 'Left';
                if(key == Keyboard[type + 'Right']) var direction = 'Right';
                if(key == Keyboard[type + 'Up']) var direction = 'Up';
                if(key == Keyboard[type + 'Down']) var direction = 'Down';

                this._roleModel.setDirection(direction);

                if(state!='lock'){
                    this._roleModel.setState('Move');
                }

                flag = true;

            }

        }

        if(flag==false){

            if(state!='lock'){
                this._roleModel.setState('Stand');
            }
        }
    }
            
 

    
}






RoleCtrl.prototype.setMove = function(){

    var bombFlag = this._roleModel.setMove();

    this.move();
    if(bombFlag==true) this.placeBomb();
}


RoleCtrl.prototype.move = function(){

    var arr = this._roleModel.move();
    var newX = arr[0];
    var newY = arr[1];
    var j = arr[2];
    var state = arr[3];
    var direction = arr[4];
    var type = arr[5];
    
    this._roleView.move(newX, newY, j, state, direction, type);
    

}


RoleCtrl.prototype.pushing = function(){

    Sound.play("pushSound");
    this._roleModel.pushing();
    
}






RoleCtrl.prototype.placeBomb = function(){

    var flag = this._roleModel.placeBomb();
    
    if(flag==true) Sound.play("placeSound");


}

RoleCtrl.prototype.destroy = function(){

    var type = this._roleModel.destroy();
    this._roleView.destroy(type);
    this.stopLoop();
    
    Sound.play("dieSound");
    
    Game.judge(false,type);
}



