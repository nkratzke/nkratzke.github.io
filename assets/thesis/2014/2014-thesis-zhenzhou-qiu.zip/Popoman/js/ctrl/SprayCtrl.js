function SprayCtrl(sprayModel,sprayView){

	this._sprayModel = sprayModel;
	this._sprayView = sprayView;
    
    this.initialize();


}

SprayCtrl.prototype.initialize = function(){

    var arr = this._sprayModel.initialize(this);
    var i = arr[0];
    var j = arr[1];
    
    this._sprayView.initialize(i,j);
    

}

SprayCtrl.prototype.show = function(){

    this._sprayView.show();

}