
var Game = {};

Game.initialData = function(){

this.WIDTH = 40;
this.HEIGHT = 40;
this.D = 2;
this.K = 1.4;

this.iLength = this.map[0].length;
this.jLength = this.map.length;
    
this.left = 1;
this.right = this.iLength - 2;
this.top = 1;
this.down = this.jLength - 2;

this.leftBorder = (this.left + 1/2)*this.WIDTH;
this.rightBorder = (this.right + 1/2) * this.WIDTH;
this.topBorder = (this.top + 1/2)*this.HEIGHT;
this.bottomBorder = (this.down + 1/2) * this.HEIGHT;

this.gameRoles = [];
}



Game.rootWindow = function(){

    UI.div("rootWindow");
    UI.text("rootText","rootWindow","PopoMan");
    UI.button("newButton","rootWindow","New");
    UI.button("testButton","rootWindow","Test");
    

    document.getElementById("newButton").addEventListener("click",function(){

                   Window.remove("rootWindow");
                   Window.show("modeWindow");

               },false);      
    
    document.getElementById("testButton").addEventListener("click",function(){
                   Game.mode = 'test';
                   Window.remove("rootWindow");
                   Window.show("mapWindow");
                  

               },false);      


    Picture.loadImg();
    Keyboard.initialize();
    Sound.loop("menuSound");

}


Game.modeWindow = function(){

    UI.div("modeWindow");
    UI.text("modeText","modeWindow","Mode");
    UI.button("soloButton","modeWindow","Solo");
    UI.button("multiButton","modeWindow","Multi");
    document.getElementById("soloButton").addEventListener("click",function(){
                   Game.mode = 'solo';
                   Game.enemyRoleNumber = 1; 
                   Window.remove("modeWindow");
                   Window.show("mapWindow");
                   

    },false);      

    document.getElementById("multiButton").addEventListener("click",function(){
                   Game.mode = 'multi';
                   Game.enemyRoleNumber = 1; 
                   Window.remove("modeWindow");
                   Window.show("mapWindow");
                   

    },false);
}


Game.mapWindow = function(){

    UI.div("mapWindow");
    UI.text("mapText","mapWindow","Map");
    UI.select("mapSelect","mapWindow");
    

    for(var i in Map[this.mode+'MapPool']){
        UI.option("mapSelect",Map[this.mode+'MapPool'][i]);
    }
    
    UI.button("goButton","mapWindow","Go");
    document.getElementById("goButton").addEventListener("click",function(){

           var map = document.getElementById("mapSelect").value;
           Game.type = Map.type;
           Game.map = Map[Game.mode+map];
           Game.baseType = Map.baseType;
           Game.baseMap = Map[map+'BaseMap'];

           Window.remove("mapWindow");
           Window.show("gameWindow");


    },false); 
    
    

}




Game.soloWindow = function(){

    UI.div("soloWindow");
    UI.text("soloText","soloWindow","Map");
    UI.select("soloSelect","soloWindow");
    
    for(var i in Map.soloMapPool){
        UI.option("soloSelect",Map.soloMapPool[i]);
    }
    
    UI.button("goButton","soloWindow","Go");
    document.getElementById("goButton").addEventListener("click",function(){

           var map = document.getElementById("soloSelect").value;
           Game.type = Map.type;
           Game.map = Map['solo'+map];
           Game.baseType = Map.baseType;
           Game.baseMap = Map[map+'BaseMap'];
           Game.enemyRoleNumber = 1;
           Window.remove("soloWindow");
           Window.show("gameWindow");


    },false); 
    
    

}


Game.multiWindow = function(){

    UI.div("multiWindow");
    UI.text("multiText","multiWindow","Map");
    UI.select("multiSelect","multiWindow");

    for(var i in Map.multiMapPool){
        UI.option("multiSelect",Map.multiMapPool[i]);
    }

    UI.button("goButton","multiWindow","Go");
    document.getElementById("goButton").addEventListener("click",function(){

           var map = document.getElementById("multiSelect").value;
           Game.type = Map.type;
           Game.map = Map['multi'+map];
           Game.baseType = Map.baseType;
           Game.baseMap = Map[map+'BaseMap'];
           Game.enemyRoleNumber = -1;
           Window.remove("multiWindow");
           Window.show("gameWindow");

    },false);   

}



Game.type = [];

Game.map = [];

Game.baseType = [];

Game.baseMap = [];

Game.gameWindow = function () {
    
    UI.div("gameWindow");
    this.initialData();
    this.countDown();

       
    Sound.stop("menuSound");
    Sound.play("bornSound");
    Sound.loop("gameSound");

    
    
    for (var j = 0; j < this.baseMap.length; j++){
    
            for (var i = 0; i<this.baseMap[j].length; i++){
                
                var baseTypeNumber = this.baseMap[j][i];
                var baseType = this.baseType[baseTypeNumber];
                
                
                var baseModel = new BaseModel(i, j, baseType);
                var baseView = new BaseView();
                var baseCtrl = new BaseCtrl(baseModel,baseView);
                
                
            }
    }
    
    

    for (var j = 0; j < this.map.length; j++){
    
        for (var i = 0; i<this.map[j].length; i++){
        
            var typeNumber = this.map[j][i];
            var type = this.type[typeNumber];
            
            Game.map[j][i] ={};
            var gird = Game.map[j][i];
            
            gird.spray = null;
            gird.bomb = null;
            gird.baffle = null;
            gird.powerups = null;
            gird.mainRole = null;
            gird.subRole = null;
            gird.enemyRole = null;
                        
            
            gird.pass = true;
            gird.blow = true;
            gird.push = false;
            
            gird.danger = false;

            
            var sprayModel = new SprayModel(i, j);
            var sprayView = new SprayView();
            var sprayCtrl =  new SprayCtrl(sprayModel,sprayView);
            
            
            if(typeNumber==-1){
            
                gird.pass = false;
            
            
            }else if (type == 'none'){
                
            
            }else if (typeNumber==18) {
                //create a mainRole
                var mainRoleModel = new RoleModel(i,j,'mainRole');
                var mainRoleView = new RoleView();
                var mainRoleCtrl = new RoleCtrl(mainRoleModel,mainRoleView);
            
            }else if(typeNumber==19){
            
                //create a subRole
                var subRoleModel = new RoleModel(i,j,'subRole');
                var subRoleView = new RoleView();
                var subRoleCtrl = new RoleCtrl(subRoleModel,subRoleView);
            
            
            }else if ( typeNumber==20){
            
                //create an enemy
                var enemyRoleModel = new RoleModel(i,j,'enemyRole');
                var enemyRoleView = new RoleView();
                var enemyRoleCtrl = new RoleCtrl(enemyRoleModel,enemyRoleView);
            
            }else{
                
                //create a baffle (pass, blow, push)
                var baffleModel = new BaffleModel(i, j, type, (/^0|8$/).test(typeNumber) ? true : false,(/^1|2|6|8|10|11$/).test(typeNumber) ? true : false, typeNumber==6 ? true : false);
                var baffleView = new BaffleView();
                var baffleCtrl = new BaffleCtrl(baffleModel,baffleView);
                
            }
        
        
        }
    
    }





    
    
    
};





Game.judge = function(timeUp,type){

    var flag = false;
    var text = "";
    if(timeUp==true && type==null){
        flag = true;
        if(Game.enemyRoleNumber==-1){
            //multi mode
            Sound.stop("gameSound");
            Sound.play("drawSound");
            for(i in this.gameRoles){

                this.gameRoles[i]._roleView.win(this.gameRoles[i]._roleModel.getType());

            }
            text = "Draw";
            
            
        }else{
            //single mode
            Sound.stop("gameSound");
            Sound.play("loseSound");
            for(i in this.gameRoles){
                if(this.gameRoles[i]._roleModel.getType()=='mainRole'){
                    this.gameRoles[i]._roleView.lose(this.gameRoles[i]._roleModel.getType());
                }else{
                    this.gameRoles[i]._roleView.win(this.gameRoles[i]._roleModel.getType());
                }
            }
            text = "You Lose";
        
        }
        
    }
    
    if(timeUp==false){
    

        if(Game.enemyRoleNumber==-1){
            //multi mode
            Sound.stop("gameSound");
            Sound.play("winSound");

            flag = true;
            clearInterval(t);

            var roles = ['mainRole','subRole'];
            for( i in roles){

                    if(roles[i]!=type){
                         text = roles[i] + " Win";        
                    }
            }
            
            for(i in this.gameRoles){
                if(this.gameRoles[i]._roleModel.getType()==type){
                    this.gameRoles[i]._roleView.lose(this.gameRoles[i]._roleModel.getType());
                }else{
                    this.gameRoles[i]._roleView.win(this.gameRoles[i]._roleModel.getType());
                }
            }


        }else{
        
            //single mode
            if(type=='enemyRole'){

                Game.enemyRoleNumber--;

                if(Game.enemyRoleNumber==0){

                    Sound.stop("gameSound");
                    Sound.play("winSound"); 

                    flag = true;
                    clearInterval(t);

                    text = "You Win";   
                    
                    for(i in this.gameRoles){
                        if(this.gameRoles[i]._roleModel.getType()=='enemyRole'){
                            this.gameRoles[i]._roleView.lose(this.gameRoles[i]._roleModel.getType());
                        }else{
                            this.gameRoles[i]._roleView.win(this.gameRoles[i]._roleModel.getType());
                        }
                    }

                }

            }

            if(type=='mainRole' && Game.enemyRoleNumber!=0){

                Sound.stop("gameSound");
                Sound.play("loseSound"); 

                flag = true;
                clearInterval(t);

                text = "You Lose"; 
                
                
                for(i in this.gameRoles){
                    if(this.gameRoles[i]._roleModel.getType()=='mainRole'){
                        this.gameRoles[i]._roleView.lose(this.gameRoles[i]._roleModel.getType());
                    }else{
                        this.gameRoles[i]._roleView.win(this.gameRoles[i]._roleModel.getType());
                    }
                }

            }

        }
        

    }


    if(flag == true){
        
        for(i in this.gameRoles){
    
            this.gameRoles[i]._roleModel.setState('lock');
    
        }
        
        setTimeout(function(){

            Game.result(text);

        },2500);
        
    }
    

}


Game.result = function(text){

    if(Window.gameWindow){
    
        Window.remove("gameWindow");
    }
    
    if(Window.resultWindow) return;
    
    UI.div("resultWindow");
    UI.text("resultText","resultWindow",text);
    UI.button("backButton","resultWindow","Back");
    document.getElementById("backButton").addEventListener("click",function(){

                location.reload();

    },false); 

 }
    



Game.countDown = function(){


var mins = 3;  //Set the number of minutes you need
var sec = 0;
var secs = mins * 60 + sec;
var currentSeconds = 0;
var currentMinutes = 0;
t = setInterval(function(){

        currentMinutes = Math.floor(secs / 60);
        currentSeconds = secs % 60;
        if(currentSeconds <= 9) currentSeconds = "0" + currentSeconds;
        secs--;
        document.getElementById("timerText").innerHTML = currentMinutes + ":" + currentSeconds; 
        if(secs == -1) {
            
            clearInterval(t);
            Game.judge(true,null);
        
        
        };

},1000);


}









