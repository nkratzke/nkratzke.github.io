var Keyboard = {};

Keyboard.initialize = function(){

    this.mainRoleKeyboard = [];
    this.subRoleKeyboard = [];
    
    this.mainRoleLeft = 68;
    this.mainRoleRight = 71;
    this.mainRoleUp = 82;
    this.mainRoleDown = 70;
    this.mainRoleBomb = 81;

    this.subRoleLeft = 219;
    this.subRoleRight = 220;
    this.subRoleUp = 187;
    this.subRoleDown = 221;
    this.subRoleBomb = 186;

}

Keyboard.customize = function(){


}