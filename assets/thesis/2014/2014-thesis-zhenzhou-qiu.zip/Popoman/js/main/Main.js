$(function(){

Game.rootWindow();
    
document.oncontextmenu = function(ev){

return false;

}

});
