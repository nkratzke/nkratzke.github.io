var Picture = {};

Picture.loadImg = function(){
    
    for(var i in this.tagName){
    
        for(var j in this[this.tagName[i]+'Pool']){
            
            
            this[this[this.tagName[i]+'Pool'][j]] = document.createElement("img");
            this[this[this.tagName[i]+'Pool'][j]].src = "img/" + this.tagName[i] +"/" +this[this.tagName[i]+'Pool'][j]+".gif";
            var img = new Image();
            var me = this;
            img.src = this[this[this.tagName[i]+'Pool'][j]].src;
            img.onload = function(){
            
                me[me[me.tagName[i]+'Pool'][j]].width = this.width;
                me[me[me.tagName[i]+'Pool'][j]].height = this.height;
            
            }
            
        }
    
    }

}


Picture.tagName = ['border','base','mainRole','subRole','enemyRole','baffle','bomb','powerups'];


Picture.borderPool = ['border_lt','border_t','border_rt','border_r','border_rb','border_b','border_lb','border_l'];

Picture.basePool = ['yellowGround','greenGround','brownGround','greyGround','crossGround','bricGround'];

Picture.mainRolePool = [
    'mainRoleLeftMove','mainRoleLeftStand',
    'mainRoleRightMove','mainRoleRightStand',
    'mainRoleUpMove','mainRoleUpStand',
    'mainRoleDownMove','mainRoleDownStand',
    'mainRoleBorn','mainRoleDead',
    'mainRoleWin','mainRoleLose'
];
Picture.subRolePool = [
    'subRoleLeftMove','subRoleLeftStand',
    'subRoleRightMove','subRoleRightStand',
    'subRoleUpMove','subRoleUpStand',
    'subRoleDownMove','subRoleDownStand',
    'subRoleBorn','subRoleDead',
    'subRoleWin','subRoleLose'
];
Picture.enemyRolePool = [
    'enemyRoleLeftMove','enemyRoleLeftStand',
    'enemyRoleRightMove','enemyRoleRightStand',
    'enemyRoleUpMove','enemyRoleUpStand',
    'enemyRoleDownMove','enemyRoleDownStand',
    'enemyRoleBorn','enemyRoleDead',
    'enemyRoleWin','enemyRoleLose'
];
Picture.bafflePool = [
    'house1','house2','house3',
    'bric1','bric2',
    'box','tree1','tree2','hideWall','rock1','rock2','leaf','log'
];
Picture.bombPool = ['spray','bomb'];

Picture.powerupsPool = ['bombUp','powerUp','speedUp'];


Picture.loadBorderImg = function(){

    for(var  i in this.borderPool){
        this[this.borderPool[i]] = document.createElement("img");
        this[this.borderPool[i]].src = "img/border/"+this.borderPool[i]+".gif";
        
        var img = new Image();
        var me = this;
        img.src = this[this.borderPool[i]].src;
        img.onload = function(){
        
            me[me.borderPool[i]].width = this.width;
            me[me.borderPool[i]].height = this.height;
        
        
        }

    }
}


Picture.loadBaseImg = function(){

    for(var  i in this.basePool){
        this[this.basePool[i]] = document.createElement("img");
        this[this.basePool[i]].src = "img/base/"+this.basePool[i]+".gif";
        
        var img = new Image();
        var me = this;
        img.src = this[this.basePool[i]].src;
        img.onload = function(){
        
            me[me.basePool[i]].width = this.width;
            me[me.basePool[i]].height = this.height;
        
        
        }

    }
}










