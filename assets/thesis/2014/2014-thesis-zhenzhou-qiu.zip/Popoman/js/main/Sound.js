var Sound = {};
Sound.loop = function(id){

    document.getElementById(id).setAttribute("src","Sound/"+id+".mp3");
    document.getElementById(id).setAttribute("autoplay","autoplay");
    document.getElementById(id).setAttribute("loop","loop");

}


Sound.play = function(id){

    document.getElementById(id).setAttribute("src","Sound/"+id+".mp3");
    document.getElementById(id).setAttribute("autoplay","autoplay");

}

Sound.stop = function(id){
    
    document.getElementById(id).setAttribute("src","");

}




