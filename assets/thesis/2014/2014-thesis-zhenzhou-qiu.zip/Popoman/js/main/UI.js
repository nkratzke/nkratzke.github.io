var UI = {};

UI.div = function(div_id){

    Window[div_id] = document.createElement("div");
    document.getElementById("Popo").appendChild(Window[div_id]);
    Window[div_id].setAttribute("id",div_id);

};


UI.text = function(text_id,father_id,innerText){

    var text = document.createElement("div");
    document.getElementById(father_id).appendChild(text);
    text.setAttribute("id",text_id);
    text.innerHTML = innerText; 

};

UI.button = function(button_id,father_id,value){

    var button = document.createElement("input");
    document.getElementById(father_id).appendChild(button);
    button.setAttribute("id",button_id);
    button.setAttribute("type","button");
    button.setAttribute("value",value);
    $("#"+button_id).button();
    
};

UI.select = function(select_id,father_id){

    var select = document.createElement("select");
    document.getElementById(father_id).appendChild(select);
    select.setAttribute("id",select_id);
    $("#"+select_id).menu();


}

UI.option = function(father_id,value){

    var option = document.createElement("option");
    document.getElementById(father_id).appendChild(option);
    option.value = value;
    option.innerHTML = value;

}