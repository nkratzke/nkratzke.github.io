var Window = {


};

Window.initialize = function(){

    this.rootWindow = null;
    this.optionWindow = null;
    this.modeWindow = null;
    this.mapWindow = null;
    this.gameWindow = null;
    this.resultWindow = null;
}

Window.show = function(id){

    Game[id]();
}

Window.remove = function(id){

    this[id].remove();
};






