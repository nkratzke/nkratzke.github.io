function BaffleModel(i, j, type, pass, blow, push){

    this._i = i;
    this._j = j;
    this._type = type;
    this._pass = pass;
    this._blow = blow;
    this._push = push;
    this._ctrl = null;

};

BaffleModel.prototype.getI = function(){

    return this._i;
};
    
BaffleModel.prototype.getJ = function(){

    return this._j;
};

BaffleModel.prototype.getType = function(){

    return this._type;
};


BaffleModel.prototype.getPass = function(){

    return this._pass;
}

BaffleModel.prototype.getBlow = function(){

    return this._blow;
}

BaffleModel.prototype.getPush = function(){

    return this._push;
}

BaffleModel.prototype.getCtrl = function(){

    return this._ctrl;
}

//************************************************************************
BaffleModel.prototype.setI = function(i){

    this._i = i;
}


BaffleModel.prototype.setJ = function(j){

    this._j = j;
}

BaffleModel.prototype.setCtrl = function(ctrl){

    this._ctrl = ctrl;
}


//************************************************************************
BaffleModel.prototype.initialize = function(ctrl){
    
    this.setCtrl(ctrl);
    var i = this.getI();
    var j = this.getJ();
    var type = this.getType();
    var pass = this.getPass();
    var blow = this.getBlow();
    var push = this.getPush();
    var ctrl = this.getCtrl();
    
    var gird = Game.map[j][i];
    
    gird.baffle = ctrl;
    gird.pass = pass;
    gird.blow = blow;
    gird.push = push;
    
    return [i,j,type]; 
}


BaffleModel.prototype.destroy = function(){

    var i = this.getI();
    var j = this.getJ();
    var type = this.getType();
    var gird = Game.map[j][i];
    
    gird.baffle = null;
    gird.pass = true;
    gird.blow = true;
    gird.push = false;
    
    return [i,j];

}


BaffleModel.prototype.shift = function(direction){
    
    var i = this.getI();
    var j = this.getJ();
    var ctrl = this.getCtrl();
    var type = this.getType();
    var gird = Game.map[j][i];
    var i1 = i;
    var j1 = j;
    
    gird.baffle = null;
    gird.pass = true;
    gird.blow = true;
    gird.push = false;
    
    
    switch(direction){
    
        case 'Left': 
                    i1 = i-1;
                    j1 = j;
                    break;
                    
        case 'Right':
                    i1 = i+1;
                    j1 = j;
                    break;
            
        case 'Up':
                    i1 = i;
                    j1 = j-1;
                    break;           
        case 'Down':
                    i1 = i;
                    j1 = j1+1;
                    break;   
    
    }
    
    var gird1 = Game.map[j1][i1];
    gird1.baffle = ctrl;
    gird1.pass = false;
    gird1.blow = true;
    gird1.push = true;

    if(gird1.powerups){
        gird1.powerups.destroy();        
    }
    

        
    this.setI(i1);
    this.setJ(j1);

    return [i,j,direction,type];


}