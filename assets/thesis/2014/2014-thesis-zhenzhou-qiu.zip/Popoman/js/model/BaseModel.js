function BaseModel(i, j, type){

    this._i = i;
    this._j = j;
    this._type = type;

}

BaseModel.prototype.getI = function(){

    return this._i;
}


BaseModel.prototype.getJ = function(){


    return this._j;
}

BaseModel.prototype.getType = function(){


    return this._type;
}

//************************************************

BaseModel.prototype.initialize = function(){

    var i = this.getI();
    var j = this.getJ();
    var type = this.getType();
    
    return [i,j,type];

}