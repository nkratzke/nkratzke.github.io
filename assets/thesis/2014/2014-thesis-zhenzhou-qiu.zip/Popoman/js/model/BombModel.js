function BombModel(roleModel){

	this._roleModel = roleModel;
    this._i = 0;
    this._j = 0;
    this._type = 'bomb'
    this._bombPower = 1;
    this._ctrl = null;

}

BombModel.prototype.getRoleModel = function(){

    return this._roleModel;

}

BombModel.prototype.getI = function(){

    return this._i;

}

BombModel.prototype.getJ = function(){

    return this._j;

}

BombModel.prototype.getType = function(){

    return this._type;

}

BombModel.prototype.getBombPower = function(){

    return this._bombPower;

}

BombModel.prototype.getCtrl = function(){


    return this._ctrl;
}
//*****************************************************************

BombModel.prototype.setI = function(placeI){

   this._i = placeI;

}

BombModel.prototype.setJ = function(placeJ){

    this._j = placeJ;

}

BombModel.prototype.setBombPower = function(bombPower){

    this._bombPower = bombPower;

}

BombModel.prototype.setCtrl = function(ctrl){

    this._ctrl = ctrl;
}

//****************************************************************


BombModel.prototype.play = function(ctrl){

    this.setCtrl(ctrl);
    var roleModel = this.getRoleModel();
    var i = roleModel.getI();
    var j = roleModel.getJ();
    var type = this.getType();
    var ctrl = this.getCtrl();
    var gird = Game.map[j][i];
    
    //set the current bombPower for this bomb
    var bombPower = roleModel.getBombPower();
    this.setBombPower(bombPower);

    this.setI(i);
    this.setJ(j);
    
    gird.bomb = ctrl;
    gird.pass = false;
    gird.danger = true;
   
    var explosionDetection = [];
    
    //left
    for(var i1 = i - 1; i1 >= i - bombPower; i1--){
        if (i1 < Game.left) break;
        var gird = Game.map[j][i1];
        if (gird.blow==false && gird.pass==false && gird.baffle) break;
        explosionDetection.push(gird);
    
        if (gird.blow==true && gird.pass==false && gird.baffle) break;

    }
    
    //right
    for(var i1 = i + 1; i1 <= i + bombPower; i1++){
        if (i1 > Game.right) break;
        var gird = Game.map[j][i1];
        if (gird.blow==false && gird.pass==false && gird.baffle) break;
        explosionDetection.push(gird);

        if (gird.blow==true && gird.pass==false && gird.baffle) break;

    }
    
    
    //up
    for(var j1 = j - 1; j1 >= j - bombPower; j1--){
        if (j1 < Game.top) break;
        var gird = Game.map[j1][i];
        if (gird.blow==false && gird.pass==false && gird.baffle) break;
        explosionDetection.push(gird);

        if (gird.blow==true && gird.pass==false && gird.baffle) break;

    }  
    
    
    //down
    for(var j1 = j + 1; j1 <= j + bombPower; j1++){
        if (j1 > Game.down) break;
        var gird = Game.map[j1][i];
        if (gird.blow==false && gird.pass==false && gird.baffle) break;
        explosionDetection.push(gird);

        if (gird.blow==true && gird.pass==false && gird.baffle) break;

    } 


    for(var m = 0; m < explosionDetection.length; m++){
        var obj = explosionDetection[m];

        obj.danger = true;
    }
    
    

    return [i,j,type];
}



BombModel.prototype.destroy = function(){

    var i = this.getI();
    var j = this.getJ();
    var bombPower = this.getBombPower();
    var gird = Game.map[j][i];
    gird.pass = true;
    gird.bomb = null;
    gird.danger = false;
    if(gird.mainRole) gird.mainRole.destroy();
    if(gird.subRole) gird.subRole.destroy();
    if(gird.enemyRole) gird.enemyRole.destroy();
    if(gird.baffle && gird.blow==true) gird.baffle.destroy();
    gird.spray.show();


    var explosionRegion = [];
    //left
    for(var i1 = i - 1; i1 >= i - bombPower; i1--){
        if (i1 < Game.left) break;
        var gird = Game.map[j][i1];
        if (gird.blow==false && gird.pass==false && gird.baffle) break;
        explosionRegion.push(gird);
    
        if (gird.blow==true && gird.pass==false && gird.baffle) break;

    }
    
    //right
    for(var i1 = i + 1; i1 <= i + bombPower; i1++){
        if (i1 > Game.right) break;
        var gird = Game.map[j][i1];
        if (gird.blow==false && gird.pass==false && gird.baffle) break;
        explosionRegion.push(gird);

        if (gird.blow==true && gird.pass==false && gird.baffle) break;

    }
    
    
    //up
    for(var j1 = j - 1; j1 >= j - bombPower; j1--){
        if (j1 < Game.top) break;
        var gird = Game.map[j1][i];
        if (gird.blow==false && gird.pass==false && gird.baffle) break;
        explosionRegion.push(gird);

        if (gird.blow==true && gird.pass==false && gird.baffle) break;

    }  
    
    
    //down
    for(var j1 = j + 1; j1 <= j + bombPower; j1++){
        if (j1 > Game.down) break;
        var gird = Game.map[j1][i];
        if (gird.blow==false && gird.pass==false && gird.baffle) break;
        explosionRegion.push(gird);

        if (gird.blow==true && gird.pass==false && gird.baffle) break;

    } 


    for(var m = 0; m < explosionRegion.length; m++){
        var obj = explosionRegion[m];
        obj.spray.show();
        obj.danger = false;
        
        if(obj.powerups) obj.powerups.destroy();
        if(obj.baffle && obj.blow==true) obj.baffle.destroy();
        if(obj.bomb) obj.bomb.destroy();
        if(obj.mainRole)  obj.mainRole.destroy();
        if(obj.subRole) obj.subRole.destroy();
        if(obj.enemyRole) obj.enemyRole.destroy();


    }
    
    this.recover();

}


BombModel.prototype.recover = function(){
    var roleModel = this.getRoleModel();
    var type = roleModel.getType();
    var ctrl = this.getCtrl();
    roleModel.getBombList().push(ctrl);

    //********************* Test*******************//
    var bombAvailable = roleModel.getBombAvailable();
    
    if(type=='mainRole'){
        document.getElementById("main_bombAvailable").value = bombAvailable;
    }
    
    if(type=='subRole'|type=='enemyRole'){
        document.getElementById("sub_bombAvailable").value = bombAvailable;
    }

}

