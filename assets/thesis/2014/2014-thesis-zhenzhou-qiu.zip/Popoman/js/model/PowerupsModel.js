function PowerupsModel(i, j){
    
    this._i = i;
    this._j = j;
    this._type = "";
    this._ctrl = null;
}

PowerupsModel.prototype.getI = function(){

    return this._i;
    
}

PowerupsModel.prototype.getJ = function(){

    return this._j;

}

PowerupsModel.prototype.getType = function(){

    return this._type;

}

PowerupsModel.prototype.getCtrl = function(){

    return this._ctrl;

}


//************************************************************
PowerupsModel.prototype.setType = function(type){

    this._type = type;

}

PowerupsModel.prototype.setCtrl = function(ctrl){

    this._ctrl = ctrl;

}



//************************************************************
    
PowerupsModel.prototype.initialize = function(ctrl){

    this.setCtrl(ctrl);
    var i = this.getI();
    var j = this.getJ();
    var ctrl = this.getCtrl();
    var type = ['bombUp', 'powerUp', 'speedUp'][Math.floor(Math.random()*3)];
    this.setType(type);
    
    var gird = Game.map[j][i];
    gird.powerups = ctrl;
    
    return [i,j,type];
    
}


PowerupsModel.prototype.collect = function(roleModel){

    
    var i = this.getI();
    var j = this.getJ();
    var type = this.getType();
    var gird = Game.map[j][i];
    var roleType = roleModel.getType();
    gird.powerups = null;
    switch(type){
    
    case 'bombUp':
            var bombTotal = roleModel.getBombTotal();
            if( bombTotal + 1 <= 6){
                bombTotal++;
                roleModel.setBombTotal(bombTotal);
                
                var bombModel = new BombModel(roleModel);
                var bombView = new BombView();
                var bombCtrl = new BombCtrl(bombModel,bombView);
                roleModel.getBombList().push(bombCtrl);
               

            }
            
            
            //test_panel
            var bombAvailable = roleModel.getBombAvailable();
            if(roleType=='mainRole'){
            
                document.getElementById("main_bombTotal").value = bombTotal;
                document.getElementById("main_bombAvailable").value = bombAvailable;
                document.getElementById("main_Bomb").value = bombTotal;

            }
            
            if(roleType=='subRole'|roleType=='enemyRole'){
            
                document.getElementById("sub_bombTotal").value = bombTotal;
                document.getElementById("sub_bombAvailable").value = bombAvailable;
                document.getElementById("sub_Bomb").value = bombTotal;

                
            }

            
            break;

            
    case 'powerUp':
            
            var bombPower = roleModel.getBombPower();
            if(roleType=='mainRole'|roleType=='subRole'){
                if( bombPower + 1 <= 6){
                    bombPower++;
                    roleModel.setBombPower(bombPower);

                }
            }
            
            if(roleType=='enemyRole'){
            
                if( bombPower + 1 <= 10){
                    bombPower++;
                    roleModel.setBombPower(bombPower);

                }
            
            
            
            
            
            }
            
            //test_panel
            if(roleType=='mainRole'){
            
                document.getElementById("main_bombPower").value = bombPower;
                document.getElementById("main_Power").value = bombPower;

                
            }
            
            if(roleType=='subRole'|roleType=='enemyRole'){
                    
                document.getElementById("sub_bombPower").value = bombPower;
                document.getElementById("sub_Power").value = bombPower;

                
            }
            break;
            
            
    case 'speedUp':
            
            var speed = roleModel.getSpeed();
            
            
            if(roleType=='mainRole'|roleType=='subRole'){

                if( speed + 1 <= 4){
                    speed++;
                    roleModel.setSpeed(speed);

                }
                
            }
            
            if(roleType=='enemyRole'){
            
                if( speed + 1 <= 7){
                    speed++;
                    roleModel.setSpeed(speed);

                }
            
            
            
            }
            
            //test_panel
            if(roleType=='mainRole'){
            
                document.getElementById("main_speed").value = speed;
                document.getElementById("main_Speed").value = speed;

                
            }
            
            if(roleType=='subRole'|roleType=='enemyRole'){
                    
                document.getElementById("sub_speed").value = speed;
                document.getElementById("sub_Speed").value = speed;

                
            }
            break;
    
    }
    
}


PowerupsModel.prototype.destroy = function(){

    var i = this.getI();
    var j = this.getJ();
    var gird = Game.map[j][i];
    gird.powerups = null;

}


