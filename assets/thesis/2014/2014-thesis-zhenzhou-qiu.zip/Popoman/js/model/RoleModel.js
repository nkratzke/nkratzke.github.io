function RoleModel(i, j, type) {

    this._i = i;
    this._j = j;
    this._x = (i +1/2)* Game.WIDTH;
    this._y = (j +1/2)* Game.HEIGHT;
    this._direction = 'Down';
    this._state = '';
    // _type = mainRole || subRole
    this._type = type;
    this._bombList = [];
    this._bombTotal = 1;
    this._speed = 1;
    this._bombPower = 1;
    this._ctrl = null;
}

//****************** get*****************************************
RoleModel.prototype.getI = function(){

    return this._i;

};

RoleModel.prototype.getJ = function(){

    return this._j;

};

RoleModel.prototype.getX = function(){

    return this._x;

};

RoleModel.prototype.getY = function(){

    return this._y;

};

RoleModel.prototype.getSpeed = function(){

    return this._speed;

};

RoleModel.prototype.getDirection = function(){

    return this._direction;
};


RoleModel.prototype.getState = function(){
    
    return this._state;

};

RoleModel.prototype.getType = function(){
    
    return this._type;

};


RoleModel.prototype.getBombTotal = function(){
    
    return this._bombTotal;

};

RoleModel.prototype.getBombList = function(){
    
    return this._bombList;

};

RoleModel.prototype.getBombAvailable = function(){
    
    return this._bombList.length;

};

RoleModel.prototype.getBombPower = function(){
    
    return this._bombPower;

};

RoleModel.prototype.getCtrl = function(){
    
    return this._ctrl;

};


//*************** set ******************************************
RoleModel.prototype.setI = function(i){
    
    this._i = i;
    

};

RoleModel.prototype.setJ = function(j){
    
    this._j = j;
};

RoleModel.prototype.setX = function(x){

    this._x = x;
};

RoleModel.prototype.setY = function(y){

    this._y = y;
};


RoleModel.prototype.setSpeed = function(speed){

	this._speed = speed;
};

RoleModel.prototype.setDirection = function(direction){

    this._direction = direction;
};


RoleModel.prototype.setState = function(state){

    this._state = state;
};

RoleModel.prototype.setBombTotal = function(bombTotal){

    this._bombTotal = bombTotal;
}



RoleModel.prototype.setBombPower = function(bombPower){

    this._bombPower = bombPower;
}

RoleModel.prototype.setCtrl = function(ctrl){

    this._ctrl = ctrl;
}


//*****************************************************************

RoleModel.prototype.initialize = function(ctrl){
    
    this.setCtrl(ctrl);
    
    var i = this.getI();
    var j = this.getJ();
    var type = this.getType();
    var ctrl = this.getCtrl();
    var gird = Game.map[j][i];
    
    gird[type] = ctrl;
    
    Game.gameRoles.push(ctrl);
    
    
    if(type=='mainRole'|type=='subRole'){
            
        this.setState('Stand');
    }else{
    
        this.setState('Move');
    }
    

    
    
    
    var initialBombNumber = this.getBombTotal();
    for(var m = 0; m < initialBombNumber; m++ ){
    
        var bombModel = new BombModel(this);
        var bombView = new BombView();
        var bombCtrl = new BombCtrl(bombModel,bombView);
        this.getBombList().push(bombCtrl);

        
    }
    
    
    
    //test_panel
    var bombTotal = this.getBombTotal();
    var bombAvailable = this.getBombAvailable();
    var bombPower = this.getBombPower();
    var speed = this.getSpeed();
    
    if(type=='mainRole'){
        
        document.getElementById("main_bombTotal").value = bombTotal;
        document.getElementById("main_bombAvailable").value = bombAvailable;
        document.getElementById("main_bombPower").value = bombPower;
        document.getElementById("main_speed").value = speed;
        
        document.getElementById("main_Bomb").value = bombTotal;
        document.getElementById("main_Power").value = bombPower;
        document.getElementById("main_Speed").value = speed;




    }
    
    if(type=='subRole'|type=='enemyRole'){
    
        document.getElementById("sub_bombTotal").value = bombTotal;
        document.getElementById("sub_bombAvailable").value = bombAvailable;
        document.getElementById("sub_bombPower").value = bombPower;
        document.getElementById("sub_speed").value = speed;
        
        document.getElementById("sub_Bomb").value = bombTotal;
        document.getElementById("sub_Power").value = bombPower;
        document.getElementById("sub_Speed").value = speed;



    }

    return [i,j,type];
    
    
}


RoleModel.prototype.destroy = function(){

    var i = this.getI();
    var j = this.getJ();
    var type = this.getType();
    var gird = Game.map[j][i];
    
    this.setState('lock');

    gird[type] = null;
    
    
    return type;

}



RoleModel.prototype.setMove = function(){

    var ctrl = this.getCtrl();
    var state = this.getState();
    var type = this.getType();
    var bombFlag = false;
    
    if(state=='lock')  return;


    if(type=='enemyRole'){
        
        
        var i = this.getI();
        var j = this.getJ();
        var gird = Game.map[j][i];
        var trys = this.trys(i,j);
        var safes = this.safes(i,j);
    
        if(this.newGird==true |safes.length==1|trys.length==1){
            
                if(safes.length>0){
                    var newDirection = safes[Math.floor(Math.random()*safes.length)];
                }
                if(safes.length==0 && trys.length>0){
                    var newDirection = trys[Math.floor(Math.random()*trys.length)];
                }
        }
        
        if( state=='Stand'){
        
                if(trys.length>0){
                    
                    var newDirection = trys[Math.floor(Math.random()*trys.length)];
                
                
                }

        
        }
        

        var currentDirection = this.getDirection();
        var aheadBlock = false;
        var restDirections = [];
        
        if(currentDirection=='Left'){
            if(i==Game.left){
            
                aheadBlock = true;
                restDirections = ['Right','Up','Down'];

            }
            if(i!=Game.left){         
                if(Game.map[j][i-1].pass==false) aheadBlock = true;
                restDirections = ['Right','Up','Down'];
            } 
        }        
        
        if(currentDirection=='Right'){
            if(i== Game.right){
                aheadBlock = true;
                restDirections = ['Left','Up','Down'];

            }
            if(i!= Game.right){         
                if(Game.map[j][i+1].pass==false) aheadBlock = true;
                restDirections = ['Left','Up','Down'];
            }
        }        
        
        if(currentDirection=='Up'){
            if(j==Game.top){
            
                aheadBlock =true;
                restDirections = ['Left','Right','Down'];
               
            }
            if(j!=Game.top){         
                if(Game.map[j-1][i].pass==false) aheadBlock = true;
                restDirections = ['Left','Right','Down'];
            }
        }        
        
        if(currentDirection=='Down'){
            if(j==Game.down){
            
                aheadBlock = true;
                restDirections = ['Left','Right','Up'];

            }
            if(j!=Game.down){         
                if(Game.map[j+1][i].pass==false) aheadBlock = true;
                restDirections = ['Left','Right','Up'];
            }
        }
        
        
        if(this.newGird ==false && aheadBlock ==true){
        
            var newDirection = restDirections[Math.floor(Math.random()*restDirections.length)];
        
        }
        

    

        //Stand or Move

        if( trys.length==0 && gird.danger==false){
        
            state = 'Stand';
            this.setState('Stand');

            
        }else if(trys==['Left','Right']|trys==['Up','Down']){
        


                state = 'Stand';
                this.setState('Stand');

                bombFlag = true;
        
        
        }else{
            state = 'Move';
            var d = new Date();
            if(trys.length==3){
                 if(d.getMilliseconds() % 50 == 1 | d.getMilliseconds() % 60 == 2 | d.getMilliseconds() % 70 == 3){
                        bombFlag = true;
                 }
            }

            if(newDirection!=null) this.setDirection(newDirection);
            this.setState('Move');

            
            
        }

       


    }else{ 
        //mainRole subRole

    }
    
    
    return bombFlag;
    
}


RoleModel.prototype.move = function(){

    var ctrl = this.getCtrl();
    var x = this.getX();
    var y = this.getY();
    var speed = this.getSpeed();
    var direction = this.getDirection(); 
    var newX = x,newY = y;
    var tempX = x, tempY = y;

    var state = this.getState();
    
    var i = this.getI();
    var j = this.getJ();
    var type = this.getType();
    var gird = Game.map[j][i];


    if(state=='Move'){
    
            if(direction=='Left'){

                
                        tempX = x - (speed / 2  *  Game.K + Game.D) ;

                        if(i==Game.left){

                            if(tempX<Game.leftBorder){

                                newX = Game.leftBorder;
                            }else{

                                newX = tempX;
                            }


                        }else if(i==Game.left + 1){
                        
                            switch(Game.map[j][i-1].pass){

                                    case true:
                                                if( y < ( j + 1/2 )*Game.HEIGHT ){

                                                            if(Game.map[j-1][i-1].pass==false){

                                                                        if( tempX < (i + 1/2)*Game.WIDTH ){

                                                                            newX = tempX;
                                                                            newY = (j + 1/2)*Game.HEIGHT;


                                                                        }else{
                                                                              newX = tempX;

                                                                        }

                                                            }else{
                                                                 newX = tempX;
                                                            } 

                                                }else if(y > ( j + 1/2 )*Game.HEIGHT){

                                                                                                                                                                                                                    if(Game.map[j+1][i-1].pass==false){

                                                                        if( tempX < (i + 1/2)*Game.WIDTH ){

                                                                            newX = tempX;
                                                                            newY = (j + 1/2)*Game.HEIGHT;

                                                                        }else{

                                                                            newX = tempX;

                                                                        }

                                                             }else{                              
                                                                    newX = tempX;
                                                             }

                                                }else{
                                                      newX = tempX;


                                                }
                                                break;

                                    case false:

                                              if(tempX < (i + 1/2)*Game.WIDTH){

                                                  newX = (i + 1/2)*Game.WIDTH;
                                                  
                                              }else{

                                                  newX = tempX;
                                              }
                                              break;

                            } 
                            
                        
                        }else{

                            switch(Game.map[j][i-1].pass){

                                    case true:
                                                if( y < ( j + 1/2 )*Game.HEIGHT ){

                                                            if(Game.map[j-1][i-1].pass==false){

                                                                        if( tempX < (i + 1/2)*Game.WIDTH ){

                                                                            newX = tempX;
                                                                            newY = (j + 1/2)*Game.HEIGHT;


                                                                        }else{
                                                                              newX = tempX;

                                                                        }

                                                            }else{
                                                                 newX = tempX;
                                                            } 

                                                }else if(y > ( j + 1/2 )*Game.HEIGHT){

                                                                                                                                                                                                                    if(Game.map[j+1][i-1].pass==false){

                                                                        if( tempX < (i + 1/2)*Game.WIDTH ){

                                                                            newX = tempX;
                                                                            newY = (j + 1/2)*Game.HEIGHT;

                                                                        }else{

                                                                            newX = tempX;

                                                                        }

                                                             }else{                              
                                                                    newX = tempX;
                                                             }

                                                }else{
                                                      newX = tempX;


                                                }
                                                break;

                                    case false:

                                              if(tempX < (i + 1/2)*Game.WIDTH){

                                                  newX = (i + 1/2)*Game.WIDTH;
                                                  if(Game.map[j][i-1].push==true && Game.map[j][i-2].pass==true){
                                                  
                                                     ctrl.pushing();
                                                  }
                                                  
                                              }else{

                                                  newX = tempX;
                                              }
                                              break;

                            }


                        }

            }

            if(direction=='Right'){

                        tempX = x + (speed / 2  *  Game.K + Game.D);
                        if(i==Game.right){


                            if(tempX>Game.rightBorder){

                                newX = Game.rightBorder;

                            }else{

                                newX = tempX;
                            }


                        }else if(i==Game.right - 1){
                        
                                switch(Game.map[j][i+1].pass){

                                    case true:
                                                if( y < ( j + 1/2 )*Game.HEIGHT ){

                                                            if(Game.map[j-1][i+1].pass==false){

                                                                        if( tempX > (i + 1/2)*Game.WIDTH ){

                                                                            newX = tempX;
                                                                            newY = (j + 1/2)*Game.HEIGHT;


                                                                        }else{

                                                                            newX = tempX;

                                                                        }

                                                            }else{

                                                                    newX = tempX;
                                                            } 

                                                }else if(y > ( j + 1/2 )*Game.HEIGHT ){

                                                            if(Game.map[j+1][i+1].pass==false){

                                                                        if( tempX > (i + 1/2)*Game.WIDTH ){

                                                                            newX = tempX;
                                                                            newY = (j + 1/2)*Game.HEIGHT;

                                                                        }else{

                                                                            newX = tempX;

                                                                        }

                                                             }else{                              
                                                                    newX = tempX;
                                                             }

                                                }else{

                                                           newX = tempX;  

                                                }
                                                break;

                                    case false:

                                              if(tempX > (i + 1/2)*Game.WIDTH){

                                                  newX = (i + 1/2)*Game.WIDTH;

                                              }else{

                                                  newX = tempX;
                                              }
                                              break;

                                }                        
                        
                        
                        
                        
                        
                        }else{

                                switch(Game.map[j][i+1].pass){

                                    case true:
                                                if( y < ( j + 1/2 )*Game.HEIGHT ){

                                                            if(Game.map[j-1][i+1].pass==false){

                                                                        if( tempX > (i + 1/2)*Game.WIDTH ){

                                                                            newX = tempX;
                                                                            newY = (j + 1/2)*Game.HEIGHT;


                                                                        }else{

                                                                            newX = tempX;

                                                                        }

                                                            }else{

                                                                    newX = tempX;
                                                            } 

                                                }else if(y > ( j + 1/2 )*Game.HEIGHT ){

                                                            if(Game.map[j+1][i+1].pass==false){

                                                                        if( tempX > (i + 1/2)*Game.WIDTH ){

                                                                            newX = tempX;
                                                                            newY = (j + 1/2)*Game.HEIGHT;

                                                                        }else{

                                                                            newX = tempX;

                                                                        }

                                                             }else{                              
                                                                    newX = tempX;
                                                             }

                                                }else{

                                                           newX = tempX;  

                                                }
                                                break;

                                    case false:

                                              if(tempX > (i + 1/2)*Game.WIDTH){

                                                  newX = (i + 1/2)*Game.WIDTH;
                                                  if(Game.map[j][i+1].push==true && Game.map[j][i+2].pass==true){
                                                  
                                                     ctrl.pushing();
                                                  }

                                              }else{

                                                  newX = tempX;
                                              }
                                              break;

                                }
                        }
            }
            if(direction=='Up'){

                        tempY = y - (speed / 2  *  Game.K + Game.D);

                        if(j==Game.top){


                            if(tempY < Game.topBorder){

                                newY = Game.topBorder;

                            }else{

                                newY = tempY;
                            }


                        }else if(j==Game.top + 1){
                        
                           switch(Game.map[j-1][i].pass){

                                case true:
                                            if( x < ( i + 1/2 )*Game.WIDTH ){

                                                        if(Game.map[j-1][i-1].pass==false){

                                                                    if( tempY < (j + 1/2)*Game.HEIGHT ){

                                                                        newX = (i + 1/2)*Game.WIDTH;
                                                                        newY = tempY;

                                                                    }else{

                                                                        newY = tempY;

                                                                    }

                                                        }else{

                                                                newY = tempY;
                                                        } 

                                            }else if(x > ( i + 1/2 )*Game.WIDTH){

                                                           if(Game.map[j-1][i+1].pass==false){

                                                                    if( tempY < (j + 1/2)*Game.HEIGHT ){

                                                                        newX = (i + 1/2)*Game.WIDTH;
                                                                        newY = tempY;

                                                                    }else{

                                                                        newY = tempY;

                                                                    }

                                                         }else{                              
                                                                newY = tempY;
                                                         }


                                            }else{

                                                  newY = tempY;      
                                            }
                                            break;

                                case false:

                                          if(tempY < (j+1/2)*Game.HEIGHT){

                                              newY = (j+1/2)*Game.HEIGHT;

                                          }else{

                                              newY = tempY;
                                          }
                                          break;

                            }                        
                    
                        
                        
                        
                        }else{


                            switch(Game.map[j-1][i].pass){

                                case true:
                                            if( x < ( i + 1/2 )*Game.WIDTH ){

                                                        if(Game.map[j-1][i-1].pass==false){

                                                                    if( tempY < (j + 1/2)*Game.HEIGHT ){

                                                                        newX = (i + 1/2)*Game.WIDTH;
                                                                        newY = tempY;

                                                                    }else{

                                                                        newY = tempY;

                                                                    }

                                                        }else{

                                                                newY = tempY;
                                                        } 

                                            }else if(x > ( i + 1/2 )*Game.WIDTH){

                                                           if(Game.map[j-1][i+1].pass==false){

                                                                    if( tempY < (j + 1/2)*Game.HEIGHT ){

                                                                        newX = (i + 1/2)*Game.WIDTH;
                                                                        newY = tempY;

                                                                    }else{

                                                                        newY = tempY;

                                                                    }

                                                         }else{                              
                                                                newY = tempY;
                                                         }


                                            }else{

                                                  newY = tempY;      
                                            }
                                            break;

                                case false:

                                          if(tempY < (j+1/2)*Game.HEIGHT){

                                              newY = (j+1/2)*Game.HEIGHT;
                                              if(Game.map[j-1][i].push==true && Game.map[j-2][i].pass==true){

                                                 ctrl.pushing();
                                              }

                                          }else{

                                              newY = tempY;
                                          }
                                          break;

                            }

                        }
            }


            if(direction=='Down'){

                        tempY = y + (speed / 2  *  Game.K + Game.D);

                        if(j==Game.down){


                            if(tempY > Game.bottomBorder){

                                newY = Game.bottomBorder;

                            }else{

                                newY = tempY;

                            }


                        }else if(j==Game.down - 1){
                        
                              switch(Game.map[j+1][i].pass){

                                case true:
                                            if( x < ( i + 1/2 )*Game.WIDTH ){

                                                        if(Game.map[j+1][i-1].pass==false){

                                                                    if( tempY > (j + 1/2)*Game.HEIGHT ){

                                                                        newX = (i + 1/2)*Game.WIDTH;
                                                                        newY = tempY;

                                                                    }else{

                                                                        newY = tempY;

                                                                    }

                                                        }else{

                                                                newY = tempY;
                                                        } 

                                            }else if(x > ( i + 1/2 )*Game.WIDTH){

                                                            if(Game.map[j+1][i+1].pass==false){

                                                                        if( tempY > (j + 1/2)*Game.HEIGHT ){

                                                                            newX = (i + 1/2)*Game.WIDTH;
                                                                            newY = tempY;

                                                                        }else{

                                                                            newY = tempY;

                                                                        }

                                                             }else{                              
                                                                    newY = tempY;
                                                             }

                                            }else{
                                                  newY = tempY;       

                                            }
                                            break;

                                case false:

                                          if(tempY > (j+1/2)*Game.HEIGHT){

                                              newY = (j+1/2)*Game.HEIGHT;

                                          }else{

                                              newY = tempY;
                                          }
                                          break;

                            }                      
                        
                        

                        }else{


                            switch(Game.map[j+1][i].pass){

                                case true:
                                            if( x < ( i + 1/2 )*Game.WIDTH ){

                                                        if(Game.map[j+1][i-1].pass==false){

                                                                    if( tempY > (j + 1/2)*Game.HEIGHT ){

                                                                        newX = (i + 1/2)*Game.WIDTH;
                                                                        newY = tempY;

                                                                    }else{

                                                                        newY = tempY;

                                                                    }

                                                        }else{

                                                                newY = tempY;
                                                        } 

                                            }else if(x > ( i + 1/2 )*Game.WIDTH){

                                                            if(Game.map[j+1][i+1].pass==false){

                                                                        if( tempY > (j + 1/2)*Game.HEIGHT ){

                                                                            newX = (i + 1/2)*Game.WIDTH;
                                                                            newY = tempY;

                                                                        }else{

                                                                            newY = tempY;

                                                                        }

                                                             }else{                              
                                                                    newY = tempY;
                                                             }

                                            }else{
                                                  newY = tempY;       

                                            }
                                            break;

                                case false:

                                          if(tempY > (j+1/2)*Game.HEIGHT){

                                              newY = (j+1/2)*Game.HEIGHT;
                                              if(Game.map[j+1][i].push==true && Game.map[j+2][i].pass==true){

                                                   ctrl.pushing();
                                              }
                                          }else{

                                              newY = tempY;
                                          }
                                          break;

                            }

                        }
            }
    

    
    }
    
    this.setX(newX);
    this.setY(newY);
    
    this.freeGird();
    this.useGird();


        
    if(gird.danger==true){
            var safety = 'No';
    }else{
            var safety = 'Yes';
    }

    
    //test_panel
    if(type=='mainRole'){
    
        document.getElementById("main_x").value = newX;
        document.getElementById("main_y").value = newY;
        document.getElementById("main_direction").value = direction;
        document.getElementById("main_state").value = state;
        document.getElementById("main_safety").value = safety;
        
    }
    if(type=='subRole'|type=='enemyRole'){
    
        document.getElementById("sub_x").value = newX;
        document.getElementById("sub_y").value = newY;
        document.getElementById("sub_direction").value = direction;
        document.getElementById("sub_state").value = state;
        document.getElementById("sub_safety").value = safety;

    }

    return [newX,newY,j,state,direction,type];

    
    
}



RoleModel.prototype.useGird = function(){

    var ctrl = this.getCtrl();
    var type = this.getType(); 
    var i = this.getI();
    var j = this.getJ();  
    var x = this.getX();
    var y = this.getY();
    var i1 = Math.floor(x / Game.WIDTH);
    var j1 = Math.floor(y / Game.HEIGHT);
    var gird = Game.map[j1][i1];
    
    this.newGird = false;
    if(!(i==i1 && j==j1)){
        
        this.newGird = true;
        gird[type] = ctrl;
        
        //test_panel
        if(type=='mainRole'){
         
            document.getElementById("main_useGird").value = i1 +", "+j1;
   
        }
        
        
        if(type=='subRole'|type=='enemyRole'){
        
            document.getElementById("sub_useGird").value = i1 +", "+j1;
    
        
        }
        
        if(gird.powerups) {
            gird.powerups.collect(this);
        }

        
    }
    
    
    this.setI(i1);
    this.setJ(j1);
    
    //test_panel
    
    if(type=='mainRole'){
    
        document.getElementById("main_i").value = i1;
        document.getElementById("main_j").value = j1;
        
    }
    if(type=='subRole'|type=='enemyRole'){
    
        document.getElementById("sub_i").value = i1;
        document.getElementById("sub_j").value = j1;   
    }

  
}

RoleModel.prototype.freeGird = function(){

    var type = this.getType();
    var i = this.getI();
    var j = this.getJ();
    var x = this.getX();
    var y = this.getY();
    var i1 = Math.floor(x / Game.WIDTH);
    var j1 = Math.floor(y / Game.HEIGHT); 
    var gird = Game.map[j][i];
    
    if(!(i==i1 && j==j1)){
        
        gird[type] = null;
        
        //test_panel
        if(type=='mainRole'){
        
                document.getElementById("main_freeGird").value = i +", "+j;

        }
        if(type=='subRole'|type=='enemyRole'){
        
                document.getElementById("sub_freeGird").value = i +", "+j;

        }
        
    }
    
    
}

RoleModel.prototype.placeBomb = function(){
    var i = this.getI();
    var j = this.getJ();
    var type = this.getType();
    var gird = Game.map[j][i];
    var bombAvailable = this.getBombAvailable();
    var flag = false;
    if(gird.bomb==null && bombAvailable>0){
        this.getBombList().pop().play();
        flag = true;
        
        
          //test_panel
        var bombAvailable = this.getBombAvailable();
        if(type=='mainRole'){
         
            document.getElementById("main_bombAvailable").value = bombAvailable;
      
        }
        if(type=='subRole'|type=='enemyRole'){
        
            document.getElementById("sub_bombAvailable").value = bombAvailable;

        }
    }
    
    return flag;

}


RoleModel.prototype.pushing = function(){

    var direction = this.getDirection();
    var i = this.getI();
    var j = this.getJ();
    

    if(direction=='Left'){
    
        var boxCtrl = Game.map[j][i-1].baffle;
        boxCtrl.shift(direction);
    
    }
    
    
    if(direction=='Right'){
    
        var boxCtrl = Game.map[j][i+1].baffle;
        boxCtrl.shift(direction);   
    
    
    }
    
    
    if(direction=='Up'){
       
        var boxCtrl = Game.map[j-1][i].baffle;
        boxCtrl.shift(direction);    
       
    }
    
    if(direction=='Down'){
    
        var boxCtrl = Game.map[j+1][i].baffle;
        boxCtrl.shift(direction); 
    
    
    }


}




RoleModel.prototype.safes = function(i,j){

    var gird = Game.map[j][i];
    var safes = [];
    if(gird.danger==true){
                
                //********************************************
                var safeLeft = true;
                if(i==Game.left){safeLeft = false;}
                if(i!=Game.left){
                    if(Game.map[j][i-1].pass==false) safeLeft = false;
                }
                for(var i1 = i - 1; i1 >= Game.left; i1--){

                    if(Game.map[j][i1].pass==false) break;
                    if(Game.map[j][i1].danger==true) {
                        
                        safeLeft = false;
                    }
                    

                }
            
                if(safeLeft==true){
                
                    safes.push('Left');
                
                }

                //********************************************
                var safeRight = true;
                if(i==Game.right){safeRight = false;}
                if(i!=Game.right){
                    if(Game.map[j][i+1].pass==false) safeRight = false;
                }

                for(var i1 = i + 1; i1 <= Game.right;  i1++){

                    if(Game.map[j][i1].pass==false) break;
                    if(Game.map[j][i1].danger==true){
                        safeRight = false;
                    }

                }


                if(safeRight==true){
                
                    safes.push('Right');
                }

                //*****************************************
                var safeUp = true;
                if(j==Game.top){safeUp = false;}
                if(j!=Game.top){
                    if(Game.map[j-1][i].pass==false) safeUp = false;
                }

                for(var j1 = j - 1; j1 >= Game.top; j1--){

                    if(Game.map[j1][i].pass==false) break;
                    if(Game.map[j1][i].danger==true){
                        safeUp = false;
                    }
                }  
            
                if(safeUp==true){
                
                    safes.push('Up');
                }

            
                //**********************************************
                var safeDown = true;
                if(j==Game.down){safeDown = false;}
                if(j!=Game.down){
                    if(Game.map[j+1][i].pass==false) safeDown = false;
                }

                for(var j1 = j + 1; j1 <= Game.down ; j1++){

                    if(Game.map[j1][i].pass==false) break;
                    if(Game.map[j1][i].danger==true){
                        
                        safeDown = false;
                    }

                } 

            
                if(safeDown==true){
                
                    safes.push('Down');
                
                }


    
    }
    
    return safes;

}

RoleModel.prototype.trys = function(i,j){

    var gird = Game.map[j][i];
    var trys = [];
    if(gird.danger==false){
        
              //left
                if(i==Game.left){
                    //do nothing
                }else if(i==Game.left + 1){

                    if(Game.map[j][i-1].pass==true && Game.map[j][i-1].danger==false){

                        trys.push('Left');

                    }



                }else{

                    if(Game.map[j][i-1].pass==true && Game.map[j][i-1].danger==false){

                        trys.push('Left');

                    }


                    if(Game.map[j][i-1].push==true && Game.map[j][i-1].danger==false && Game.map[j][i-2].pass==true){

                        trys.push('Left');

                    }

                }


                //right

                if(i==Game.right){
                    //do nothing
                }else if(i==Game.right - 1){

                    if(Game.map[j][i+1].pass==true && Game.map[j][i+1].danger==false){

                        trys.push('Right');

                    }    


                }else{


                    if(Game.map[j][i+1].pass==true && Game.map[j][i+1].danger==false){

                        trys.push('Right');

                    }


                    if(Game.map[j][i+1].push==true && Game.map[j][i+1].danger==false && Game.map[j][i+2].pass==true){

                        trys.push('Right');

                    }


                }



                //up
                if(j==Game.top){
                    //do nothing
                }else if(j==Game.top + 1){

                    if(Game.map[j-1][i].pass==true && Game.map[j-1][i].danger==false){

                        trys.push('Up');

                    }



                }else{

                    if(Game.map[j-1][i].pass==true && Game.map[j-1][i].danger==false){

                        trys.push('Up');

                    }


                    if(Game.map[j-1][i].push==true && Game.map[j-1][i].danger==false && Game.map[j-2][i].pass==true){

                        trys.push('Up');

                    }

                }  



                //down
                if(j==Game.down){
                    //do nothing
                }else if(j==Game.down - 1){

                    if(Game.map[j+1][i].pass==true && Game.map[j+1][i].danger==false){

                        trys.push('Down');

                    }    


                }else{


                    if(Game.map[j+1][i].pass==true && Game.map[j+1][i].danger==false){

                        trys.push('Down');

                    }


                    if(Game.map[j+1][i].push==true && Game.map[j+1][i].danger==false && Game.map[j+2][i].pass==true){

                        trys.push('Down');

                    }


                }
            
            
        }
        
        
        if(gird.danger==true){
                
                //********************************************
                var tryLeft = false;

                for(var i1 = i - 1; i1 >= Game.left; i1--){

                    if(Game.map[j][i1].pass==false) break;
                    if(Game.map[j][i1].test==true) break;
                    if(Game.map[j][i1].danger==false) {
                        
                        tryLeft = true;
                    }
                    

                }

                if(tryLeft==true){

                    trys.push('Left');
                }
            


                //********************************************
                var tryRight = false;


                for(var i1 = i + 1; i1 <= Game.right;  i1++){

                    if(Game.map[j][i1].pass==false) break;
                    if(Game.map[j][i1].test==true) break;
                    if(Game.map[j][i1].danger==false){
                        tryRight = true;
                    }
                }

                if(tryRight==true){

                    trys.push('Right');
                }


                //*****************************************
                var tryUp = false;

                for(var j1 = j - 1; j1 >= Game.top; j1--){

                    if(Game.map[j1][i].pass==false) break;
                    if(Game.map[j][i1].test==true) break;
                    if(Game.map[j1][i].danger==false){
                        tryUp = true;
                    }
                }  

                if(tryUp==true){

                    trys.push('Up');
                }

            
                //**********************************************
                var tryDown = false;

                for(var j1 = j + 1; j1 <= Game.down ; j1++){

                    if(Game.map[j1][i].pass==false) break;
                    if(Game.map[j][i1].test==true) break;
                   if(Game.map[j1][i].danger==false){
                        
                        tryDown = true;
                    }

                } 

                if(tryDown==true){

                    trys.push('Down');
                }
            

    
        }
    
    return trys;

}
