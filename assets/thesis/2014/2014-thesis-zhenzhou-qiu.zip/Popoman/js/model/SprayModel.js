function SprayModel(i, j){

	this._i = i;
	this._j = j;
    this._ctrl = null;


}

SprayModel.prototype.getI = function(){

    return this._i;
}

SprayModel.prototype.getJ = function(){

    return this._j;
}

SprayModel.prototype.getCtrl = function(){

    return this._ctrl;
}


//********************************************

SprayModel.prototype.setCtrl = function(ctrl){

     this._ctrl = ctrl;
}

//********************************************

SprayModel.prototype.initialize = function(ctrl){
    
    this.setCtrl(ctrl);
    var i = this.getI();
    var j = this.getJ();
    var ctrl = this.getCtrl();
    var gird = Game.map[j][i];
    
    gird.spray = ctrl;

    return [i,j];
}
