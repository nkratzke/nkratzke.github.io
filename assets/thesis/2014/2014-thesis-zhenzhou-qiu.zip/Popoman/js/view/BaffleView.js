function BaffleView(){};
    
BaffleView.prototype.initialize = function(i, j, type){

    this.dom = document.createElement("div");
    document.getElementById("gameWindow").appendChild(this.dom);
    this.dom.style.left = i*Game.WIDTH;
    if(type=='hideWall'){
        this.dom.style.zIndex = j + 1;
    }else{
        this.dom.style.zIndex = j;
    }
    this.dom.setAttribute('class','baffle');
    var img = document.createElement("img");
    
    img.src = Picture[type].src;
    
    this.dom.style.top = (j+1)*Game.HEIGHT - Picture[type].height;
    this.dom.appendChild(img);    

}; 


BaffleView.prototype.destroy = function(){
    
    this.dom.remove();
    
}





BaffleView.prototype.shift = function(i, j, direction, type){

    
    switch(direction){
    
    
        case 'Left':
                    this.dom.style.left = (i-1)*Game.WIDTH;
                    break;

        case 'Right':
                    this.dom.style.left = (i+1)*Game.WIDTH;
                    break;
                    

        case 'Up':
                    this.dom.style.top = (j+0)*Game.HEIGHT - Picture[type].height;
                    this.dom.style.zIndex = j - 1;
                    break;

        case 'Down':
                    this.dom.style.top = (j+2)*Game.HEIGHT - Picture[type].height;
                    this.dom.style.zIndex = j + 1;
                    break;
    
    }
    

}