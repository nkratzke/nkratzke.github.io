function BaseView(){

}

BaseView.prototype.initialize = function(i, j, type){

    this.dom = document.createElement("div");
    document.getElementById("gameWindow").appendChild(this.dom);
    this.dom.style.left = i*Game.WIDTH;
    this.dom.style.zIndex = j - 2;
    this.dom.setAttribute('class','base');
    var img = document.createElement("img");
    
    img.src = Picture[type].src;
    
    this.dom.style.top = (j+1)*Game.HEIGHT - Picture[type].height;
    this.dom.appendChild(img); 
    

}