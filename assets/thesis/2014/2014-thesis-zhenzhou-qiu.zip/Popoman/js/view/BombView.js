function BombView(){};

BombView.prototype.play = function(playerI,playerJ,type){

    this.dom = document.createElement("div");
    if(!Game.gameWindow) return;
    document.getElementById("gameWindow").appendChild(this.dom);
    this.dom.style.left = playerI*Game.WIDTH;
    this.dom.style.top = playerJ*Game.HEIGHT;
    this.dom.setAttribute('class','bomb');
    this.dom.style.zIndex = playerJ - 1;
    var img =  document.createElement("img");
    img.src = Picture[type].src;
    this.dom.appendChild(img);

}

BombView.prototype.destroy = function(){

    this.dom.remove();
    
}