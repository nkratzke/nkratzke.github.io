function PowerupsView(){

}


PowerupsView.prototype.initialize = function(i,j,type){
    
    this.dom = document.createElement("div");
    if(!Game.gameWindow) return;
    document.getElementById("gameWindow").appendChild(this.dom);
    
       
    this.dom.setAttribute('class','powerups');
    this.dom.style.zIndex = j;
    
    this.dom.style.left = i*Game.WIDTH;
    this.dom.style.top = (j+1)*Game.HEIGHT - Picture[type].height;
    
    var img = document.createElement("img");
    img.src = Picture[type].src;
    this.dom.appendChild(img);    

};

PowerupsView.prototype.collect = function(){

    this.dom.remove();
    
};


PowerupsView.prototype.destroy = function(){

    this.dom.remove();
    
};