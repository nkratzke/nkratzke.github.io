function RoleView(){

};



RoleView.prototype.initialize = function(i, j, type){

    this.dom = document.createElement("div");
    document.getElementById("gameWindow").appendChild(this.dom);
    this.dom.style.left = i*Game.WIDTH;

    this.dom.setAttribute('class','role');
    this.dom.setAttribute('id',type);
    this.dom.style.zIndex = j;
    this.img = document.createElement("img");
    
    this.img.src = Picture[type + 'Born'].src;
    this.dom.style.top = (j+1)*Game.HEIGHT - Picture[type + 'Born'].height;
    this.dom.appendChild(this.img);
    

};

RoleView.prototype.move = function(x, y, j, state, direction, type){
    
    this.dom.style.left = x - Game.WIDTH/2;
    this.dom.style.top = y + Game.HEIGHT/2 - Picture[type+direction+state].height;
    this.dom.style.zIndex = j;
    
    if(this.img.src != Picture[type+direction+state].src){
    
        this.img.src = Picture[type+direction+state].src;
    }
    
  
};



RoleView.prototype.destroy = function(type){

    this.img.src = Picture[type + 'Dead'].src;
    
    var dom = this.dom;
    setTimeout(function(){
        
        //dom.style.display = 'none';
        dom.remove();
    
    },2500);

}

RoleView.prototype.win = function(type){

    this.dom.style.display = 'block';
    this.img.src = Picture[type + 'Win'].src;

}


RoleView.prototype.lose = function(type){

    this.dom.style.display = 'block';
    this.img.src = Picture[type + 'Lose'].src;

}




