function SprayView(){};

SprayView.prototype.initialize = function(i, j, type){

    this.dom = document.createElement("div");
    document.getElementById("gameWindow").appendChild(this.dom);
    this.dom.style.left = i*Game.WIDTH;
    this.dom.style.top = j*Game.HEIGHT;
    this.dom.style.display = "none";
    this.dom.setAttribute('class','spray');
    this.dom.style.zIndex = j + 3;
    var img =  document.createElement("img");
    img.src = Picture['spray'].src;
    this.dom.appendChild(img);
   
}

SprayView.prototype.show = function(){


    var dom = this.dom;
    dom.style.display = "block";

    setTimeout(function(){
        
        dom.style.display = "none"
    
    },180);
    
}