package de.madesign.TouchBeamer;

import com.leapmotion.leap.Finger;
import org.apache.commons.math3.geometry.euclidean.threed.Plane;
import org.apache.commons.math3.geometry.euclidean.threed.Vector3D;
import rx.Subscriber;
import rx.Subscription;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Objects;

/**
 * Created by Andre_Schwarz on 15.01.15.
 */
public class CalibrationController {

    // region fields
    private LeapController leapController;
    private Data data;
    private Subscription s;
    private TouchController touchController;
    private Vector3D actualFingerTipPosition;
    GUI gui;
    // endregion


    // region constructor
    public CalibrationController(Data data, LeapController leapController) {

        gui = new GUI(this, data);

        touchController = new TouchController(data, leapController);

        this.leapController = leapController;
        this.data = data;

        leapController.getLeapListener().addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                if ((boolean)evt.getNewValue()) {
                    gui.setHandAvailableIndicatorToHandTracked();
                } else {
                    gui.setHandAvailableIndicatorToNothingTracked();
                }
            }
        });
    }
    // endregion


    // region public methods
    public void calibrate(String corner) {

        s = leapController.observableFingerTipPosition.take(1).subscribe(new Subscriber<Finger>() {
            @Override
            public void onCompleted() {
                System.out.println("c");
            }

            @Override
            public void onError(Throwable e) {
                System.out.println(e);
            }

            @Override
            public void onNext(Finger finger) {

                actualFingerTipPosition = new Vector3D(finger.tipPosition().getX(), finger.tipPosition().getY(), finger.tipPosition().getZ());

                switch (corner) {
                    case "TopLeft":
                        data.setCornerTopLeft(actualFingerTipPosition);
                        System.out.println("TOPLEFT");
                        break;
                    case "TopRight":
                        data.setCornerTopRight(actualFingerTipPosition);
                        System.out.println("TOPRIGHT");
                        break;
                    case "BottomLeft":
                        data.setCornerBottomLeft(actualFingerTipPosition);
                        System.out.println("BOTTOMLEFT");
                        break;
                    case "BottomRight":
                        data.setCornerBottomRight(actualFingerTipPosition);
                        System.out.println("BOTTOMRIGHT");
                        break;
                }
            }

        });
    }

    public String createPlane() {
        if (data.getCornerTopLeft() != null && data.getCornerBottomLeft() != null && data.getCornerTopRight() != null && data.getCornerBottomRight() != null) {
            Plane touchPlane = new Plane(data.getCornerTopLeft(), data.getCornerTopRight(), data.getCornerBottomLeft(), 1);

            if (touchPlane.getOffset(data.getCornerBottomRight()) < 20 && touchPlane.getOffset(data.getCornerBottomRight()) > -20) {
                data.setTouchPlane(touchPlane);
                touchController.start();
                return "Kalibrierung ok";
            } else {
                return "Kalibrierung nicht ok, wiederholen";
            }
        }

        return "Kalibrierung nicht ok, wiederholen";
    }


    // endregion
}
