package de.madesign.TouchBeamer;

import org.apache.commons.math3.geometry.euclidean.threed.Plane;
import org.apache.commons.math3.geometry.euclidean.threed.Vector3D;

/**
 * Created by Andre_Schwarz on 15.01.15.
 */
public class Data {
    // region fields
    private Vector3D cornerTopLeft;
    private Vector3D cornerTopRight;
    private Vector3D cornerBottomLeft;
    private Vector3D cornerBottomRight;
    private Plane touchPlane;
    private int screenWidth = 1280;
    private int screenHeight = 800;
    private double screenWidthMultiplicator;
    private double screenHeightMultiplicator;
    //endregion

    //region getter
    public Vector3D getCornerTopLeft() {
        return cornerTopLeft;
    }

    public Vector3D getCornerTopRight() {
        return cornerTopRight;
    }

    public Vector3D getCornerBottomLeft() {
        return cornerBottomLeft;
    }

    public Vector3D getCornerBottomRight() {
        return cornerBottomRight;
    }

    public Plane getTouchPlane() {
        return touchPlane;
    }

    public double getScreenWidthMultiplicator() {
        screenWidthMultiplicator = screenWidth / (Vector3D.distance(cornerTopLeft, cornerTopRight));

        return screenWidthMultiplicator;
    }

    public double getScreenHeightMultiplicator() {
        screenHeightMultiplicator = screenHeight / (Vector3D.distance(cornerTopLeft, cornerBottomLeft));
        return screenHeightMultiplicator;
    }
    //endregion

    //region setter
    public void setCornerTopLeft(Vector3D cornerHeightTopLeft) {
        this.cornerTopLeft = cornerHeightTopLeft;
    }

    public void setCornerTopRight(Vector3D cornerHeightTopRight) {
        this.cornerTopRight = cornerHeightTopRight;
    }

    public void setCornerBottomLeft(Vector3D cornerHeightBottomLeft) {
        this.cornerBottomLeft = cornerHeightBottomLeft;
    }

    public void setCornerBottomRight(Vector3D cornerHeightBottomRight) {
        this.cornerBottomRight = cornerHeightBottomRight;
    }

    public void setTouchPlane(Plane touchPlane) {
        this.touchPlane = touchPlane;
    }
    //endregion
}
