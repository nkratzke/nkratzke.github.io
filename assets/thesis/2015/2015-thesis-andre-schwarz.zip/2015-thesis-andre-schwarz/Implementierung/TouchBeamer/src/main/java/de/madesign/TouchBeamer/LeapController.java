package de.madesign.TouchBeamer;

import com.leapmotion.leap.Controller;
import com.leapmotion.leap.Finger;
import org.apache.commons.math3.geometry.euclidean.threed.Vector3D;
import rx.Observable;

import java.io.IOException;

/**
 * Created by Andre_Schwarz on 15.01.15.
 */
public class LeapController {
    //region fields
    private Controller mainController;

    public LeapListener getLeapListener() {
        return leapListener;
    }

    private LeapListener leapListener;
    public Observable<Finger> observableFingerTipPosition;

    //endregion

    public LeapController() {
        startListener();
    }

    //region public methods
    public void startListener(){
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                mainController = new Controller();
                mainController.setPolicyFlags(Controller.PolicyFlag.POLICY_BACKGROUND_FRAMES);

                leapListener = new LeapListener();
                mainController.addListener(leapListener);
                observableFingerTipPosition = leapListener.fingerTipPosition.asObservable();
                System.out.println("Press Enter to quit mainListener...");
                try {
                    System.in.read();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        thread.start();
    }

    public void stopListener(){
        mainController.removeListener(leapListener);
    }
    //endregion
}
