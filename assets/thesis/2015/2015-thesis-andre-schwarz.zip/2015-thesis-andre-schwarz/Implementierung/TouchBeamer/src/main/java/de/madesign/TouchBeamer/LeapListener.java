package de.madesign.TouchBeamer;

import com.leapmotion.leap.*;
import rx.subjects.BehaviorSubject;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

/**
 * Created by Andre_Schwarz on 16.12.14.
 */

public class LeapListener extends Listener {


    //region fields
    public BehaviorSubject<Finger> fingerTipPosition = BehaviorSubject.create();
//endregion

    //region detectedObject

    public void setHasHand(boolean hasHand) {
        boolean oldValue = this.hasHand;
        this.hasHand = hasHand;

        changes.firePropertyChange("hasHand", oldValue, hasHand);
    }

    private boolean hasHand = false;

    //endregion

    private PropertyChangeSupport changes = new PropertyChangeSupport(this);


    //endregion

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changes.addPropertyChangeListener(listener);
    }


    //region public methods
    public void onInit(Controller controller) {
        System.out.println("Initialized");
    }

    public void onConnect(Controller controller) {
        System.out.println("Connected");
        controller.enableGesture(Gesture.Type.TYPE_SWIPE);
        controller.enableGesture(Gesture.Type.TYPE_CIRCLE);
        controller.enableGesture(Gesture.Type.TYPE_SCREEN_TAP);
        controller.enableGesture(Gesture.Type.TYPE_KEY_TAP);
    }

    public void onDisconnect(Controller controller) {
        System.out.println("Disconnected");
    }

    public void onExit(Controller controller) {
        System.out.println("Exited");
    }

    public void onFrame(Controller controller) { // get every frame
        Frame frame = controller.frame();

        if (frame.hands().count()>0) {
            setHasHand(true);
        } else {
            setHasHand(false);
        }

        for (Hand hand : frame.hands()) {   // check the frame for hands
            for (Finger finger : hand.fingers()) { // read the fingers on the hand
                if (finger.type() == Finger.Type.TYPE_INDEX) { // choose the index finger
                    fingerTipPosition.onNext(finger); // put the value into an subject to pass it
                }
            }
        }

    }
    //endregion
}
