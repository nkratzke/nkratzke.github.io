package de.madesign.TouchBeamer;

import com.leapmotion.leap.Controller;

import java.io.IOException;

/**
 * Created by Andre_Schwarz on 16.12.14.
 */
public class LeapMain {
    public static void main(String[] args) {
        Data data = new Data();
        LeapController leapController = new LeapController();
        CalibrationController calibrationController = new CalibrationController(data, leapController);
    }
}
