package de.madesign.TouchBeamer;

import com.leapmotion.leap.Finger;
import org.apache.commons.math3.geometry.euclidean.threed.Line;
import org.apache.commons.math3.geometry.euclidean.threed.Plane;
import org.apache.commons.math3.geometry.euclidean.threed.Vector3D;
import rx.Subscriber;
import rx.Subscription;

import java.awt.*;
import java.awt.event.InputEvent;

/**
 * Created by Andre_Schwarz on 15.01.15.
 */
public class TouchController {

    //region fields
    private Data data;
    private Plane touchPlane;
    private LeapController leapController;
    private Robot robot;
    private Line lineFinger;

    public Vector3D getIntersectionPointScreen() {
        return intersectionPointScreen;
    }

    private Vector3D intersectionPointScreen;
    private Vector3D actualFingerTipPosition;
    private boolean isPressed = false;
    //endregion

    //region constructor
    public TouchController(Data data, LeapController leapController) {
        this.leapController = leapController;
        this.data = data;

        try {
            robot = new Robot();
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }
    //endregion

    //region public methods
    public void start() {
        touchPlane = data.getTouchPlane();

        Subscription s = leapController.observableFingerTipPosition.subscribe(new Subscriber<Finger>() { //gets the finger values from the leap motion

            @Override
            public void onCompleted() {
                System.out.println("c");
            }

            @Override
            public void onError(Throwable e) {
                System.out.println(e);
            }

            @Override
            public void onNext(Finger finger) {
                createFingerLine(finger);

                if (touchPlane.intersection(lineFinger) != null) {
                    actualFingerTipPosition = new Vector3D(finger.tipPosition().getX(), finger.tipPosition().getY(), finger.tipPosition().getZ());

                    intersectionPointScreen = touchPlane.intersection(lineFinger);      //the registrated click point ist moved to a point which is really on the plane

                    if (touchPlane.getOffset(actualFingerTipPosition) < 80 && touchPlane.getOffset(actualFingerTipPosition) > -80) { //check if an actual finger is moving into the sensitive area
                        robot.mouseMove((int) (getXCoordinate(intersectionPointScreen)), (int) (getYCoordinate(intersectionPointScreen)));

                        if (touchPlane.getOffset(actualFingerTipPosition) < 25 && touchPlane.getOffset(actualFingerTipPosition) > -25) { //check if an actual finger is moving into the touch area
                            if (!isPressed) {
                                robot.mousePress(InputEvent.BUTTON1_DOWN_MASK); //use the robot to press the left mouse button
                                isPressed = true;
                            }
                        } else if (isPressed) {
                            robot.delay(100);
                            robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                            isPressed = false;
                        }
                    }
                }
            }
        });
    }

    public double getYCoordinate(Vector3D intersectionPoint) {  // caluculates the y coordinate on the computer screen
        double yCoordinateLeap = (1 - ((intersectionPoint.getY() - data.getCornerBottomLeft().getY()) /
                (data.getCornerTopLeft().getY() - data.getCornerBottomLeft().getY())));
        return yCoordinateLeap * 600;
    }

    public double getXCoordinate(Vector3D intersectionPoint) {  // caluculates the y coordinate on the computer screen
        double xCoordinateLeap = ((intersectionPoint.getX() - data.getCornerTopLeft().getX()) /
                (data.getCornerTopRight().getX() - data.getCornerTopLeft().getX()));
        return xCoordinateLeap * 800;
    }

    private void createFingerLine(Finger finger) { //  create a segment of the index finger with the finger tipPosition and an line of 20mm in the direction of the finger
        Vector3D start = new Vector3D(finger.tipPosition().getX() - 20 * finger.direction().getX(),
                finger.tipPosition().getY() - 20 * finger.direction().getY(),
                finger.tipPosition().getZ() - 20 * finger.direction().getZ());

        Vector3D end = new Vector3D(finger.tipPosition().getX() + 20 * finger.direction().getX(),
                finger.tipPosition().getY() + 20 * finger.direction().getY(),
                finger.tipPosition().getZ() + 20 * finger.direction().getZ());

        lineFinger = new Line(start, end, 1);
    }
    //endregion
}
