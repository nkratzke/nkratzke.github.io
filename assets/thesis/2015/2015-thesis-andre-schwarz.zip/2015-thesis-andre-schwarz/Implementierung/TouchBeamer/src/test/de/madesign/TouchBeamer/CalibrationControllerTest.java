package de.madesign.TouchBeamer;

import com.leapmotion.leap.Finger;
import org.apache.commons.math3.geometry.euclidean.threed.Vector3D;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import rx.subjects.BehaviorSubject;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class CalibrationControllerTest {
    Data data;
    LeapController leapController;
    CalibrationController calibrationController;
    Finger finger;
    BehaviorSubject<Finger> fingerBehaviorSubject;
    rx.Observable<Finger> fingerObservable;

    @Before
    public void setUp() throws Exception {
        data = Mockito.mock(Data.class); //mock the data class

        leapController = new LeapController();
        calibrationController = new CalibrationController(data, leapController);


        finger = new Finger();
        fingerBehaviorSubject = BehaviorSubject.create();
        fingerObservable = fingerBehaviorSubject.asObservable();
    }

    // Test for the createPlane method. This test should create a valid plane
    @Test
    public void testCreatePlaneCorrect() throws Exception {

        Mockito.when(data.getCornerTopLeft()).thenReturn(new Vector3D(1,0,0)); // when a test method calls a get method on a corner field it returns a specified value
        Mockito.when(data.getCornerTopRight()).thenReturn(new Vector3D(1,1,0));
        Mockito.when(data.getCornerBottomLeft()).thenReturn(new Vector3D(0,0,0));
        Mockito.when(data.getCornerBottomRight()).thenReturn(new Vector3D(0,1,0));

        assertEquals("Kalibrierung ok", calibrationController.createPlane());
    }

    // Test for the createPlane method. This test should create a invalid plane
    @Test
    public void testCreatePlaneIncorrect() throws Exception {

        Mockito.when(data.getCornerTopLeft()).thenReturn(new Vector3D(1,0,0));
        Mockito.when(data.getCornerTopRight()).thenReturn(new Vector3D(1,1,0));
        Mockito.when(data.getCornerBottomLeft()).thenReturn(new Vector3D(0,0,0));
        Mockito.when(data.getCornerBottomRight()).thenReturn(new Vector3D(50,50,50));

        assertEquals("Kalibrierung nicht ok, wiederholen", calibrationController.createPlane());
    }
}