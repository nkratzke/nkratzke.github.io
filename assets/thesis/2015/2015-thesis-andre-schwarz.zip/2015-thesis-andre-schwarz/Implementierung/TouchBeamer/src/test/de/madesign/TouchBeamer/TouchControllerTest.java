package de.madesign.TouchBeamer;

import org.apache.commons.math3.geometry.euclidean.threed.Vector3D;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;

public class TouchControllerTest {
    Data data;
    LeapController leapController;
    TouchController touchController;

    @Before
    public void setUp() throws Exception {
        data = Mockito.mock(Data.class);
        leapController = new LeapController();
        touchController = new TouchController(data, leapController);
    }
    // tests for calculate the coordinates
    @Test
    public void testGetYCoordinateZero() throws Exception {
        Mockito.when(data.getCornerTopLeft()).thenReturn(new Vector3D(0,12,0));
        Mockito.when(data.getCornerBottomLeft()).thenReturn(new Vector3D(0,0,0));

        assertEquals(0, touchController.getYCoordinate(new Vector3D(0,12,0)), 0);
    }

    @Test
    public void testGetYCoordinateLast() throws Exception {
        Mockito.when(data.getCornerTopLeft()).thenReturn(new Vector3D(0,12,0));
        Mockito.when(data.getCornerBottomLeft()).thenReturn(new Vector3D(0,0,0));

        assertEquals(600, touchController.getYCoordinate(new Vector3D(0,0,0)), 0);
    }

    @Test
    public void testGetXCoordinateZero() throws Exception {
        Mockito.when(data.getCornerTopLeft()).thenReturn(new Vector3D(0,12,0));
        Mockito.when(data.getCornerTopRight()).thenReturn(new Vector3D(12,12,0));

        assertEquals(0, touchController.getXCoordinate(new Vector3D(0,0,0)), 0);
    }

    @Test
    public void testGetXCoordinateLast() throws Exception {
        Mockito.when(data.getCornerTopLeft()).thenReturn(new Vector3D(0,12,0));
        Mockito.when(data.getCornerTopRight()).thenReturn(new Vector3D(12,12,0));

        assertEquals(800, touchController.getXCoordinate(new Vector3D(12,12,0)), 0);
    }

}