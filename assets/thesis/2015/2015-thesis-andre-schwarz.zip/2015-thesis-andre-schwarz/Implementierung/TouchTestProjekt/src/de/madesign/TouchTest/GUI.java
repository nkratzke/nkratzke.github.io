package de.madesign.TouchTest;

import javax.swing.*;

/**
 * Created by Andre on 01.03.15.
 */
public class GUI {
    private JButton button1;
    private JButton button2;
    private JButton button3;
    private JButton button4;
    private JSlider slider1;
    private JPanel panel1;
    private JPanel jPanel;

    public GUI() {
        JFrame frame = new JFrame("GUI");
        frame.setContentPane(panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

        init();
    }

    private void init() {
        slider1.setValue(0);

        button1.addActionListener(e -> {
            button1.setEnabled(false);
        });
        button2.addActionListener(e -> {
            button2.setEnabled(false);
        });
        button3.addActionListener(e -> {
            button3.setEnabled(false);
        });
        button4.addActionListener(e -> {
            button4.setEnabled(false);
        });

        slider1.addChangeListener(e -> {
            if(slider1.getValue() == slider1.getMaximum()){
                slider1.setEnabled(false);
            }
        });
    }


}
