package de.madesign.TouchTest;

/**
 * Created by Andre on 01.03.15.
 */
public class TouchTestMain {
    private static GUI gui;


    public static void main(String[] args) {

        gui = new GUI();
        System.out.print("test");
    }
}
