#import <CoreBluetooth/CoreBluetooth.h>


@interface CBSpeedTester : NSObject <CBCentralManagerDelegate, CBPeripheralDelegate>

@property(nonatomic) CBCentralManager *centralManager;
@property(nonatomic) CBPeripheral *peripheral;
@property(nonatomic) CBService *service;
@property(nonatomic) CBCharacteristic *characteristic;

@end


@implementation CBSpeedTester


- (instancetype)init {
    self = [super init];
    if (self) {
        _centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:dispatch_get_main_queue()];
    }
    return self;
}


- (void)centralManagerDidUpdateState:(CBCentralManager *)central {
    if (central.state == 5) {
        self.startDate = [NSDate date];

        // scan for peripherals
        [self.centralManager scanForPeripheralsWithServices:nil options:nil];
    }
}

- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI {
    if (RSSI.integerValue > -15) {
        return;
    }

    self.peripheral = peripheral;
    self.peripheral.delegate = self;
    [central stopScan];

    // connect to peripheral
    [central connectPeripheral:peripheral options:nil];
}

- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral {
    if (peripheral == self.peripheral) {

        // discover services
        [self.peripheral discoverServices:nil];
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error {
    if (!error && peripheral == self.peripheral) {
        CBUUID *testServiceUUID = [CBUUID UUIDWithString:@"AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA"];
        for (CBService *service in peripheral.services) {
            if ([service.UUID isEqual:testServiceUUID]) {
                self.service = service;

                // discover characteristic
                [self.peripheral discoverCharacteristics:nil forService:self.service];
            }
        }
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error {
    if (!error && service == self.service) {
        CBUUID *testCharacteristicUUID = [CBUUID UUIDWithString:@"BBBBBBBB-BBBB-BBBB-BBBB-BBBBBBBBBBBB"];
        for (CBCharacteristic *characteristic in self.service.characteristics) {
            if ([characteristic.UUID isEqual:testCharacteristicUUID]) {
                self.characteristic = characteristic;

                // read characteristic
                [self.peripheral readValueForCharacteristic:self.characteristic];
            }
        }
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
    if (!error) {
        NSLog(@"Characteristic Value: %@", characteristic.value);

        // write characteristic
        [self.peripheral writeValue:[@"Test" dataUsingEncoding:NSUTF8StringEncoding] forCharacteristic:self.characteristic type:CBCharacteristicWriteWithResponse];
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
    if (!error && characteristic == self.characteristic) {
        
        // disconnect peripheral
        [self.centralManager cancelPeripheralConnection:self.peripheral];
    }
}


@end
