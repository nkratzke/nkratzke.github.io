#import <CoreBluetooth/CoreBluetooth.h>


@interface CoreBluetoothImplementationPeripheral : NSObject <CBPeripheralManagerDelegate>

@property(nonatomic) CBPeripheralManager *peripheralManager;
@property(nonatomic) CBMutableService *testService;
@property(nonatomic) CBMutableCharacteristic *testCharacteristic;

@end


@implementation CoreBluetoothImplementationPeripheral

- (instancetype)init {
    self = [super init];
    if (self) {
        _peripheralManager = [[CBPeripheralManager alloc] initWithDelegate:self queue:nil];
        [self setup];
    }
    return self;
}

- (void)setup {
    CBUUID *testServiceUUID = [CBUUID UUIDWithString:@"AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA"];
    CBUUID *testCharacteristicUUID = [CBUUID UUIDWithString:@"BBBBBBBB-BBBB-BBBB-BBBB-BBBBBBBBBBBB"];

    // create attributes structure
    self.testService = [[CBMutableService alloc] initWithType:testServiceUUID primary:YES];
    self.testCharacteristic = [[CBMutableCharacteristic alloc] initWithType:testCharacteristicUUID properties:(CBCharacteristicPropertyRead | CBCharacteristicPropertyWrite) value:nil permissions:(CBAttributePermissionsReadable | CBAttributePermissionsWriteable)];
    self.testService.characteristics = @[self.testCharacteristic];
}

- (void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral {
    if (peripheral.state == 5) {
        // publish attributes
        [self.peripheralManager addService:self.testService];
    }
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral didAddService:(CBService *)service error:(NSError *)error {
    if (error) {
        return;
    }

    // set characteristic value
    self.testCharacteristic.value = [@"TEST-VALUE" dataUsingEncoding:NSUTF8StringEncoding];

    // set device name & start advertising
    [self.peripheralManager startAdvertising:@{CBAdvertisementDataLocalNameKey : @"TEST-DEVICE",
            CBAdvertisementDataServiceUUIDsKey : @[self.testService.UUID]}];
}

// read request handling
- (void)peripheralManager:(CBPeripheralManager *)peripheral didReceiveReadRequest:(CBATTRequest *)request {
    if (request.offset > self.testCharacteristic.value.length) {
        [self.peripheralManager respondToRequest:request withResult:CBATTErrorInvalidOffset];
        return;
    }
    request.value = [self.testCharacteristic.value subdataWithRange:NSMakeRange(request.offset,
            self.testCharacteristic.value.length - request.offset)];
    [self.peripheralManager respondToRequest:request withResult:CBATTErrorSuccess];
}

// write request handling
- (void)peripheralManager:(CBPeripheralManager *)peripheral didReceiveWriteRequests:(NSArray *)requests {
    for (CBATTRequest *request in requests) {
        self.testCharacteristic.value = request.value;
        [self.peripheralManager respondToRequest:request withResult:CBATTErrorSuccess];
    }
}

@end