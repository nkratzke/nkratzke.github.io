#import <ReactiveBluetoothLE/ReactiveBluetoothLE.h>


@interface ReactiveImplementationPeripheral : NSObject

@property(nonatomic) RBTPeripheralModule *peripheralModule;
@property(nonatomic) RBTMutableService *testService;
@property(nonatomic) RBTMutableCharacteristic *testCharacteristic;

@end


@implementation ReactiveImplementationPeripheral

- (instancetype)init {
    self = [super init];
    if (self) {
        _peripheralModule = [[RBTPeripheralModule alloc] init];
        [self setup];
    }
    return self;
}

- (void)setup {
    CBUUID *testServiceUUID = [CBUUID UUIDWithString:@"AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA"];
    CBUUID *testCharacteristicUUID = [CBUUID UUIDWithString:@"BBBBBBBB-BBBB-BBBB-BBBB-BBBBBBBBBBBB"];

    // set device name
    self.peripheralModule.name = @"TEST-DEVICE";

    // create attributes structure
    self.testService = [[RBTMutableService alloc] initPrimaryServiceWithUUID:testServiceUUID];
    self.testCharacteristic = [[RBTMutableCharacteristic alloc]
                        initWithUUID:testCharacteristicUUID
                          properties:(CBCharacteristicPropertyRead | CBCharacteristicPropertyWrite)
                               value:nil
                         permissions:(CBAttributePermissionsReadable | CBAttributePermissionsWriteable)];

    @weakify(self)
    [[self.peripheralModule.peripheralState filter:^BOOL(NSNumber *state) {
        return state.intValue == 5;
    }] subscribeNext:^(id x) {
        @strongify(self)

        // publish attributes
        [self.testService addCharacteristic:self.testCharacteristic];
        [[self.peripheralModule addService:self.testService] subscribeCompleted:^{
            @strongify(self)

            // set characteristic value
            self.testCharacteristic.value = [@"TEST-VALUE" dataUsingEncoding:NSUTF8StringEncoding];

            // start advertising
            [self.peripheralModule startAdvertising];
        }];
    }];
}

@end
