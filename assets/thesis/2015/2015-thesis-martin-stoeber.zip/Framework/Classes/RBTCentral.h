//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <ReactiveCocoa/ReactiveCocoa.h>

#import "RBTPeripheralModule.h"


@interface RBTCentral : NSObject

/// CoreBluetooth central
@property(nonatomic, readonly) CBCentral *cbCental;

/// Parrent peripheral module
@property(nonatomic, readonly) RBTPeripheralModule *peripheralModule;

/// Unique identifier of this central
@property(nonatomic, readonly) NSUUID *identifier;

/// Maximum transmission unit for a value (e.g. a characteristic)
@property(nonatomic, readonly) NSUInteger maximumUpdateValueLength;


/**
*  Designated initializer, should not be used manually.
*/
- (instancetype)initWithCentral:(CBCentral *)cbCentral ofPeripheralModule:(RBTPeripheralModule *)peripheralModule;


/// Sets the desired connection latency for an existing connection to central
- (void)setDesiredConnectionLatency:(CBPeripheralManagerConnectionLatency)latency;

@end
