//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTCentral.h"


@implementation RBTCentral

#pragma mark - initialization

- (instancetype)initWithCentral:(CBCentral *)cbCentral ofPeripheralModule:(RBTPeripheralModule *)peripheralModule {
    self = [super init];
    if (self) {
        _cbCental = cbCentral;
        _peripheralModule = peripheralModule;
    }
    return self;
}


#pragma mark - Property getter

- (NSUUID *)identifier {
    return self.cbCental.identifier;
}

- (NSUInteger)maximumUpdateValueLength {
    return self.cbCental.maximumUpdateValueLength;
}


#pragma mark - Public methods

- (void)setDesiredConnectionLatency:(CBPeripheralManagerConnectionLatency)latency {
    [self.peripheralModule.cbPeripheralManager setDesiredConnectionLatency:latency forCentral:self.cbCental];
}


@end
