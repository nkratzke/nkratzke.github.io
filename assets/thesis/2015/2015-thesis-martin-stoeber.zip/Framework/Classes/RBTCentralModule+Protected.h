//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RBTCentralModule.h"

/// Protected extension to interact in a private scope with RBTPeripheral
@interface RBTCentralModule (Protected)

@property(nonatomic) RACSignal *peripheralConnectedSignal;
@property(nonatomic) RACSignal *peripheralDisconnectedSignal;
@property(nonatomic) RACSignal *peripheralConnectionFailedSignal;

@end
