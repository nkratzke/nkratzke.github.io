//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <ReactiveCocoa/ReactiveCocoa.h>
#import <ReactiveCocoa/RACEXTScope.h>


@interface RBTCentralModule : NSObject <CBCentralManagerDelegate>

/// CoreBluetooth manager
@property(nonatomic, readonly) CBCentralManager *cbCentralManager;

//// Current bluetooth state as Signal, last connection state will just send after subscription
@property(nonatomic, readonly) RACSignal *bluetoothState;

/// Signal which is send when the cental is scanning
@property(nonatomic, readonly) RACSignal *scanState;

/// Scanstate as boolean (true -> scanning)
@property(readonly, getter=isScanning) BOOL scanning;

/// Signal which is send when a peripheral did connect
@property(nonatomic, readonly) RACSignal *peripheralConnected;

/// Signal which is send when a peripheral did disconnect
@property(nonatomic, readonly) RACSignal *peripheralDisconnected;


/// Start scanning, signal send found peripherals
- (RACSignal *)scan;

/// Start scanning and allow duplicates, signal send found peripherals
- (RACSignal *)scanWithDuplicates:(BOOL)allowDuplicates;

/// Start scanning for peripherals with the given service-UUIDs, signal send found peripherals
- (RACSignal *)scanForPeripheralsWithServices:(NSArray *)services;

/// Scan with peripherals, which have a lower RSSI as given, signal send found peripherals
- (RACSignal *)scanWithMaxRSSI:(NSNumber *)RSSI;

/// Scan with peripherals, which have a lower RSSI as given and allow duplicates, signal send found peripherals
- (RACSignal *)scanWithDuplicatesAndMaxRSSI:(NSNumber *)maxRSSI;

/// Start scanning for peripherals with the given service-UUIDs for a given timeinterval and max RSSI, signal send found peripherals
- (RACSignal *)scanForPeripheralsWithServices:(NSArray *)services forTimeinterval:(NSTimeInterval)time
                               withDuplicates:(BOOL)allowDuplicates maxRSSI:(NSNumber *)maxRSSI;

/// Stop scanning
- (void)stopScan;


/// Retives a sequence with all current connected peripherals
- (RACSequence *)retrieveConnectedPeripherals;

/// Retives a sequence with all current connected peripherals to this device.
/// You must call connect if the peripheral is not connected to this central instance.
- (RACSequence *)retrieveDeviceConnectedPeripheralsWithServices:(NSArray *)serviceUUIDs;

/// Retives a sequence with all current known peripherals to this central instance.
- (RACSequence *)retrieveKnownPeripheralsWithIdentifiers:(NSArray *)identifiers;

@end
