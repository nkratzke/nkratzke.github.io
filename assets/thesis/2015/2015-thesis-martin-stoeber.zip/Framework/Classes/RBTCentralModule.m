//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//


#import "RBTCentralModule.h"
#import "RBTPeripheral.h"
#import "RBTPeripheral+Protected.h"


@interface RBTCentralModule () {
    RACSubject *_peripheralConnectedSubject;
    RACSubject *_peripheralDisconnectedSubject;
}

@property(nonatomic) RACSubject *discoveredPeripheralsSubject;

@property NSMutableDictionary *knownPeripherals;
@property NSMutableDictionary *connectedPeripherals;

@property BOOL scanning;

@property(nonatomic) RACSignal *peripheralConnectedSignal;
@property(nonatomic) RACSignal *peripheralDisconnectedSignal;
@property(nonatomic) RACSignal *peripheralConnectionFailedSignal;

@end


@implementation RBTCentralModule

@synthesize peripheralConnected = _peripheralConnectedSubject;
@synthesize peripheralDisconnected = _peripheralDisconnectedSubject;


#pragma mark - Initialization

- (instancetype)init {
    self = [super init];
    if (self) {
        [self setupCentralModule];
    }
    return self;
}

- (void)setupCentralModule {
    _cbCentralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];

    _bluetoothState = [[[self rac_signalForSelector:@selector(centralManagerDidUpdateState:)
                                       fromProtocol:@protocol(CBCentralManagerDelegate)]
            map:^NSNumber *(RACTuple *tuple) {
                RACTupleUnpack(CBCentralManager *centralManager) = tuple;
                return @(centralManager.state);
            }] replayLast];
    _scanState = RACObserve(self, scanning);

    _peripheralConnectedSignal = [self rac_signalForSelector:@selector(centralManager:didConnectPeripheral:)
                                                fromProtocol:@protocol(CBCentralManagerDelegate)];

    _peripheralDisconnectedSignal = [self rac_signalForSelector:@selector(centralManager:didDisconnectPeripheral:error:)
                                                   fromProtocol:@protocol(CBCentralManagerDelegate)];

    _peripheralConnectionFailedSignal = [self rac_signalForSelector:@selector(centralManager:didFailToConnectPeripheral:error:)
                                                       fromProtocol:@protocol(CBCentralManagerDelegate)];
    _discoveredPeripheralsSubject = [RACSubject subject];

    _peripheralConnectedSubject = [RACSubject subject];
    _peripheralDisconnectedSubject = [RACSubject subject];

    _knownPeripherals = [NSMutableDictionary dictionary];
    _connectedPeripherals = [NSMutableDictionary dictionary];
}


#pragma mark - public methods

- (RACSignal *)scan {
    return [self scanWithDuplicates:NO];
}

- (RACSignal *)scanWithDuplicates:(BOOL)allowDuplicates {
    return [self scanForPeripheralsWithServices:nil forTimeinterval:0 withDuplicates:allowDuplicates maxRSSI:nil];
}

- (RACSignal *)scanForPeripheralsWithServices:(NSArray *)services {
    return [self scanForPeripheralsWithServices:services forTimeinterval:0 withDuplicates:NO maxRSSI:nil];
}

- (RACSignal *)scanWithMaxRSSI:(NSNumber *)maxRSSI {
    return [self scanForPeripheralsWithServices:nil forTimeinterval:0 withDuplicates:NO maxRSSI:maxRSSI];
}

- (RACSignal *)scanWithDuplicatesAndMaxRSSI:(NSNumber *)maxRSSI {
    return [self scanForPeripheralsWithServices:nil forTimeinterval:0 withDuplicates:YES maxRSSI:maxRSSI];
}

- (RACSignal *)scanForPeripheralsWithServices:(NSArray *)services forTimeinterval:(NSTimeInterval)time
                               withDuplicates:(BOOL)allowDuplicates maxRSSI:(NSNumber *)maxRSSI {
    if (self.scanning) {
        [self stopScan];
    }

    [self.cbCentralManager scanForPeripheralsWithServices:services options:@{CBCentralManagerScanOptionAllowDuplicatesKey : (allowDuplicates ? @YES : @NO)}];
    self.scanning = YES;

    if (time > 0) {
        [NSTimer scheduledTimerWithTimeInterval:time target:self selector:@selector(handleScanTimer:) userInfo:nil repeats:NO];
    }

    if (maxRSSI) {
        return [self.discoveredPeripheralsSubject filter:^BOOL(RBTPeripheral *peripheral) {
            return (peripheral.RSSI <= maxRSSI);
        }];
    }

    return self.discoveredPeripheralsSubject;
}

- (void)stopScan {
    self.scanning = NO;
    [self.cbCentralManager stopScan];
}

- (RACSequence *)retrieveConnectedPeripherals {
    return [self.connectedPeripherals rac_valueSequence];
}

- (RACSequence *)retrieveDeviceConnectedPeripheralsWithServices:(NSArray *)serviceUUIDs {
    NSArray *connectedCBPeripherals = [self.cbCentralManager retrieveConnectedPeripheralsWithServices:serviceUUIDs];
    NSArray *connectedPeripherals = [self wrapPeripherals:connectedCBPeripherals];
    return [connectedPeripherals rac_sequence];
}

- (RACSequence *)retrieveKnownPeripheralsWithIdentifiers:(NSArray *)identifiers {
    NSArray *knownCBPeripherals = [self.cbCentralManager retrievePeripheralsWithIdentifiers:identifiers];
    NSArray *knownPeripherals = [self wrapPeripherals:knownCBPeripherals];
    return [knownPeripherals rac_sequence];
}


#pragma mark - Private helper methods

- (RBTPeripheral *)wrapPeripheral:(CBPeripheral *)cbPeripheral {
    if (!self.knownPeripherals[cbPeripheral.identifier]) {
        RBTPeripheral *newPeripheral = [[RBTPeripheral alloc] initWithPeripheral:cbPeripheral
                                                               fromCentralModule:self];
        self.knownPeripherals[cbPeripheral.identifier] = newPeripheral;
    }
    return self.knownPeripherals[cbPeripheral.identifier];
}

- (NSArray *)wrapPeripherals:(NSArray *)cbPeripherals {
    NSMutableArray *peripherals = [NSMutableArray array];
    for (CBPeripheral *cbPeripheral in cbPeripherals) {
        [peripherals addObject:[self wrapPeripheral:cbPeripheral]];
    }
    return peripherals;
}

- (void)handleScanTimer:(NSTimer *)timer {
    [timer invalidate];
    [self stopScan];
}


#pragma mark - CBCentralManagerDelegate methods

- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI {
    RBTPeripheral *discoverdPeripheral = [self wrapPeripheral:peripheral];
    discoverdPeripheral.advertismentData = advertisementData;
    discoverdPeripheral.RSSI = RSSI;

    [self.discoveredPeripheralsSubject sendNext:discoverdPeripheral];
}

- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral {
    RBTPeripheral *connectedPeripheral = [self wrapPeripheral:peripheral];
    self.connectedPeripherals[peripheral.identifier] = connectedPeripheral;

    [_peripheralConnectedSubject sendNext:connectedPeripheral];
}

- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    RBTPeripheral *disconnectedPeripheral = [self wrapPeripheral:peripheral];
    [self.connectedPeripherals removeObjectForKey:peripheral.identifier];

    [_peripheralDisconnectedSubject sendNext:disconnectedPeripheral];
}


#pragma mark - CBCentralManagerDelegate stub methods

- (void)centralManagerDidUpdateState:(CBCentralManager *)central {
}

- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
}

#pragma mark - Debugging

- (NSString *)description {
    return [NSString stringWithFormat:@"<%@: %p - State: %ld, Scanning: %@>",
                                      [self class], &self, (long) self.cbCentralManager.state, self.isScanning ? @"YES" : @"NO"];
}


@end
