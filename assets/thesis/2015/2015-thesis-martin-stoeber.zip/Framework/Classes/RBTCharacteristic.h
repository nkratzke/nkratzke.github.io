//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <ReactiveCocoa/ReactiveCocoa.h>
#import <ReactiveCocoa/RACEXTScope.h>

@class RBTPeripheral, RBTService;

@interface RBTCharacteristic : NSObject

/// Parrent peripheral
@property(weak, nonatomic, readonly) RBTPeripheral *peripheral;

/// Parrent Service
@property(weak, nonatomic, readonly) RBTService *service;

/// CoreBluetooth characteristic
@property(nonatomic, readonly) CBCharacteristic *cbCharacteristic;

/// Identifier of the characteristic
@property(nonatomic, readonly) CBUUID *UUID;

/// Flag whether the characteristic is notifying to centrals
@property(nonatomic, getter=isNotifying) BOOL notifying;

/// Properties (access rights / freatures) of the characteristic (e.g. readable, writable...)
@property(nonatomic, readonly) CBCharacteristicProperties properties;

/// Current value of the characteristic
@property(readonly) NSData *value;

/// Current value as signal
@property(nonatomic, readonly) RACSignal *valueSignal;

/// Related descriptors of the characteristic
@property(nonatomic, readonly) RACSequence *descriptors;


/**
*  Designated initializer, should not be used manually.
*/
- (instancetype)initWithCBCharacteristic:(CBCharacteristic *)cbCharacteristic ofService:(RBTService *)service;


/// Trigger to read the value of the characteristic.  Returns a signal which completed when successful.
- (RACSignal *)readValue;

/// Write data for a characteristic without response
- (void)writeValue:(NSData *)data;

/// Write data for a characteristic with response.
- (RACSignal *)writeValue:(NSData *)data withResponse:(BOOL)response;


/// Set the Characteristic to Notifying or not. Returns a signal which completed when successful.
- (RACSignal *)setNotifyingStatus:(BOOL)notifying;


/// Retives the related descripors of the characteristic.
/// Returns a signal which completed when successful.
- (RACSignal *)discoverDescriptors;

@end
