//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTCharacteristic.h"
#import "RBTPeripheral+Protected.h"
#import "RBTDescriptor.h"
#import "RBTService.h"

@interface RBTCharacteristic ()

@property(readwrite) NSData *value;
@property NSMutableDictionary *descriptorsDictionary;

@end


@implementation RBTCharacteristic

#pragma mark - initialization

- (instancetype)initWithCBCharacteristic:(CBCharacteristic *)cbCharacteristic ofService:(RBTService *)service; {
    self = [super init];
    if (self) {
        _cbCharacteristic = cbCharacteristic;
        _service = service;
        _peripheral = service.peripheral;
        [self setupMSCharacteristic];
    }
    return self;
}

- (void)setupMSCharacteristic {
    _valueSignal = RACObserve(self.cbCharacteristic, value);
    _descriptorsDictionary = [NSMutableDictionary dictionary];

    [self.valueSignal subscribeNext:^(NSData *value) {
        self.value = value;
    }];
}


#pragma mark - Public methods

- (RACSignal *)readValue {
    @weakify(self);
    RACSignal *readSignal = [RACSignal createSignal:^RACDisposable *(id <RACSubscriber> subscriber) {
        @strongify(self);
        [self.peripheral.cbPeripheral readValueForCharacteristic:self.cbCharacteristic];

        [[[self.peripheral.didUpdateValueForCharacteristicSignal filter:^BOOL(RACTuple *updatedValueTuple) {
            @strongify(self);
            RACTupleUnpack(CBPeripheral *peripheral, CBCharacteristic *characteristic) = updatedValueTuple;
            return (peripheral == self.peripheral.cbPeripheral && characteristic == self.cbCharacteristic);
        }] take:1] subscribeNext:^(RACTuple *updatedValueTuple) {
            NSError *error = [updatedValueTuple third];
            if (!error) {
                [subscriber sendNext:self.cbCharacteristic.value];
                [subscriber sendCompleted];
            } else {
                [subscriber sendError:error];
            }

        }];
        return nil;
    }];
    return readSignal;
}

- (void)writeValue:(NSData *)data {
    [self writeValue:data withResponse:NO];
}

- (RACSignal *)writeValue:(NSData *)data withResponse:(BOOL)response {
    [self.peripheral.cbPeripheral writeValue:data
                           forCharacteristic:self.cbCharacteristic
                                        type:(response ? CBCharacteristicWriteWithResponse : CBCharacteristicWriteWithoutResponse)];
    @weakify(self)
    RACSignal *writeSignal = [RACSignal createSignal:^RACDisposable *(id <RACSubscriber> subscriber) {
        @strongify(self)
        [[[self.peripheral.didWriteValueForCharacteristicSignal filter:^BOOL(RACTuple *writtenValueTuple) {
            @strongify(self)
            RACTupleUnpack(CBPeripheral *peripheral, CBCharacteristic *characteristic) = writtenValueTuple;
            return (peripheral == self.peripheral.cbPeripheral && characteristic == self.cbCharacteristic);
        }] take:1] subscribeNext:^(RACTuple *writtenValueTuple) {
            NSError *error = [writtenValueTuple third];
            if (!error) {
                [subscriber sendCompleted];
            } else {
                [subscriber sendError:error];
            }
        }];
        return nil;
    }];

    return writeSignal;
}

- (RACSignal *)setNotifyingStatus:(BOOL)notifying {
    [self.peripheral.cbPeripheral setNotifyValue:notifying forCharacteristic:self.cbCharacteristic];

    @weakify(self)
    RACSignal *setterSignal = [RACSignal createSignal:^RACDisposable *(id <RACSubscriber> subscriber) {
        @strongify(self)
        [[[self.peripheral.didUpdateNotificationState filter:^BOOL(RACTuple *notificationStateTuple) {
            @strongify(self)
            RACTupleUnpack(CBPeripheral *peripheral, CBCharacteristic *characteristic) = notificationStateTuple;
            return (peripheral == self.peripheral.cbPeripheral && characteristic == self.cbCharacteristic);
        }] take:1] subscribeNext:^(RACTuple *notificationStateTuple) {
            NSError *error = [notificationStateTuple third];
            if (!error) {
                [subscriber sendCompleted];
            } else {
                [subscriber sendError:error];
            }
        }];
        return nil;
    }];

    return setterSignal;
}

- (RACSignal *)discoverDescriptors {
    [self.peripheral.cbPeripheral discoverDescriptorsForCharacteristic:self.cbCharacteristic];

    @weakify(self)
    RACSignal *discoverDescriptorsSignal = [RACSignal createSignal:^RACDisposable *(id <RACSubscriber> subscriber) {
        @strongify(self)
        [[[self.peripheral.didDiscoverDescriptorsForCharacteristic filter:^BOOL(RACTuple *discoveredDescriptorsTuple) {
            RACTupleUnpack(CBPeripheral *peripheral, CBCharacteristic *characteristic) = discoveredDescriptorsTuple;
            @strongify(self)
            return (peripheral == self.peripheral.cbPeripheral && characteristic == self.cbCharacteristic);
        }] take:1] subscribeNext:^(RACTuple *discoveredCharacteristicsTuple) {
            @strongify(self);
            NSError *error = [discoveredCharacteristicsTuple third];
            if (!error) {

                for (CBDescriptor *cbDescriptor in self.cbCharacteristic.descriptors) {
                    if (!self.descriptorsDictionary[cbDescriptor.UUID]) {
                        self.descriptorsDictionary[cbDescriptor.UUID] = [[RBTDescriptor alloc] initWithCBDescriptor:cbDescriptor
                                                                                                   ofCharacteristic:self];
                    }
                }

                [subscriber sendNext:self.descriptors];
                [subscriber sendCompleted];
            } else
                [subscriber sendError:error];
        }];
        return nil;
    }];

    return discoverDescriptorsSignal;
}


#pragma mark - Property getter/setter

- (BOOL)isNotifying {
    return self.cbCharacteristic.isNotifying;
}

- (void)setNotifying:(BOOL)notifying {
    [self.peripheral.cbPeripheral setNotifyValue:notifying forCharacteristic:self.cbCharacteristic];
}

- (RACSequence *)descriptors {
    return [self.descriptorsDictionary rac_valueSequence];
}

#pragma mark - Debugging

- (NSString *)description {
    return [NSString stringWithFormat:@"<%@: %p, Service: %p , Peripheral: %p "
                                              "- Value: %@, Notifying: %d, Properties: %lu>",
                                      [self class], &self, &_service, &_peripheral, self.value, self.notifying, (unsigned long) self.properties];
}

@end

