//
// Created by Martin Stöber on 14.01.15.
// Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CBATTRequest;

@protocol RBTCharacteristicRequestDelegate <NSObject>
@required

/**
* Invoked when characteristic receives a read request.
*
* For every invocation of this method, respondToRequest:withResult: must be called.
*/
- (void)handleReadRequest:(CBATTRequest *)request;

/**
* Invoked when characteristic receives a write request.
*
* For every invocation of this method, respondToRequest:withResult: must be called.
*/
- (void)handleWriteRequest:(CBATTRequest *)request;


@end
