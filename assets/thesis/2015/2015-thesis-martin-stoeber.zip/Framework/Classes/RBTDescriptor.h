//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <ReactiveCocoa/ReactiveCocoa.h>
#import <ReactiveCocoa/RACEXTScope.h>

@class RBTPeripheral, RBTCharacteristic, RBTService;

@interface RBTDescriptor : NSObject

/// Parrent Characteristic
@property(weak, nonatomic, readonly) RBTCharacteristic *characteristic;

/// Parrent Service
@property(weak, nonatomic, readonly) RBTService *service;

/// Parrent Peripheral
@property(weak, nonatomic, readonly) RBTPeripheral *peripheral;

/// Wrapped CoreBluetooth descriptor
@property(nonatomic, readonly) CBDescriptor *cbDescriptor;

/// Identifier of the characteristic
@property(nonatomic, readonly) CBUUID *UUID;

/// Current Value of the descriptor.
@property(nonatomic, readonly) id value;

/**
*  Designated initializer, should not be used manually.
*/
- (instancetype)initWithCBDescriptor:(CBDescriptor *)cbDescriptor ofCharacteristic:(RBTCharacteristic *)characteristic;

/// Retrive the current value of the descriptor
- (RACSignal *)readValue;

/// Write data to the descriptor
- (RACSignal *)writeValue:(NSData *)data;

@end
