//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTDescriptor.h"
#import "RBTCharacteristic.h"
#import "RBTService.h"
#import "RBTPeripheral+Protected.h"


@implementation RBTDescriptor

#pragma mark - Initialization

- (instancetype)initWithCBDescriptor:(CBDescriptor *)cbDescriptor ofCharacteristic:(RBTCharacteristic *)characteristic {
    self = [super init];
    if (self) {
        _cbDescriptor = cbDescriptor;
        _characteristic = characteristic;
        _service = characteristic.service;
        _peripheral = characteristic.service.peripheral;
    }
    return self;
}


#pragma mark - Property getter

- (id)value {
    return self.cbDescriptor.value;
}


#pragma mark - Public methods

- (RACSignal *)readValue {
    [self.peripheral.cbPeripheral readValueForDescriptor:self.cbDescriptor];

    @weakify(self);
    RACSignal *readSignal = [RACSignal createSignal:^RACDisposable *(id <RACSubscriber> subscriber) {
        [[[self.peripheral.didUpdateValueForDescriptorSignal filter:^BOOL(RACTuple *updateValueTuple) {
            @strongify(self);
            RACTupleUnpack(CBPeripheral *cbPeripheral, CBDescriptor *descriptor) = updateValueTuple;

            return (cbPeripheral == self.peripheral.cbPeripheral && descriptor == self.cbDescriptor);
        }] take:1] subscribeNext:^(RACTuple *updateValueTuple) {
            NSError *error = [updateValueTuple third];
            if (!error) {
                [subscriber sendNext:self.cbDescriptor.value];
                [subscriber sendCompleted];
            } else {
                [subscriber sendError:error];
            }
        }];

        return nil;
    }];
    return readSignal;
}

- (RACSignal *)writeValue:(NSData *)data {
    [self.peripheral.cbPeripheral writeValue:data forDescriptor:self.cbDescriptor];

    @weakify(self)
    RACSignal *writeSignal = [RACSignal createSignal:^RACDisposable *(id <RACSubscriber> subscriber) {
        @strongify(self)
        [[[self.peripheral.didWriteValueForDescriptor filter:^BOOL(RACTuple *writtenValueForDescriptorTuple) {
            @strongify(self)
            RACTupleUnpack(CBPeripheral *peripheral, CBDescriptor *descriptor) = writtenValueForDescriptorTuple;
            return (peripheral == self.peripheral.cbPeripheral && descriptor == self.cbDescriptor);
        }] take:1] subscribeNext:^(RACTuple *writtenValueTuple) {
            NSError *error = [writtenValueTuple third];
            if (!error) {
                [subscriber sendCompleted];
            } else {
                [subscriber sendError:error];
            }
        }];
        return nil;
    }];

    return writeSignal;
}


#pragma mark - Debugging

- (NSString *)description {
    return [NSString stringWithFormat:@"< %@: %p - Value: %@>", [self class], &self, self.value];
}

@end
