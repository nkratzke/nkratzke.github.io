//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <ReactiveCocoa/ReactiveCocoa.h>
#import "RBTMutableDescriptor.h"

@class RBTMutableService, RBTMutableDescriptor;
@protocol RBTCharacteristicRequestDelegate;


@interface RBTMutableCharacteristic : NSObject

/// Parrent service, will be available after the characteristic is added to a service
@property(nonatomic, weak) RBTMutableService *service;

/// CoreBluetooth characteristic
@property(nonatomic, readonly) CBMutableCharacteristic *cbCharacteristic;

/// Delegate to handle read/write requests. Standard handling will be used if not set
@property(nonatomic, weak) id <RBTCharacteristicRequestDelegate> delegate;

/// Identifier of the characteristic
@property(nonatomic) CBUUID *UUID;

/// Properties of the characteristics
@property(nonatomic) CBCharacteristicProperties properties;

/// Permissons of access of this characteristic
@property(nonatomic) CBAttributePermissions permissions;

/// Flag whether the characteristic was added to a service an published to a peripheral module
@property(nonatomic, readonly, getter=isPublished) BOOL published;

/// Descriptors of the characteristic
@property NSArray *descriptors;

/// Current value of the characteristic
@property NSData *value;


/**
* Create a new characteristic to publish to a peripheral module.
* If you want a dynamic value you must pass nil to value.
*/
- (instancetype)initWithUUID:(CBUUID *)UUID properties:(CBCharacteristicProperties)properties
                       value:(NSData *)value permissions:(CBAttributePermissions)permissions;


/// Add a descriptor to this characteristic
- (void)addDescriptor:(RBTMutableDescriptor *)descriptor;

/// Remove a descriptor from this characteristic
- (void)removeDescriptor:(RBTMutableDescriptor *)descriptor;


/// Sends an updated characteristic value to one or more centrals, via a notification or indication.
/// CBCharacteristicPropertyIndicate or CBCharacteristicPropertyNotify must be set to the properties.
/// Returns YES when successful, NO when the not e.g. due a full queue.
- (BOOL)notifySubscribedCentrals;


@end