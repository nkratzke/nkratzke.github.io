//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <CoreBluetooth/CoreBluetooth.h>
#import <ReactiveCocoa/RACSequence.h>
#import "RBTMutableCharacteristic.h"
#import "RBTMutableService.h"
#import "RBTPeripheralModule.h"


@interface RBTMutableCharacteristic () {
@private
    NSMutableArray *_descriptors;
}

@property(nonatomic) RACSignal *didReceiveReadRequestsSignal;
@property(nonatomic) RACSignal *didReceiveWriteRequests;

@end

@implementation RBTMutableCharacteristic

#pragma mark - init

- (instancetype)initWithUUID:(CBUUID *)UUID properties:(CBCharacteristicProperties)properties value:(NSData *)value permissions:(CBAttributePermissions)permissions {
    self = [super init];
    if (self) {
        _cbCharacteristic = [[CBMutableCharacteristic alloc] initWithType:UUID properties:properties value:value permissions:permissions];
        _descriptors = [NSMutableArray array];
    }

    return self;
}

#pragma mark - Property getter/setter

- (CBUUID *)UUID {
    return self.cbCharacteristic.UUID;
}

- (void)setUUID:(CBUUID *)UUID {
    self.cbCharacteristic.UUID = UUID;
}

- (CBCharacteristicProperties)properties {
    return self.cbCharacteristic.properties;
}

- (void)setProperties:(CBCharacteristicProperties)properties {
    self.cbCharacteristic.properties = properties;
}


- (CBAttributePermissions)permissions {
    return self.cbCharacteristic.permissions;
}

- (void)setPermissions:(CBAttributePermissions)permissions {
    self.cbCharacteristic.permissions = permissions;
}

- (void)setValue:(NSData *)value {
    self.cbCharacteristic.value = value;
}

- (NSData *)value {
    return self.cbCharacteristic.value;
}


- (BOOL)isPublished {
    return !(!self.service || !self.service.peripheralModule) && self.service.isPublished;
}

- (void)setDescriptors:(NSArray *)descriptors {
    NSMutableArray *newDescriptors = [NSMutableArray array];
    for (RBTMutableDescriptor *descriptor in descriptors) {
        [newDescriptors addObject:descriptor.cbDescriptor];
    }
    self.cbCharacteristic.descriptors = newDescriptors;
}

- (NSArray *)descriptors {
    return [NSArray arrayWithArray:_descriptors];
}

#pragma mark - Public methods

- (void)addDescriptor:(RBTMutableDescriptor *)descriptor {
    [_descriptors addObject:descriptor];
    [self setDescriptors:_descriptors];
    descriptor.characteristic = self;
}

- (void)removeDescriptor:(RBTMutableDescriptor *)descriptor {
    [_descriptors removeObject:descriptor];
    [self setDescriptors:_descriptors];
}

- (BOOL)notifySubscribedCentrals {
    return [self.service.peripheralModule.cbPeripheralManager updateValue:self.value
                                                        forCharacteristic:self.cbCharacteristic
                                                     onSubscribedCentrals:nil];
}

#pragma mark - Debugging

- (NSString *)description {
    return [NSString stringWithFormat:@"<%@: %p, UUID: %@ -  Descriptors: %@, >",
                                      [self class], &self, self.UUID, self.descriptors];
}


@end