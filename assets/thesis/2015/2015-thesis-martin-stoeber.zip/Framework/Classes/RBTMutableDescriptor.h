//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@class RBTMutableCharacteristic;


@interface RBTMutableDescriptor : NSObject

/// Parrent characteristic, will be available after the characteristic is added to a service
@property(weak, nonatomic) RBTMutableCharacteristic *characteristic;

/// CoreBluetooth descriptor
@property(nonatomic, readonly) CBMutableDescriptor *cbDescriptor;

/// Unique identifier of this descriptor
@property(nonatomic, readonly) CBUUID *UUID;

/// Value of this descriptor
@property(nonatomic, readonly) id value;

/// Flag whether the descriptor was added to a characteristic an published to a peripheral module
@property(nonatomic, readonly, getter=isPublished) BOOL published;


/**
* Create a new descriptor.
* Only the <code>Characteristic User Description</code> and
* <code>Characteristic Presentation Format</code> descriptors are currently supported
* due CoreBluetooth restrictions.
*/
- (instancetype)initWithUUID:(CBUUID *)UUID value:(id)value;

@end