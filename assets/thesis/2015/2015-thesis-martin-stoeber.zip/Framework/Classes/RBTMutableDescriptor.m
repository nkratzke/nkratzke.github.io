//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <CoreBluetooth/CoreBluetooth.h>
#import "RBTMutableDescriptor.h"
#import "RBTMutableCharacteristic.h"
#import "RBTMutableService.h"


@implementation RBTMutableDescriptor {

}

- (instancetype)initWithUUID:(CBUUID *)UUID value:(id)value {
    self = [super init];
    if (self) {
        _cbDescriptor = [[CBMutableDescriptor alloc] initWithType:UUID value:value];
    }

    return self;
}


#pragma mark - Property getter/setter

- (id)value {
    return self.cbDescriptor.value;
}

- (CBUUID *)UUID {
    return self.cbDescriptor.UUID;
}

- (BOOL)isPublished {
    return self.characteristic.service.isPublished;
}


#pragma mark - Debugging

- (NSString *)description {
    return [NSString stringWithFormat:@"<%@: %p, UUID: %@ - Value: %@ >", [self class], &self, self.UUID, self.value];
}


@end
