//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@class RBTPeripheralModule, RBTMutableCharacteristic;


@interface RBTMutableService : NSObject

/// Parrent perpheral, will be available after the service was added
@property(weak, nonatomic) RBTPeripheralModule *peripheralModule;

/// CoreBluetooth service
@property(nonatomic, readonly) CBMutableService *cbService;

/// Unique identifier
@property(nonatomic) CBUUID *UUID;

/// Related included services, witch were added to this service
@property NSArray *includedServices;

/// Related characteristics, witch were added to this service
@property NSArray *characteristics;

/// Flag whether the service is primary or secondary (related to another service)
@property(nonatomic, getter=isPrimary) BOOL primaryService;

/// Flag whether the services was added and published to a peripheral module
@property(nonatomic, readonly, getter=isPublished) BOOL published;


/// Create a new primary service with the given UUID
- (instancetype)initPrimaryServiceWithUUID:(CBUUID *)UUID;

/// Create a new primary or a secondary service with the given UUID.
- (instancetype)initWithUUID:(CBUUID *)UUID primary:(BOOL)primary;


/// Add a characteristic to this service.
- (void)addCharacteristic:(RBTMutableCharacteristic *)characteristic;

/// Add characteristics to this service.
- (void)addCharacteristics:(NSArray *)characteristics;

/// Remove a characteristic from this service.
- (void)removeCharacteristic:(RBTMutableCharacteristic *)characteristic;

/// Remove characteristics from this service.
- (void)removeCharacteristics:(NSArray *)characteristics;

/// Add a included service to this service.
- (void)addIncludedService:(RBTMutableService *)service;

/// Add included services to this service.
- (void)addIncludedServices:(NSArray *)includedServices;

/// Remove a included service from this service.
- (void)removeIncludedService:(RBTMutableService *)service;

/// Remove included services from this service.
- (void)removeIncludedServices:(NSArray *)includedServices;

@end