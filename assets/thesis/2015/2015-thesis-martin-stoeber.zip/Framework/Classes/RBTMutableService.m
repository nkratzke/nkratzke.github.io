//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTMutableService.h"
#import "RBTPeripheralModule.h"
#import "RBTMutableCharacteristic.h"

@interface RBTMutableService () {
@private
    NSMutableArray *_characteristics;
    NSMutableArray *_includedServices;
}

@end


@implementation RBTMutableService

#pragma mark - init

- (instancetype)initPrimaryServiceWithUUID:(CBUUID *)UUID {
    return [self initWithUUID:UUID primary:YES];
}

- (instancetype)initWithUUID:(CBUUID *)UUID primary:(BOOL)primary {
    self = [super init];
    if (self) {
        _cbService = [[CBMutableService alloc] initWithType:UUID primary:primary];
        _characteristics = [NSMutableArray array];
        _includedServices = [NSMutableArray array];
    }
    return self;
}


#pragma mark - Property getter/setter

- (NSArray *)characteristics {
    return [NSArray arrayWithArray:_characteristics];
}

- (void)setCharacteristics:(NSArray *)characteristics {
    _characteristics = [NSMutableArray arrayWithArray:characteristics];

    NSMutableArray *newCBCharacteristics = [NSMutableArray array];
    for (RBTMutableCharacteristic *characteristic in characteristics) {
        [newCBCharacteristics addObject:characteristic.cbCharacteristic];
    }
    self.cbService.characteristics = newCBCharacteristics;
}

- (NSArray *)includedServices {
    return [NSArray arrayWithArray:_includedServices];
}

- (void)setIncludedServices:(NSArray *)includedServices {
    NSMutableArray *newCBIncludedServices = [NSMutableArray array];
    for (RBTMutableService *includedService in includedServices) {
        [newCBIncludedServices addObject:includedService.cbService];
    }
    self.cbService.includedServices = newCBIncludedServices;
}

- (BOOL)isPrimaryService {
    return self.cbService.isPrimary;
}

- (void)setPrimaryService:(BOOL)primaryService {
    self.cbService.isPrimary = primaryService;
}

- (CBUUID *)UUID {
    return self.cbService.UUID;
}

- (void)setUUID:(CBUUID *)UUID {
    self.cbService.UUID = UUID;
}

- (BOOL)isPublished {
    return [self.peripheralModule.services containsObject:self];
}

#pragma mark - Public methods

- (void)addCharacteristic:(RBTMutableCharacteristic *)characteristic {
    [self addCharacteristics:@[characteristic]];
}

- (void)addCharacteristics:(NSArray *)characteristics {
    [_characteristics addObjectsFromArray:characteristics];
    self.characteristics = _characteristics;
    for (RBTMutableCharacteristic *characteristic in self.characteristics) {
        characteristic.service = self;
    }
}

- (void)removeCharacteristic:(RBTMutableCharacteristic *)characteristic {
    [self removeCharacteristics:@[characteristic]];
}

- (void)removeCharacteristics:(NSArray *)characteristics {
    [_characteristics removeObjectsInArray:characteristics];
    self.characteristics = _characteristics;
}

- (void)addIncludedService:(RBTMutableService *)service {
    [self addIncludedServices:@[service]];
}

- (void)addIncludedServices:(NSArray *)includedServices {
    [_includedServices addObjectsFromArray:includedServices];
    [self setIncludedServices:_includedServices];
}

- (void)removeIncludedService:(RBTMutableService *)service {
    [self removeIncludedServices:@[service]];
}

- (void)removeIncludedServices:(NSArray *)includedServices {
    [_includedServices removeObjectsInArray:includedServices];
    [self setIncludedServices:_includedServices];
}

#pragma mark - Debugging

- (NSString *)description {
    return [NSString stringWithFormat:@"<%@: %p, UUID: %@ - Peripheral: %@, Primary: %@, Characteristics: %@, IncludedServices: %@ >",
                                      [self class], &self, self.UUID, self.peripheralModule,
                                      self.isPrimaryService ? @"YES" : @"NO", self.characteristics, self.includedServices];
}

@end
