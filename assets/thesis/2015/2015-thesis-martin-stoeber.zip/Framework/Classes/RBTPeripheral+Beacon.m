//
// Created by Martin Stöber on 25.01.15.
// Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTPeripheral+Beacon.h"
#import "RBTPeripheral+Protected.h"


@implementation RBTPeripheral (Beacon)

- (NSNumber *)calculateDistance {
    // source: http://stackoverflow.com/a/20434019

    [self updateRSSI];

    if (self.RSSI.integerValue == 0) {
        return nil;
    }

    double ratio = self.RSSI.integerValue * 1. / -54;
    if (ratio < 1.0) {
        return @(pow(ratio, 10));
    }
    else {
        return @((0.89976) * pow(ratio, 7.7095) + 0.111);
    }
}

@end