//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTPeripheral.h"
#import <ReactiveCocoa/ReactiveCocoa.h>


/// Protected extension to interact with corresponding RBTServices, etc.
@interface RBTPeripheral (Protected)

@property(nonatomic) NSNumber *RSSI;

@property(nonatomic) NSDictionary *advertismentData;

@property(nonatomic, readonly) RACSignal *didDiscoverCharacteristicsSignal;
@property(nonatomic, readonly) RACSignal *didDiscoverIncludedServicesSignal;
@property(nonatomic, readonly) RACSignal *didUpdateValueForCharacteristicSignal;
@property(nonatomic, readonly) RACSignal *didWriteValueForCharacteristicSignal;
@property(nonatomic, readonly) RACSignal *didUpdateValueForDescriptorSignal;
@property(nonatomic, readonly) RACSignal *didUpdateNotificationState;
@property(nonatomic, readonly) RACSignal *didDiscoverDescriptorsForCharacteristic;
@property(nonatomic, readonly) RACSignal *didWriteValueForDescriptor;


@end
