//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <CoreBluetooth/CoreBluetooth.h>
#import <ReactiveCocoa/ReactiveCocoa.h>
#import <ReactiveCocoa/RACEXTScope.h>

@class RBTCentralModule, RBTService;


@interface RBTPeripheral : NSObject <CBPeripheralDelegate>

/// Parrent central
@property(weak, nonatomic) RBTCentralModule *centralModule;

/// CoreBluetooth periperhal
@property(nonatomic, readonly) CBPeripheral *cbPeripheral;

/// Unique identifier of this peripheral
@property(nonatomic, readonly) NSUUID *identifier;

/// Name of this peripheral
@property(nonatomic, readonly) NSString *name;

//// Current connection state as Signal, last connection state will just send after subscription
@property(nonatomic, readonly) RACSignal *connectionState;

/// Current signal strength (RSSI)
@property(nonatomic, readonly) NSNumber *RSSI;

/// Advertisement data witch the peripheral send
@property(nonatomic, readonly) NSDictionary *advertismentData;

/// Already discovered services of this peripheral
@property(nonatomic, readonly) RACSequence *services;

/// Signal witch will be triggered when the peripheral will change its services
@property(nonatomic, readonly) RACSignal *didModifyServices;


/**
*  Designated initializer
*
*  RBTPeripheral should not be created manually.
*  It will be created by discovering a peripheral.
*/
- (instancetype)initWithPeripheral:(CBPeripheral *)peripheral fromCentralModule:(RBTCentralModule *)centralModule;


/// Update the RSSI, completes when successful
- (RACSignal *)updateRSSI;

/// Update the RSSI repetitive; Use -stopUpdateRSSI to cancel the update
- (RACSignal *)updateRSSIWithTimeInterval:(NSTimeInterval)interval;

/// Stop Update the RSSI
- (void)stopUpdateRSSI;


/// Will discover all services, completes when successful
- (RACSignal *)discoverServices;

/// Will discover services with the given UUIDs, completes when successful
- (RACSignal *)discoverServicesWithUUIDs:(NSArray *)serviceUUIDs;

/// Retrieves a service with the given UUID. It must be discovered first.
- (RBTService *)serviceWithUUUID:(CBUUID *)uuid;


/// Connect to a Peripheral, completes when successful
- (RACSignal *)connect;

/// Trigger a disconnect from a peripheral, completes when successful. (Due iOS restrictions this can take up tp 60sec.)
- (RACSignal *)disconnect;

@end
