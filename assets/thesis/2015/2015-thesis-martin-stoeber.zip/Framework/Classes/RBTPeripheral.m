
//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTPeripheral.h"
#import "RBTCentralModule+Protected.h"
#import "RBTService.h"


@interface RBTPeripheral ()

@property(nonatomic, readwrite) NSNumber *RSSI;
@property(nonatomic) RACSignal *RSSISignal;

@property(nonatomic) NSDictionary *advertismentData;


@property NSMutableDictionary *serviceDictionary;

@property(nonatomic) RACSignal *didDiscoverServices;
@property(nonatomic) RACSignal *didDiscoverCharacteristicsSignal;
@property(nonatomic) RACSignal *didDiscoverIncludedServicesSignal;
@property(nonatomic) RACSignal *didUpdateValueForCharacteristicSignal;
@property(nonatomic) RACSignal *didWriteValueForCharacteristicSignal;
@property(nonatomic) RACSignal *didUpdateValueForDescriptorSignal;

@property(nonatomic) RACSignal *didUpdateNotificationState;

@property(nonatomic) RACSignal *didDiscoverDescriptorsForCharacteristic;
@property(nonatomic) RACSignal *didWriteValueForDescriptor;

@property NSTimer *RSSIUpdateTimer;
@property NSTimer *scanTimer;

@end


@implementation RBTPeripheral


- (instancetype)initWithPeripheral:(CBPeripheral *)peripheral fromCentralModule:(RBTCentralModule *)centralModule {
    self = [super init];
    if (self) {
        _cbPeripheral = peripheral;
        _centralModule = centralModule;

        if (_cbPeripheral) {
            [self initPeripheral];
        }
    }
    return self;
}

- (void)initPeripheral {
    [self.cbPeripheral setDelegate:self];

    _connectionState = [RACObserve(self.cbPeripheral, state) replayLast];

    _serviceDictionary = [NSMutableDictionary dictionary];

    _RSSISignal = [[self rac_signalForSelector:@selector(peripheral:didReadRSSI:error:)
                                  fromProtocol:@protocol(CBPeripheralDelegate)] replayLast];

    _didDiscoverServices = [self rac_signalForSelector:@selector(peripheral:didDiscoverServices:)
                                          fromProtocol:@protocol(CBPeripheralDelegate)];
    _didDiscoverIncludedServicesSignal = [self rac_signalForSelector:@selector(peripheral:didDiscoverIncludedServicesForService:error:)
                                                        fromProtocol:@protocol(CBPeripheralDelegate)];
    _didDiscoverCharacteristicsSignal = [self rac_signalForSelector:@selector(peripheral:didDiscoverCharacteristicsForService:error:)
                                                       fromProtocol:@protocol(CBPeripheralDelegate)];

    _didUpdateValueForCharacteristicSignal = [self rac_signalForSelector:@selector(peripheral:didUpdateValueForCharacteristic:error:)
                                                            fromProtocol:@protocol(CBPeripheralDelegate)];
    _didWriteValueForCharacteristicSignal = [self rac_signalForSelector:@selector(peripheral:didWriteValueForCharacteristic:error:)
                                                           fromProtocol:@protocol(CBPeripheralDelegate)];
    _didUpdateValueForDescriptorSignal = [self rac_signalForSelector:@selector(peripheral:didUpdateValueForDescriptor:error:)
                                                        fromProtocol:@protocol(CBPeripheralDelegate)];

    _didUpdateNotificationState = [self rac_signalForSelector:@selector(peripheral:didUpdateNotificationStateForCharacteristic:error:)
                                                 fromProtocol:@protocol(CBPeripheralDelegate)];
    _didDiscoverDescriptorsForCharacteristic = [self rac_signalForSelector:@selector(peripheral:didDiscoverDescriptorsForCharacteristic:error:)
                                                              fromProtocol:@protocol(CBPeripheralDelegate)];
    _didWriteValueForDescriptor = [self rac_signalForSelector:@selector(peripheral:didWriteValueForDescriptor:error:)
                                                 fromProtocol:@protocol(CBPeripheralDelegate)];

    _didModifyServices = [self rac_signalForSelector:@selector(peripheral:didModifyServices:)
                                        fromProtocol:@protocol(CBPeripheralDelegate)];
}


#pragma mark - Property getter/setter

- (NSString *)name {
    return self.cbPeripheral.name;
}

- (RACSequence *)services {
    return [self.serviceDictionary rac_valueSequence];
}

- (NSUUID *)identifier {
    return self.cbPeripheral.identifier;
}


#pragma mark - Public Methods

- (RACSignal *)updateRSSI {
    [self.cbPeripheral readRSSI];
    return self.RSSISignal;
}

- (RACSignal *)updateRSSIWithTimeInterval:(NSTimeInterval)interval {
    self.RSSIUpdateTimer = [NSTimer scheduledTimerWithTimeInterval:interval
                                                            target:self
                                                          selector:@selector(handleRSSIUpdate:)
                                                          userInfo:nil
                                                           repeats:YES];
    [self.RSSIUpdateTimer fire];
    return self.RSSISignal;
}

- (void)stopUpdateRSSI {
    [self.RSSIUpdateTimer invalidate];
    self.RSSIUpdateTimer = nil;
}


- (RACSignal *)discoverServices {
    return [self discoverServicesWithUUIDs:nil];
}

- (RACSignal *)discoverServicesWithUUIDs:(NSArray *)serviceUUIDs {
    @weakify(self)
    RACSignal *discoverSignal = [RACSignal createSignal:^RACDisposable *(id <RACSubscriber> subscriber) {
        @strongify(self)
        [self.cbPeripheral discoverServices:serviceUUIDs];
        [[[self.didDiscoverServices filter:^BOOL(RACTuple *discoveredServicesTuple) {
            RACTupleUnpack(CBPeripheral *peripheral) = discoveredServicesTuple;
            return (peripheral == self.cbPeripheral);
        }] take:1] subscribeNext:^(RACTuple *discoveredServicesTuple) {
            @strongify(self)

            NSError *error = [discoveredServicesTuple second];
            if (!error) {
                for (CBService *cbService in self.cbPeripheral.services) {
                    if (!self.serviceDictionary[cbService.UUID]) {
                        self.serviceDictionary[cbService.UUID] = [[RBTService alloc] initWithCBService:cbService ofPeripheral:self];
                    }
                }

                // return all services, if searched with 'nil' or filter with given UUIDs
                RACSequence *discoveredServices = [self.services filter:^BOOL(RBTService *service) {
                    return (serviceUUIDs ? [serviceUUIDs containsObject:service.UUID] : YES);
                }];

                [subscriber sendNext:discoveredServices];
                [subscriber sendCompleted];
            } else {
                [subscriber sendError:error];
            }

        }];
        return nil;
    }];
    return discoverSignal;
}

- (RBTService *)serviceWithUUUID:(CBUUID *)uuid {
    for (RBTService *service in self.services) {
        if ([service.UUID isEqual:uuid]) {
            return service;
        }
    }
    return nil;
}


- (RACSignal *)connect {
    [self.centralModule.cbCentralManager connectPeripheral:self.cbPeripheral options:nil];

    @weakify(self)
    RACSignal *connectSignal = [RACSignal createSignal:^RACDisposable *(id <RACSubscriber> subscriber) {
        @strongify(self)

        // Check for error
        RACDisposable *failDisposable =
                [[[self.centralModule.peripheralConnectionFailedSignal filter:^BOOL(RACTuple *failedTuple) {
                    @strongify(self)
                    RACTupleUnpack(CBCentralManager *manager, CBPeripheral *failedPeripheral) = failedTuple;
                    return (manager == self.centralModule.cbCentralManager && failedPeripheral == self.cbPeripheral);
                }] take:1] subscribeNext:^(RACTuple *failedTuple) {
                    NSError *error = [failedTuple third];
                    [subscriber sendError:error];
                }];

        // Check for success
        RACDisposable *successDisposable =
                [[[self.centralModule.peripheralConnectedSignal filter:^BOOL(RACTuple *connectedTuple) {
                    @strongify(self)
                    RACTupleUnpack(CBCentralManager *manager, CBPeripheral *connectedPeripheral) = connectedTuple;
                    return (manager == self.centralModule.cbCentralManager && connectedPeripheral == self.cbPeripheral);
                }] take:1] subscribeNext:^(RACTuple *connectedTuple) {
                    [subscriber sendCompleted];
                }];

        return [RACDisposable disposableWithBlock:^{
            // cleanup signals
            [failDisposable dispose];
            [successDisposable dispose];
        }];
    }];

    return connectSignal;
}

- (RACSignal *)disconnect {
    [self.centralModule.cbCentralManager cancelPeripheralConnection:self.cbPeripheral];

    @weakify(self)
    RACSignal *disconnectSignal = [RACSignal createSignal:^RACDisposable *(id <RACSubscriber> subscriber) {
        @strongify(self)
        [[[self.centralModule.peripheralDisconnectedSignal filter:^BOOL(RACTuple *disconnectedTuple) {
            @strongify(self)
            RACTupleUnpack(CBCentralManager *manager, CBPeripheral *disconnectedPeripheral) = disconnectedTuple;
            return (manager == self.centralModule.cbCentralManager && disconnectedPeripheral == self.cbPeripheral);
        }] take:1] subscribeNext:^(RACTuple *disconnectedTuple) {
            NSError *error = [disconnectedTuple third];
            if (!error) {
                [subscriber sendCompleted];
            }
            else {
                [subscriber sendError:error];
            }
        }];
        return nil;
    }];

    return disconnectSignal;
}


#pragma mark - Private helper methods

- (void)handleRSSIUpdate:(NSTimer *)timer {
    [self.cbPeripheral readRSSI];
}


#pragma mark - CBPeripheralDelegate methods

- (void)peripheral:(CBPeripheral *)peripheral didModifyServices:(NSArray *)invalidatedServices {
    for (CBService *cbService in invalidatedServices) {
        [self.serviceDictionary removeObjectForKey:cbService.UUID];
    }
}


#pragma mark - CBPeripheralDelegate stub methods

- (void)peripheral:(CBPeripheral *)peripheral didReadRSSI:(NSNumber *)RSSI error:(NSError *)error {
    self.RSSI = RSSI;
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error {
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverIncludedServicesForService:(CBService *)service error:(NSError *)error {
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error {
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverDescriptorsForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
}

- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForDescriptor:(CBDescriptor *)descriptor error:(NSError *)error {
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForDescriptor:(CBDescriptor *)descriptor error:(NSError *)error {
}

- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
}

#pragma mark - debugging

- (NSString *)description {
    return [NSString stringWithFormat:@"<%@: %p - UUID: %@, Name: %@, State: %ld, RSSI: %@>",
                                      [self class], &self, [self.identifier UUIDString], self.cbPeripheral.name, (long) self.cbPeripheral.state, self.RSSI];
}


@end


