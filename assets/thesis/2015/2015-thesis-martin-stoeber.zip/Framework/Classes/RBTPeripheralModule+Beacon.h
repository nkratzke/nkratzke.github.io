//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import "RBTPeripheralModule.h"

@class RBTMutableService;


@interface RBTPeripheralModule (Beacon)

/// Create a iBeacon with the specific UUID, minor an major Value and advertise it.
- (void)createIBeaconWithUUID:(CBUUID *)UUID major:(CLBeaconMajorValue)major minor:(CLBeaconMinorValue)minor;

/// Create a beacon service, witch contain one characteristic with the given RSSI.
/// This value should be the measured RSSI of the device from one meter distance.
- (RBTMutableService *)createBeaconServiceWithRSSI:(signed char)rssi;

@end
