//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <CoreLocation/CoreLocation.h>
#import "RBTPeripheralModule+Beacon.h"
#import "RBTMutableService.h"
#import "RBTMutableCharacteristic.h"


@implementation RBTPeripheralModule (Beacon)

- (void)createIBeaconWithUUID:(CBUUID *)UUID major:(CLBeaconMajorValue)major minor:(CLBeaconMinorValue)minor {
    CLBeaconRegion *beacon = [[CLBeaconRegion alloc] initWithProximityUUID:[[NSUUID alloc] initWithUUIDString:[UUID UUIDString]] major:major minor:minor identifier:@"test"];
    NSDictionary *beaconData = [beacon peripheralDataWithMeasuredPower:@(-54)];

    [self.cbPeripheralManager startAdvertising:beaconData];
}

- (RBTMutableService *)createBeaconServiceWithRSSI:(signed char)rssi {
    RBTMutableService *beaconService = [[RBTMutableService alloc] initPrimaryServiceWithUUID:[CBUUID UUIDWithString:@"938EC33A-C42E-4860-819C-08053A970C2A"]];
    RBTMutableCharacteristic *rssiCharacteristic =
            [[RBTMutableCharacteristic alloc] initWithUUID:[CBUUID UUIDWithString:@"938EC33A-C42E-4860-819C-08053A970C2B"]
                                                properties:CBCharacteristicPropertyRead
                                                     value:[NSData dataWithBytes:&rssi length:sizeof(rssi)]
                                               permissions:CBAttributePermissionsReadable];
    [beaconService addCharacteristic:rssiCharacteristic];
    return beaconService;
}

@end
