//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RBTPeripheralModule.h"


/// Private extension to interact with RBTMutableService, etc.
@interface RBTPeripheralModule (Protected)

@property(nonatomic, readonly) RACSignal *readyToUpdateSubscribersSignal;
@property(nonatomic, readonly) RACSignal *didSubscribeToCharacteristicSignal;
@property(nonatomic, readonly) RACSignal *didUnsubscribeFromCharacteristicSignal;

@end
