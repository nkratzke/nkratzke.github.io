//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <ReactiveCocoa/ReactiveCocoa.h>

@class RBTMutableService;


@interface RBTPeripheralModule : NSObject <CBPeripheralManagerDelegate>

/// CoreBluetooth manager
@property(nonatomic, readonly) CBPeripheralManager *cbPeripheralManager;

/// Current bluetooth state as Signal, last connection state will just send after subscription
@property(nonatomic, readonly) RACSignal *peripheralState;

/// Signal which is send when the peripheral is going to advertise or stopped advertising
@property(nonatomic, readonly) RACSignal *advertisingState;

/// Signal which is send when a the peripheral is ready to send values to the subscribed centrals
@property(nonatomic, readonly) RACSignal *readyToUpdateSubscribersSignal;

/// Signal which is send when a central subscribe to a characteristic of this peripheral
@property(nonatomic, readonly) RACSignal *didSubscribeToCharacteristicSignal;

/// Signal which is send when a central unsubscribe to a characteristic of this peripheral
@property(nonatomic, readonly) RACSignal *didUnsubscribeFromCharacteristicSignal;

// This name is used when in advertising state.
@property(nonatomic) NSString *name;

/// Array of all added Services.
@property(readonly) NSArray *services;


/// Start advertising with all added services, completes when successful
- (RACSignal *)startAdvertising;

/// Start advertising with the given services, completes when successful
- (RACSignal *)startAdvertisingWithServices:(NSArray *)services;

/// Stop the advertising
- (void)stopAdvertising;


/// Add a service an publish it, completes when successful
- (RACSignal *)addService:(RBTMutableService *)service;

/// Remove a service
- (void)removeService:(RBTMutableService *)service;

/// Remove the given services
- (void)removeServices:(NSArray *)services;

/// Remove all services
- (void)removeAllServices;


/// Respond to a read/write request with a result. Used this method when you handle the requests by yourself with RBTCharacteristicRequestDelegate.
- (void)respondToRequest:(CBATTRequest *)request withResult:(CBATTError)result;


@end
