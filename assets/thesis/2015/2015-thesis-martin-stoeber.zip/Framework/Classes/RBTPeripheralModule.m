//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <ReactiveCocoa/ReactiveCocoa.h>
#import "RBTPeripheralModule.h"
#import "RBTCharacteristicRequestDelegate.h"
#import "RBTMutableService.h"
#import "RBTMutableCharacteristic.h"

@interface RBTPeripheralModule ()

@property NSMutableArray *servicesArray;

@property(nonatomic) RACSignal *didAddServiceSignal;
@property(nonatomic) RACSignal *didStartAdvertisingSignal;

@property(nonatomic) RACSignal *readyToUpdateSubscribersSignal;
@property(nonatomic) RACSignal *didSubscribeToCharacteristicSignal;
@property(nonatomic) RACSignal *didUnsubscribeFromCharacteristicSignal;

@end


@implementation RBTPeripheralModule

#pragma mark - Initialization

- (instancetype)init {
    self = [super init];
    if (self) {
        [self setupPeripheralModule];
    }
    return self;
}

- (void)setupPeripheralModule {
    _cbPeripheralManager = [[CBPeripheralManager alloc] initWithDelegate:self queue:nil];
    _servicesArray = [NSMutableArray array];

    _peripheralState = [[[self rac_signalForSelector:@selector(peripheralManagerDidUpdateState:)
                                        fromProtocol:@protocol(CBPeripheralDelegate)]
            map:^id(RACTuple *stateTuple) {
                RACTupleUnpack(CBPeripheralManager *peripheral) = stateTuple;
                return @(peripheral.state);
            }
    ] replayLast];

    _advertisingState = RACObserve(self.cbPeripheralManager, isAdvertising);

    _readyToUpdateSubscribersSignal = [self rac_signalForSelector:@selector(peripheralManagerIsReadyToUpdateSubscribers:)
                                                     fromProtocol:@protocol(CBPeripheralManagerDelegate)];

    _didAddServiceSignal = [self rac_signalForSelector:@selector(peripheralManager:didAddService:error:)
                                          fromProtocol:@protocol(CBPeripheralManagerDelegate)];

    _didStartAdvertisingSignal = [self rac_signalForSelector:@selector(peripheralManagerDidStartAdvertising:error:)
                                                fromProtocol:@protocol(CBPeripheralManagerDelegate)];

    _didSubscribeToCharacteristicSignal = [[self rac_signalForSelector:@selector(peripheralManager:central:didSubscribeToCharacteristic:)
                                                          fromProtocol:@protocol(CBPeripheralManagerDelegate)] map:^CBUUID *(RACTuple *subscribeToCharacteristicTuple) {
        CBCharacteristic *characteristic = [subscribeToCharacteristicTuple third];
        return characteristic.UUID;
    }];
    _didUnsubscribeFromCharacteristicSignal = [[self rac_signalForSelector:@selector(peripheralManager:central:didUnsubscribeFromCharacteristic:)
                                                              fromProtocol:@protocol(CBPeripheralManagerDelegate)] map:^CBUUID *(RACTuple *subscribeToCharacteristicTuple) {
        CBCharacteristic *characteristic = [subscribeToCharacteristicTuple third];
        return characteristic.UUID;
    }];

}


#pragma mark - Property getter/setter

- (NSArray *)services {
    return [NSArray arrayWithArray:self.servicesArray];
}


#pragma mark - Public methods

- (RACSignal *)startAdvertising {
    return [self startAdvertisingWithServices:self.services];
}

- (RACSignal *)startAdvertisingWithServices:(NSArray *)services {
    // send all service UUIDs
    NSMutableArray *uuids = [NSMutableArray array];
    for (RBTMutableService *service in services) {
        [uuids addObject:service.UUID];
    }
    [self.cbPeripheralManager startAdvertising:
            @{CBAdvertisementDataLocalNameKey : self.name ?: @"<UNKNOWN>", CBAdvertisementDataServiceUUIDsKey : uuids}];

    @weakify(self)
    RACSignal *advertisingStartSignal = [RACSignal createSignal:^RACDisposable *(id <RACSubscriber> subscriber) {
        @strongify(self)
        // check for success
        [[[self.didStartAdvertisingSignal filter:^BOOL(RACTuple *didStartAdvertisingTuple) {
            @strongify(self)
            CBPeripheralManager *cbPeripheralManager = [didStartAdvertisingTuple first];
            return (cbPeripheralManager == self.cbPeripheralManager);
        }] take:1] subscribeNext:^(RACTuple *didStartAdvertisingTuple) {
            NSError *error = [didStartAdvertisingTuple second];
            if (!error) {
                [subscriber sendCompleted];
            }
            else {
                [subscriber sendError:error];
            }
        }];
        return nil;
    }];

    return advertisingStartSignal;
}

- (void)stopAdvertising {
    [self.cbPeripheralManager stopAdvertising];
}

- (RACSignal *)addService:(RBTMutableService *)service {
    //add included services at first
    for (RBTMutableService *includedService in service.includedServices) {
        [self.cbPeripheralManager addService:includedService.cbService];
    }
    [self.cbPeripheralManager addService:service.cbService];

    @weakify(self)
    RACSignal *addedServiceSignal = [RACSignal createSignal:^RACDisposable *(id <RACSubscriber> subscriber) {
        @strongify(self)
        // check for success
        [[[self.didAddServiceSignal filter:^BOOL(RACTuple *addedServicesTuple) {
            @strongify(self)
            RACTupleUnpack(CBPeripheralManager *peripheralManager, CBService *addedService) = addedServicesTuple;
            return (self.cbPeripheralManager == peripheralManager && service.cbService == addedService);
        }] take:1] subscribeNext:^(RACTuple *addedServicesTuple) {
            @strongify(self)
            NSError *error = [addedServicesTuple third];
            if (error) {
                [subscriber sendError:error];
            } else {
                [self.servicesArray addObject:service];
                service.peripheralModule = self;

                [subscriber sendCompleted];
            }

        }];
        return nil;
    }];
    return addedServiceSignal;
}

- (void)removeService:(RBTMutableService *)service {
    //remove included services at first
    for (RBTMutableService *includedService in service.includedServices) {
        [self.cbPeripheralManager removeService:includedService.cbService];
    }

    [self.servicesArray removeObject:service];
    [self.cbPeripheralManager removeService:service.cbService];
}

- (void)removeServices:(NSArray *)services {
    for (RBTMutableService *service in services) {
        [self removeService:service];
    }
}

- (void)removeAllServices {
    [self.cbPeripheralManager removeAllServices];
}

- (void)respondToRequest:(CBATTRequest *)request withResult:(CBATTError)result {
    [self.cbPeripheralManager respondToRequest:request withResult:result];
}

#pragma mark - Private helper methods

- (RBTMutableCharacteristic *)getCharacteristicForRequest:(CBATTRequest *)request {
    for (RBTMutableService *service in self.services) {
        if (service.cbService == request.characteristic.service) {
            for (RBTMutableCharacteristic *characteristic in service.characteristics) {
                if (characteristic.cbCharacteristic == request.characteristic) {
                    return characteristic;
                }
            }
            break;
        }
    }
    return nil;
}

#pragma mark - CBPeripheralManagerDelegate methods

- (void)peripheralManager:(CBPeripheralManager *)peripheral didReceiveReadRequest:(CBATTRequest *)request {
    RBTMutableCharacteristic *characteristic = [self getCharacteristicForRequest:request];

    //use delegate if available
    if (characteristic && characteristic.delegate) {
        [characteristic.delegate handleReadRequest:request];
    } else {
        // standard response for request
        if (request.offset > request.characteristic.value.length) {
            [self respondToRequest:request withResult:CBATTErrorInvalidOffset];
            return;
        }

        request.value = [request.characteristic.value
                subdataWithRange:NSMakeRange(request.offset,
                        request.characteristic.value.length - request.offset)];

        [self respondToRequest:request withResult:CBATTErrorSuccess];
    }

}

- (void)peripheralManager:(CBPeripheralManager *)peripheral didReceiveWriteRequests:(NSArray *)requests {
    for (CBATTRequest *request in requests) {
        RBTMutableCharacteristic *characteristic = [self getCharacteristicForRequest:request];

        //use delegate if available
        if (characteristic && characteristic.delegate) {
            [characteristic.delegate handleWriteRequest:request];
        } else {
            characteristic.value = request.value;
            [self respondToRequest:request withResult:CBATTErrorSuccess];
        }
    }
}


#pragma mark - CBPeripheralManagerDelegate stub methods

- (void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral {
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral didAddService:(CBService *)service error:(NSError *)error {
}

- (void)peripheralManagerDidStartAdvertising:(CBPeripheralManager *)peripheral error:(NSError *)error {
}

- (void)peripheralManagerIsReadyToUpdateSubscribers:(CBPeripheralManager *)peripheral {
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didUnsubscribeFromCharacteristic:(CBCharacteristic *)characteristic {
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didSubscribeToCharacteristic:(CBCharacteristic *)characteristic {
}

#pragma mark - Debugging

- (NSString *)description {
    return [NSString stringWithFormat:@"<%@: %p - State: %ld Advertising: %@>",
                                      [self class], &self,
                                      (long) self.cbPeripheralManager.state, self.cbPeripheralManager.isAdvertising ? @"YES" : @"NO"];
}

@end
