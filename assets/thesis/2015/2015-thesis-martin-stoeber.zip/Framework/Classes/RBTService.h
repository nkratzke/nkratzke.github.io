//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <CoreBluetooth/CoreBluetooth.h>
#import <ReactiveCocoa/ReactiveCocoa.h>
#import <ReactiveCocoa/RACEXTScope.h>

@class RBTPeripheral, RBTCharacteristic;


@interface RBTService : NSObject

// Parent peripheral
@property(weak, nonatomic, readonly) RBTPeripheral *peripheral;

/// CoreBluetooth service
@property(nonatomic, readonly) CBService *cbService;

/// Unique identifier of this Service
@property(nonatomic, readonly) CBUUID *UUID;

/// Flag whether the service is primary or secondary (related to another service)
@property(nonatomic, readonly, getter=isPrimaryService) BOOL primaryService;

/// Sequence of discovered characteristics
@property(nonatomic, readonly) RACSequence *characteristics;

/// Sequence of discovered included services
@property(nonatomic, readonly) RACSequence *includedServices;


/**
*  Designated initializer
*
*  RBTService should not be created manually.
*  It will be created by discovering a peripheral.
*/
- (instancetype)initWithCBService:(CBService *)cbService ofPeripheral:(RBTPeripheral *)peripheral;

/// Discover all characteristics of this service.
/// Returns a signal which completed when successful.
- (RACSignal *)discoverAllCharacteristics;

/// Discover all characteristics with the given CBUUIDs.
/// Returns a signal which completed when successful.
- (RACSignal *)discoverCharacteristicsWithUUIDs:(NSArray *)UUIDs;

/// Discover all included services of this service.
/// Returns a signal which completed when successful.
- (RACSignal *)discoverAllIncludedServices;

/// Discover all included services with the given CBUUIDs.
/// Returns a signal which completed when successful.
- (RACSignal *)discoverIncludedServicesWithUUIDs:(NSArray *)UUIDs;

/// Retrieves a characteristic with the given UUID. It must be discovered first.
- (RBTCharacteristic *)characteristicWithUUUID:(CBUUID *)uuid;

@end
