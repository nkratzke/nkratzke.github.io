//
// Created by Martin Stöber
// Copyright (c) 2014-2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTService.h"
#import "RBTPeripheral+Protected.h"
#import "RBTCharacteristic.h"

@interface RBTService ()

@property NSMutableDictionary *characteristicsDictionary;
@property NSMutableDictionary *includedServicesDictionary;

@end


@implementation RBTService

#pragma mark - Initialization

- (instancetype)initWithCBService:(CBService *)cbService ofPeripheral:(RBTPeripheral *)peripheral {
    self = [super init];
    if (self) {
        _cbService = cbService;
        _peripheral = peripheral;
        [self setupService];
    }
    return self;
}

- (void)setupService {
    _characteristicsDictionary = [NSMutableDictionary dictionary];
    _includedServicesDictionary = [NSMutableDictionary dictionary];
}


#pragma mark - Property getter/setter

- (BOOL)isPrimaryService {
    return self.cbService.isPrimary;
}

- (CBUUID *)UUID {
    return self.cbService.UUID;
}

- (RACSequence *)characteristics {
    return [self.characteristicsDictionary rac_valueSequence];
}

- (RACSequence *)includedServices {
    return [self.includedServicesDictionary rac_valueSequence];
}


#pragma mark - Public Methods

- (RACSignal *)discoverAllCharacteristics {
    return [self discoverCharacteristicsWithUUIDs:nil];
}

- (RACSignal *)discoverCharacteristicsWithUUIDs:(NSArray *)UUIDs {
    @weakify(self);
    RACSignal *discoverCharacteristicsSignal = [RACSignal createSignal:^RACDisposable *(id <RACSubscriber> subscriber) {
        @strongify(self);
        [self.peripheral.cbPeripheral discoverCharacteristics:UUIDs forService:self.cbService];

        [[[self.peripheral.didDiscoverCharacteristicsSignal filter:^BOOL(RACTuple *discoveredCharacteristicsTuple) {
            RACTupleUnpack(CBPeripheral *peripheral, CBService *service) = discoveredCharacteristicsTuple;
            @strongify(self);
            return (peripheral == self.peripheral.cbPeripheral && service == self.cbService);
        }] take:1] subscribeNext:^(RACTuple *discoveredCharacteristicsTuple) {
            @strongify(self);
            NSError *error = [discoveredCharacteristicsTuple third];
            if (!error) {
                // add to local dictionary
                for (CBCharacteristic *characteristic in self.cbService.characteristics) {
                    if (!self.characteristicsDictionary[characteristic.UUID]) {
                        self.characteristicsDictionary[characteristic.UUID] = [[RBTCharacteristic alloc] initWithCBCharacteristic:characteristic
                                                                                                                        ofService:self];
                    }
                }

                RACSequence *searchedCharacteristics = [self.characteristics filter:^BOOL(RBTCharacteristic *characteristic) {
                    return (UUIDs ? [UUIDs containsObject:characteristic.UUID] : YES);
                }];

                [subscriber sendNext:searchedCharacteristics];
                [subscriber sendCompleted];
            } else
                [subscriber sendError:error];
        }];
        return nil;
    }];

    return discoverCharacteristicsSignal;
}

- (RACSignal *)discoverAllIncludedServices {
    return [self discoverIncludedServicesWithUUIDs:nil];
}

- (RACSignal *)discoverIncludedServicesWithUUIDs:(NSArray *)UUIDs {
    @weakify(self)
    RACSignal *discoverIncludedSignal = [RACSignal createSignal:^RACDisposable *(id <RACSubscriber> subscriber) {
        @strongify(self)
        [self.peripheral.cbPeripheral discoverIncludedServices:UUIDs forService:self.cbService];

        [[[self.peripheral.didDiscoverIncludedServicesSignal filter:^BOOL(RACTuple *discoveredIncludedServicesTuple) {
            @strongify(self)
            RACTupleUnpack(CBPeripheral *peripheral, CBService *service) = discoveredIncludedServicesTuple;
            return (peripheral == self.peripheral.cbPeripheral && service == self.cbService);
        }] take:1] subscribeNext:^(RACTuple *discoveredIncludedServicesTuple) {
            @strongify(self)
            NSError *error = [discoveredIncludedServicesTuple third];
            if (!error) {
                NSMutableArray *searchedServices = [NSMutableArray array];

                // add to local dictionary
                for (CBService *service in self.cbService.includedServices) {
                    if (!self.includedServicesDictionary[service.UUID]) {
                        self.includedServicesDictionary[service.UUID] = [[RBTService alloc] initWithCBService:service
                                                                                                 ofPeripheral:self.peripheral];
                    }
                }

                // filter searched for return signal
                for (NSString *searchUUID in UUIDs) {
                    if (self.includedServicesDictionary[searchUUID]) {
                        [searchedServices addObject:self.includedServicesDictionary[searchUUID]];
                    }
                }

                [subscriber sendNext:[searchedServices rac_sequence]];
                [subscriber sendCompleted];
            } else
                [subscriber sendError:error];
        }];
        return nil;
    }];

    return discoverIncludedSignal;
}

- (RBTCharacteristic *)characteristicWithUUUID:(CBUUID *)uuid {
    return self.characteristicsDictionary[uuid];
}


#pragma mark - Debugging

- (NSString *)description {
    return [NSString stringWithFormat:@"<%@: %p, UUID: %@ - Peripheral: %@, Primary: %@, Characteristics: %@, IncludedServices: %@ >",
                                      [self class], &self, self.UUID, self.peripheral.name,
                                      self.isPrimaryService ? @"YES" : @"NO", self.characteristicsDictionary.allValues, self.includedServicesDictionary.allValues];
}

@end
