var category_r_b_t_central_module_07_protected_08 =
[
    [ "peripheralConnectedSignal", "category_r_b_t_central_module_07_protected_08.html#a59a4533457d1c7d4364b376c600076a6", null ],
    [ "peripheralConnectionFailedSignal", "category_r_b_t_central_module_07_protected_08.html#a12b70882aaad733ec53af3d541b9f7a9", null ],
    [ "peripheralDisconnectedSignal", "category_r_b_t_central_module_07_protected_08.html#aeeda0d3b90aee5c3736163c4a341ef0e", null ]
];