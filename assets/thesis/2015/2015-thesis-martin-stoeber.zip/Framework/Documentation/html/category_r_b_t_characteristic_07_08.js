var category_r_b_t_characteristic_07_08 =
[
    [ "descriptorsDictionary", "category_r_b_t_characteristic_07_08.html#abf7d6ccfcaaa9bf3ce832bf298b20d95", null ],
    [ "value", "category_r_b_t_characteristic_07_08.html#aed7b1139d824363486681bc8b36a23e3", null ]
];