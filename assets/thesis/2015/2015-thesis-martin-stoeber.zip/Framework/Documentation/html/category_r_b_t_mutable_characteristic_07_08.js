var category_r_b_t_mutable_characteristic_07_08 =
[
    [ "didReceiveReadRequestsSignal", "category_r_b_t_mutable_characteristic_07_08.html#aacc14353158814443f2150160ebb454d", null ],
    [ "didReceiveWriteRequests", "category_r_b_t_mutable_characteristic_07_08.html#a61780f55b6d611a8bb288118743ec9bf", null ]
];