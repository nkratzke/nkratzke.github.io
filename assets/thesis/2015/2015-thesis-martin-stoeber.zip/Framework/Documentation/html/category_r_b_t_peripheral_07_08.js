var category_r_b_t_peripheral_07_08 =
[
    [ "advertismentData", "category_r_b_t_peripheral_07_08.html#a8dd4afef9418ba1213d3a127dd7c4b71", null ],
    [ "didDiscoverCharacteristicsSignal", "category_r_b_t_peripheral_07_08.html#a0a7beecd502eb30ac68dc5546b40b5a4", null ],
    [ "didDiscoverDescriptorsForCharacteristic", "category_r_b_t_peripheral_07_08.html#adc4c7c0a9ab6d91b4a2fb0475aa1a27b", null ],
    [ "didDiscoverIncludedServicesSignal", "category_r_b_t_peripheral_07_08.html#a9cf3e10e3a5180a3482a87e35baf6fd4", null ],
    [ "didDiscoverServices", "category_r_b_t_peripheral_07_08.html#ad176418620bd9c75685a4aa8e455b535", null ],
    [ "didUpdateNotificationState", "category_r_b_t_peripheral_07_08.html#a27fd2304fa981ff783c5501453d1da78", null ],
    [ "didUpdateValueForCharacteristicSignal", "category_r_b_t_peripheral_07_08.html#ac26500564a348a6fe8053176f55fb76a", null ],
    [ "didUpdateValueForDescriptorSignal", "category_r_b_t_peripheral_07_08.html#a9f766f1807459bbcf109a45102d38b01", null ],
    [ "didWriteValueForCharacteristicSignal", "category_r_b_t_peripheral_07_08.html#af38fc20b737b94191e742f31b0ebb533", null ],
    [ "didWriteValueForDescriptor", "category_r_b_t_peripheral_07_08.html#a7abcd72b7b931bc8917fffde0cc325de", null ],
    [ "RSSI", "category_r_b_t_peripheral_07_08.html#afaed20b89223f5c1a9b25b5192012830", null ],
    [ "RSSISignal", "category_r_b_t_peripheral_07_08.html#a8ff5a45df40cb0f79cdaff5b288b24b3", null ],
    [ "RSSIUpdateTimer", "category_r_b_t_peripheral_07_08.html#aabb99b13cc32e0ae6f70402362723a24", null ],
    [ "scanTimer", "category_r_b_t_peripheral_07_08.html#afa047420ac232983736a4aa401653bfe", null ],
    [ "serviceDictionary", "category_r_b_t_peripheral_07_08.html#a788e8974e229ac0d05ff0cc38238312f", null ]
];