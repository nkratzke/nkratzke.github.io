var category_r_b_t_peripheral_07_beacon_08 =
[
    [ "calculateDistance", "category_r_b_t_peripheral_07_beacon_08.html#ae7fc83d4e94fc0a7952becc35df13c4c", null ]
];