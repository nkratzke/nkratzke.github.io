var category_r_b_t_peripheral_07_protected_08 =
[
    [ "advertismentData", "category_r_b_t_peripheral_07_protected_08.html#a16cee8a9b86d7a8d92f31591dae4d23e", null ],
    [ "didDiscoverCharacteristicsSignal", "category_r_b_t_peripheral_07_protected_08.html#a674249d7db4935fd170f66121846fb40", null ],
    [ "didDiscoverDescriptorsForCharacteristic", "category_r_b_t_peripheral_07_protected_08.html#a4ec550587ab078631084dd8ffff93d13", null ],
    [ "didDiscoverIncludedServicesSignal", "category_r_b_t_peripheral_07_protected_08.html#a643f0680a63a67a6651ff64f505155e1", null ],
    [ "didUpdateNotificationState", "category_r_b_t_peripheral_07_protected_08.html#aebdbfe560bb36e3fc568b03449aa7194", null ],
    [ "didUpdateValueForCharacteristicSignal", "category_r_b_t_peripheral_07_protected_08.html#aa8d33dbacfc632334dba3b2d10f78c06", null ],
    [ "didUpdateValueForDescriptorSignal", "category_r_b_t_peripheral_07_protected_08.html#a711909a7cafc16f5c9293f61bfbaa72e", null ],
    [ "didWriteValueForCharacteristicSignal", "category_r_b_t_peripheral_07_protected_08.html#a3d5abf68483824397b07b8e5e648fd28", null ],
    [ "didWriteValueForDescriptor", "category_r_b_t_peripheral_07_protected_08.html#ae8dea0385aef8c112813506b754d3137", null ],
    [ "RSSI", "category_r_b_t_peripheral_07_protected_08.html#a3264d44aea9b8a993996b937bb86bdc0", null ]
];