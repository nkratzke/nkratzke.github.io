var category_r_b_t_peripheral_module_07_08 =
[
    [ "didAddServiceSignal", "category_r_b_t_peripheral_module_07_08.html#a0698a56dc9c240b8db9a6fd61364dd0d", null ],
    [ "didStartAdvertisingSignal", "category_r_b_t_peripheral_module_07_08.html#ab0cfb1772a28c047d093c55f7dc1727d", null ],
    [ "didSubscribeToCharacteristicSignal", "category_r_b_t_peripheral_module_07_08.html#a4680b9049dfc01f53d5380e90137cec0", null ],
    [ "didUnsubscribeFromCharacteristicSignal", "category_r_b_t_peripheral_module_07_08.html#aa36701e6ac5fb9d6a797c9ef3ab63b20", null ],
    [ "readyToUpdateSubscribersSignal", "category_r_b_t_peripheral_module_07_08.html#a8b395350767edabbd691308ec1e3a9fb", null ],
    [ "servicesArray", "category_r_b_t_peripheral_module_07_08.html#a7598307e279f87cb54f9f1ae0329bd75", null ]
];