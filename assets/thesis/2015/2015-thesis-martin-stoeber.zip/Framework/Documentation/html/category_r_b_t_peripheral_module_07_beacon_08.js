var category_r_b_t_peripheral_module_07_beacon_08 =
[
    [ "createBeaconServiceWithRSSI:", "category_r_b_t_peripheral_module_07_beacon_08.html#a36b3638a09be49ef531afb73e2e1151a", null ],
    [ "createIBeaconWithUUID:major:minor:", "category_r_b_t_peripheral_module_07_beacon_08.html#ae82a6e3c8e007c0d9bdd0dd774fcf848", null ]
];