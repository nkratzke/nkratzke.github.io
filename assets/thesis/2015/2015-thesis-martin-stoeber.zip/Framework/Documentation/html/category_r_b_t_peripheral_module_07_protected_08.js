var category_r_b_t_peripheral_module_07_protected_08 =
[
    [ "didSubscribeToCharacteristicSignal", "category_r_b_t_peripheral_module_07_protected_08.html#a89e4e627200a40f3e978c888f35ba034", null ],
    [ "didUnsubscribeFromCharacteristicSignal", "category_r_b_t_peripheral_module_07_protected_08.html#a923760545d37c29b0da537f397f32778", null ],
    [ "readyToUpdateSubscribersSignal", "category_r_b_t_peripheral_module_07_protected_08.html#a6cc6417e8de1aeb14dde3b00f9445aa3", null ]
];