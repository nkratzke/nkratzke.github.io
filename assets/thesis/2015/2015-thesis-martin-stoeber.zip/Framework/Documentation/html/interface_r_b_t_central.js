var interface_r_b_t_central =
[
    [ "initWithCentral:ofPeripheralModule:", "interface_r_b_t_central.html#ae795c110eebde1931389c553ba151a56", null ],
    [ "setDesiredConnectionLatency:", "interface_r_b_t_central.html#a51a106b04e3efa78509a8a7b7c2457aa", null ],
    [ "cbCental", "interface_r_b_t_central.html#ac04345821b0a746f7447ee479691b561", null ],
    [ "identifier", "interface_r_b_t_central.html#a973ae57739d911abe95957aafb8501e4", null ],
    [ "maximumUpdateValueLength", "interface_r_b_t_central.html#af9ed8d2a9f4a33255890fd05aa8872c1", null ],
    [ "peripheralModule", "interface_r_b_t_central.html#af9ace69e48b9eaba7d96641cfc7c2ef6", null ]
];