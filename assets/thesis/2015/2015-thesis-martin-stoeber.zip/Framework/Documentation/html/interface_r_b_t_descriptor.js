var interface_r_b_t_descriptor =
[
    [ "initWithCBDescriptor:ofCharacteristic:", "interface_r_b_t_descriptor.html#ad2c09ee6fb265476f4a5df52ab51c01a", null ],
    [ "readValue", "interface_r_b_t_descriptor.html#a9a5752938130d72a9627b43c12b4f21d", null ],
    [ "writeValue:", "interface_r_b_t_descriptor.html#a0d063d03e31a7cd15a9e72fa7894e29c", null ],
    [ "cbDescriptor", "interface_r_b_t_descriptor.html#aed0ec2959763e41c21ee8f87680567a7", null ],
    [ "characteristic", "interface_r_b_t_descriptor.html#a309b6404df434558a3f1755b9664d1f0", null ],
    [ "peripheral", "interface_r_b_t_descriptor.html#aaf3f98265734e968bceb2b10faabbbba", null ],
    [ "service", "interface_r_b_t_descriptor.html#a30ab7f779267fb89de28d22664e57cd2", null ],
    [ "UUID", "interface_r_b_t_descriptor.html#a2a692b59d1ac0944b5646da875fa27e3", null ],
    [ "value", "interface_r_b_t_descriptor.html#a8371da960ca5bb392c8f8c8f655b30ed", null ]
];