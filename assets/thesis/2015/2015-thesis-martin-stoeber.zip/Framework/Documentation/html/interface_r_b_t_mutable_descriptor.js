var interface_r_b_t_mutable_descriptor =
[
    [ "initWithUUID:value:", "interface_r_b_t_mutable_descriptor.html#aa97c2009c1ad5d2a7a1046ba4c2e80a8", null ],
    [ "cbDescriptor", "interface_r_b_t_mutable_descriptor.html#a60f5542e8c1c2ca829ad9dd45b87eb95", null ],
    [ "characteristic", "interface_r_b_t_mutable_descriptor.html#a87fed85dea269fb9049b3c2088b57a89", null ],
    [ "published", "interface_r_b_t_mutable_descriptor.html#a68482946449f192bc1ae73ee581f710a", null ],
    [ "UUID", "interface_r_b_t_mutable_descriptor.html#ac6e6c731b456547f506e03da44059ad2", null ],
    [ "value", "interface_r_b_t_mutable_descriptor.html#a86b2eed6d9c537ec904c031a612985dd", null ]
];