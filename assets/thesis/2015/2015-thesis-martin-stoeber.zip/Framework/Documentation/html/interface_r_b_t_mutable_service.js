var interface_r_b_t_mutable_service =
[
    [ "addCharacteristic:", "interface_r_b_t_mutable_service.html#a7ee61afcfba62d4c4acc735528dfa9ec", null ],
    [ "addCharacteristics:", "interface_r_b_t_mutable_service.html#ae4aeabc9e5d6add7d1c7f939e9bca344", null ],
    [ "addIncludedService:", "interface_r_b_t_mutable_service.html#a29ee827a52cd12287a26a05dcfb081d4", null ],
    [ "addIncludedServices:", "interface_r_b_t_mutable_service.html#a695b2b9c5beb95f915515ec5cb747686", null ],
    [ "initPrimaryServiceWithUUID:", "interface_r_b_t_mutable_service.html#a7a737ca29d84f47309b87d329129fa1e", null ],
    [ "initWithUUID:primary:", "interface_r_b_t_mutable_service.html#a40ffd124d45a8216d642a9d6b5285595", null ],
    [ "removeCharacteristic:", "interface_r_b_t_mutable_service.html#abf3bad2a9a04322777f729258d669451", null ],
    [ "removeCharacteristics:", "interface_r_b_t_mutable_service.html#ad27de98f3f065b3d7b5d5439c24d9a68", null ],
    [ "removeIncludedService:", "interface_r_b_t_mutable_service.html#a407774d1147564619966f359e4d3ecea", null ],
    [ "removeIncludedServices:", "interface_r_b_t_mutable_service.html#af06b49fc44a3baaf5a67c6b7d73980d8", null ],
    [ "cbService", "interface_r_b_t_mutable_service.html#ae3b73a1385338694ff2abba6ba751cca", null ],
    [ "characteristics", "interface_r_b_t_mutable_service.html#a78e3700a2113e2a3f8fce00a9fbbb321", null ],
    [ "includedServices", "interface_r_b_t_mutable_service.html#a998029b0f0391f09269f150f5ddbcf33", null ],
    [ "peripheralModule", "interface_r_b_t_mutable_service.html#a658ad439c2e1b2f28218e2a9cabd2f0a", null ],
    [ "primaryService", "interface_r_b_t_mutable_service.html#a531433aad525d18eaf4d66690958d895", null ],
    [ "published", "interface_r_b_t_mutable_service.html#ac773ae0ddaf2518fc0cc090d58274ad4", null ],
    [ "UUID", "interface_r_b_t_mutable_service.html#a6669891e8cd91d2a6b51951aed71a5ab", null ]
];