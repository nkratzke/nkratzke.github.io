var interface_r_b_t_peripheral_module =
[
    [ "addService:", "interface_r_b_t_peripheral_module.html#abf707f695b1e7c22626a5601d28452ba", null ],
    [ "createBeaconServiceWithRSSI:", "interface_r_b_t_peripheral_module.html#a36b3638a09be49ef531afb73e2e1151a", null ],
    [ "createIBeaconWithUUID:major:minor:", "interface_r_b_t_peripheral_module.html#ae82a6e3c8e007c0d9bdd0dd774fcf848", null ],
    [ "removeAllServices", "interface_r_b_t_peripheral_module.html#a0fe8a1d83f4638ff6a5068cd767a0ffa", null ],
    [ "removeService:", "interface_r_b_t_peripheral_module.html#afd0aa0c8d3ad607e13368e3c7cf40e9d", null ],
    [ "removeServices:", "interface_r_b_t_peripheral_module.html#a0ded155059d1708302d1654ff4fb6e55", null ],
    [ "respondToRequest:withResult:", "interface_r_b_t_peripheral_module.html#a11a7b4eee67fdf358aea795b99b7714d", null ],
    [ "startAdvertising", "interface_r_b_t_peripheral_module.html#a47571bb938d5be310b11510866bc17c5", null ],
    [ "startAdvertisingWithServices:", "interface_r_b_t_peripheral_module.html#a9306d91678b6f19d360b6a66b1dc7a00", null ],
    [ "stopAdvertising", "interface_r_b_t_peripheral_module.html#ac1f8aa1c11b1bc808761e88710df400e", null ],
    [ "advertisingState", "interface_r_b_t_peripheral_module.html#ad842be01ea00356ee447e4f6336b0352", null ],
    [ "cbPeripheralManager", "interface_r_b_t_peripheral_module.html#af2fb847af5e81f35c37c409ba9654c07", null ],
    [ "didSubscribeToCharacteristicSignal", "interface_r_b_t_peripheral_module.html#a9559a5767602e622e703aa8b76242e52", null ],
    [ "didUnsubscribeFromCharacteristicSignal", "interface_r_b_t_peripheral_module.html#a783db299daaba84fcef3ada0183541c8", null ],
    [ "name", "interface_r_b_t_peripheral_module.html#ad27071c8cf4ef2010652119e343b15ce", null ],
    [ "peripheralState", "interface_r_b_t_peripheral_module.html#a11f37620bf307d70b5b3ae48646f83df", null ],
    [ "readyToUpdateSubscribersSignal", "interface_r_b_t_peripheral_module.html#a9a564280a365cd788e3b7058e9be2339", null ],
    [ "services", "interface_r_b_t_peripheral_module.html#afd3f9752c4a115ece210d8569d9be47f", null ]
];