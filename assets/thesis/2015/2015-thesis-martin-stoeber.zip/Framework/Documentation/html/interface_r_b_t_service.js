var interface_r_b_t_service =
[
    [ "characteristicWithUUUID:", "interface_r_b_t_service.html#accbe0c1fae6684057f13e27f32ccbf7c", null ],
    [ "discoverAllCharacteristics", "interface_r_b_t_service.html#a503609009d48c569bacfa0f1f9a96a29", null ],
    [ "discoverAllIncludedServices", "interface_r_b_t_service.html#aa1f1137984d976978b3ebb27b150fbb7", null ],
    [ "discoverCharacteristicsWithUUIDs:", "interface_r_b_t_service.html#a8409fd7e8b62f62ccd8a5c441b3ed5fc", null ],
    [ "discoverIncludedServicesWithUUIDs:", "interface_r_b_t_service.html#ac7ea98bcd9335fbd32fdadc8de7aab6f", null ],
    [ "initWithCBService:ofPeripheral:", "interface_r_b_t_service.html#ab1937e2faeb2246dcfe19d8c2c046487", null ],
    [ "cbService", "interface_r_b_t_service.html#a7dd516d721a47e9911003bd3b2bf87ff", null ],
    [ "characteristics", "interface_r_b_t_service.html#a9afa43b58289bc2e28b3ed4a8bd03f94", null ],
    [ "includedServices", "interface_r_b_t_service.html#af910dee78fd0bc6010aa0d9b47ec8372", null ],
    [ "peripheral", "interface_r_b_t_service.html#abba58122bfa77012d36d17e8bc73309d", null ],
    [ "primaryService", "interface_r_b_t_service.html#ae5e086120b1fd68185db315afb647e3e", null ],
    [ "UUID", "interface_r_b_t_service.html#ab8163e44e49ed586bfa7b88ad27f2ef0", null ]
];