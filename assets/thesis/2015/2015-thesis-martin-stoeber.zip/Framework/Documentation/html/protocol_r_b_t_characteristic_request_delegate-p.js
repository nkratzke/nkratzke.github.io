var protocol_r_b_t_characteristic_request_delegate_p =
[
    [ "handleReadRequest:", "protocol_r_b_t_characteristic_request_delegate-p.html#ad0221d35e476ddff15a22fd1d1b736bf", null ],
    [ "handleWriteRequest:", "protocol_r_b_t_characteristic_request_delegate-p.html#a8b8d7beda24ec287a068f6a44f80988c", null ]
];