var searchData=
[
  ['_5fperipheralconnectedsubject',['_peripheralConnectedSubject',['../category_r_b_t_central_module_07_08.html#ae8377448ca85b240c6845c90a6f96a1b',1,'RBTCentralModule()']]],
  ['_5fperipheraldisconnectedsubject',['_peripheralDisconnectedSubject',['../category_r_b_t_central_module_07_08.html#aa56f4e5a98ad88e6cd8907df71beaaaf',1,'RBTCentralModule()']]]
];
