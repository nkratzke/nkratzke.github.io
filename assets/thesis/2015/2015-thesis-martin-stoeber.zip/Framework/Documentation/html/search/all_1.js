var searchData=
[
  ['addcharacteristic_3a',['addCharacteristic:',['../interface_r_b_t_mutable_service.html#a7ee61afcfba62d4c4acc735528dfa9ec',1,'RBTMutableService']]],
  ['addcharacteristics_3a',['addCharacteristics:',['../interface_r_b_t_mutable_service.html#ae4aeabc9e5d6add7d1c7f939e9bca344',1,'RBTMutableService']]],
  ['adddescriptor_3a',['addDescriptor:',['../interface_r_b_t_mutable_characteristic.html#ad19d07d4f94fa0237cb381472793583a',1,'RBTMutableCharacteristic']]],
  ['addincludedservice_3a',['addIncludedService:',['../interface_r_b_t_mutable_service.html#a29ee827a52cd12287a26a05dcfb081d4',1,'RBTMutableService']]],
  ['addincludedservices_3a',['addIncludedServices:',['../interface_r_b_t_mutable_service.html#a695b2b9c5beb95f915515ec5cb747686',1,'RBTMutableService']]],
  ['addservice_3a',['addService:',['../interface_r_b_t_peripheral_module.html#abf707f695b1e7c22626a5601d28452ba',1,'RBTPeripheralModule']]],
  ['advertisingstate',['advertisingState',['../interface_r_b_t_peripheral_module.html#ad842be01ea00356ee447e4f6336b0352',1,'RBTPeripheralModule']]],
  ['advertismentdata',['advertismentData',['../category_r_b_t_peripheral_07_protected_08.html#a16cee8a9b86d7a8d92f31591dae4d23e',1,'RBTPeripheral(Protected)::advertismentData()'],['../interface_r_b_t_peripheral.html#a2ba78ab8d7add49ee7edaef6fa1e1d5b',1,'RBTPeripheral::advertismentData()'],['../category_r_b_t_peripheral_07_08.html#a8dd4afef9418ba1213d3a127dd7c4b71',1,'RBTPeripheral()::advertismentData()']]]
];
