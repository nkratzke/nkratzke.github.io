var searchData=
[
  ['handlereadrequest_3a',['handleReadRequest:',['../protocol_r_b_t_characteristic_request_delegate-p.html#ad0221d35e476ddff15a22fd1d1b736bf',1,'RBTCharacteristicRequestDelegate-p']]],
  ['handlewriterequest_3a',['handleWriteRequest:',['../protocol_r_b_t_characteristic_request_delegate-p.html#a8b8d7beda24ec287a068f6a44f80988c',1,'RBTCharacteristicRequestDelegate-p']]]
];
