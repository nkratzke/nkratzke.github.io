var searchData=
[
  ['identifier',['identifier',['../interface_r_b_t_central.html#a973ae57739d911abe95957aafb8501e4',1,'RBTCentral::identifier()'],['../interface_r_b_t_peripheral.html#ac0cd4336f267e9b37948952e2f4f9995',1,'RBTPeripheral::identifier()']]],
  ['includedservices',['includedServices',['../interface_r_b_t_mutable_service.html#a998029b0f0391f09269f150f5ddbcf33',1,'RBTMutableService::includedServices()'],['../interface_r_b_t_service.html#af910dee78fd0bc6010aa0d9b47ec8372',1,'RBTService::includedServices()']]],
  ['includedservicesdictionary',['includedServicesDictionary',['../category_r_b_t_service_07_08.html#aa82e34d8cae5fdd37d43553cbdcbff89',1,'RBTService()']]],
  ['initprimaryservicewithuuid_3a',['initPrimaryServiceWithUUID:',['../interface_r_b_t_mutable_service.html#a7a737ca29d84f47309b87d329129fa1e',1,'RBTMutableService']]],
  ['initwithcbcharacteristic_3aofservice_3a',['initWithCBCharacteristic:ofService:',['../interface_r_b_t_characteristic.html#a02ef2f4388ad538ec9009ce2c5713f4f',1,'RBTCharacteristic']]],
  ['initwithcbdescriptor_3aofcharacteristic_3a',['initWithCBDescriptor:ofCharacteristic:',['../interface_r_b_t_descriptor.html#ad2c09ee6fb265476f4a5df52ab51c01a',1,'RBTDescriptor']]],
  ['initwithcbservice_3aofperipheral_3a',['initWithCBService:ofPeripheral:',['../interface_r_b_t_service.html#ab1937e2faeb2246dcfe19d8c2c046487',1,'RBTService']]],
  ['initwithcentral_3aofperipheralmodule_3a',['initWithCentral:ofPeripheralModule:',['../interface_r_b_t_central.html#ae795c110eebde1931389c553ba151a56',1,'RBTCentral']]],
  ['initwithperipheral_3afromcentralmodule_3a',['initWithPeripheral:fromCentralModule:',['../interface_r_b_t_peripheral.html#a5736bcec1328647321f5381ed5ff7d48',1,'RBTPeripheral']]],
  ['initwithuuid_3aprimary_3a',['initWithUUID:primary:',['../interface_r_b_t_mutable_service.html#a40ffd124d45a8216d642a9d6b5285595',1,'RBTMutableService']]],
  ['initwithuuid_3aproperties_3avalue_3apermissions_3a',['initWithUUID:properties:value:permissions:',['../interface_r_b_t_mutable_characteristic.html#ac9d18ffa4c86e18be14ee9396650498d',1,'RBTMutableCharacteristic']]],
  ['initwithuuid_3avalue_3a',['initWithUUID:value:',['../interface_r_b_t_mutable_descriptor.html#aa97c2009c1ad5d2a7a1046ba4c2e80a8',1,'RBTMutableDescriptor']]]
];
