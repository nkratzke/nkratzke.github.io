var searchData=
[
  ['name',['name',['../interface_r_b_t_peripheral.html#aba52f1896c5670691a4cf302887d088b',1,'RBTPeripheral::name()'],['../interface_r_b_t_peripheral_module.html#ad27071c8cf4ef2010652119e343b15ce',1,'RBTPeripheralModule::name()']]],
  ['notifying',['notifying',['../interface_r_b_t_characteristic.html#a1e915f2bc1e3ae6b7db4abb0bddc5b67',1,'RBTCharacteristic']]],
  ['notifysubscribedcentrals',['notifySubscribedCentrals',['../interface_r_b_t_mutable_characteristic.html#a7627a1d735162c7a1efb44034bb7dc7c',1,'RBTMutableCharacteristic']]]
];
