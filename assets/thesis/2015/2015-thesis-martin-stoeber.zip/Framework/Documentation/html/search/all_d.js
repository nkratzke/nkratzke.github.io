var searchData=
[
  ['updaterssi',['updateRSSI',['../interface_r_b_t_peripheral.html#a955281439fbe234c6c6a6169af4c4b0f',1,'RBTPeripheral']]],
  ['updaterssiwithtimeinterval_3a',['updateRSSIWithTimeInterval:',['../interface_r_b_t_peripheral.html#a09243d703bbcb320bdf03249526cbde2',1,'RBTPeripheral']]],
  ['uuid',['UUID',['../interface_r_b_t_characteristic.html#aa79a6b6251030ed3b599e577b9d8dc2a',1,'RBTCharacteristic::UUID()'],['../interface_r_b_t_descriptor.html#a2a692b59d1ac0944b5646da875fa27e3',1,'RBTDescriptor::UUID()'],['../interface_r_b_t_mutable_characteristic.html#af4c2ce5b522494a229287128d7f57eba',1,'RBTMutableCharacteristic::UUID()'],['../interface_r_b_t_mutable_descriptor.html#ac6e6c731b456547f506e03da44059ad2',1,'RBTMutableDescriptor::UUID()'],['../interface_r_b_t_mutable_service.html#a6669891e8cd91d2a6b51951aed71a5ab',1,'RBTMutableService::UUID()'],['../interface_r_b_t_service.html#ab8163e44e49ed586bfa7b88ad27f2ef0',1,'RBTService::UUID()']]]
];
