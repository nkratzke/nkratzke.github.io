var searchData=
[
  ['writevalue_3a',['writeValue:',['../interface_r_b_t_characteristic.html#a1c230d1b3d1c77bb55ded15adac014cd',1,'RBTCharacteristic::writeValue:()'],['../interface_r_b_t_descriptor.html#a0d063d03e31a7cd15a9e72fa7894e29c',1,'RBTDescriptor::writeValue:()']]],
  ['writevalue_3awithresponse_3a',['writeValue:withResponse:',['../interface_r_b_t_characteristic.html#afbbc702d04826d41b3934f41d3177ffd',1,'RBTCharacteristic']]]
];
