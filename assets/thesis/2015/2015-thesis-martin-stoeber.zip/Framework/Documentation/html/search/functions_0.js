var searchData=
[
  ['addcharacteristic_3a',['addCharacteristic:',['../interface_r_b_t_mutable_service.html#a7ee61afcfba62d4c4acc735528dfa9ec',1,'RBTMutableService']]],
  ['addcharacteristics_3a',['addCharacteristics:',['../interface_r_b_t_mutable_service.html#ae4aeabc9e5d6add7d1c7f939e9bca344',1,'RBTMutableService']]],
  ['adddescriptor_3a',['addDescriptor:',['../interface_r_b_t_mutable_characteristic.html#ad19d07d4f94fa0237cb381472793583a',1,'RBTMutableCharacteristic']]],
  ['addincludedservice_3a',['addIncludedService:',['../interface_r_b_t_mutable_service.html#a29ee827a52cd12287a26a05dcfb081d4',1,'RBTMutableService']]],
  ['addincludedservices_3a',['addIncludedServices:',['../interface_r_b_t_mutable_service.html#a695b2b9c5beb95f915515ec5cb747686',1,'RBTMutableService']]],
  ['addservice_3a',['addService:',['../interface_r_b_t_peripheral_module.html#abf707f695b1e7c22626a5601d28452ba',1,'RBTPeripheralModule']]]
];
