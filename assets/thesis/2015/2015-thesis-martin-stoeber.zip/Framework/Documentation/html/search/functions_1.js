var searchData=
[
  ['calculatedistance',['calculateDistance',['../category_r_b_t_peripheral_07_beacon_08.html#ae7fc83d4e94fc0a7952becc35df13c4c',1,'RBTPeripheral(Beacon)::calculateDistance()'],['../interface_r_b_t_peripheral.html#ae7fc83d4e94fc0a7952becc35df13c4c',1,'RBTPeripheral::calculateDistance()']]],
  ['characteristicwithuuuid_3a',['characteristicWithUUUID:',['../interface_r_b_t_service.html#accbe0c1fae6684057f13e27f32ccbf7c',1,'RBTService']]],
  ['connect',['connect',['../interface_r_b_t_peripheral.html#a80d4c8129bf17e7a5de0485fa8b8729b',1,'RBTPeripheral']]],
  ['createbeaconservicewithrssi_3a',['createBeaconServiceWithRSSI:',['../category_r_b_t_peripheral_module_07_beacon_08.html#a36b3638a09be49ef531afb73e2e1151a',1,'RBTPeripheralModule(Beacon)::createBeaconServiceWithRSSI:()'],['../interface_r_b_t_peripheral_module.html#a36b3638a09be49ef531afb73e2e1151a',1,'RBTPeripheralModule::createBeaconServiceWithRSSI:()']]],
  ['createibeaconwithuuid_3amajor_3aminor_3a',['createIBeaconWithUUID:major:minor:',['../category_r_b_t_peripheral_module_07_beacon_08.html#ae82a6e3c8e007c0d9bdd0dd774fcf848',1,'RBTPeripheralModule(Beacon)::createIBeaconWithUUID:major:minor:()'],['../interface_r_b_t_peripheral_module.html#ae82a6e3c8e007c0d9bdd0dd774fcf848',1,'RBTPeripheralModule::createIBeaconWithUUID:major:minor:()']]]
];
