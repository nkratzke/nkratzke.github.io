var searchData=
[
  ['disconnect',['disconnect',['../interface_r_b_t_peripheral.html#af1b4e93e993db016abaf157d678a212a',1,'RBTPeripheral']]],
  ['discoverallcharacteristics',['discoverAllCharacteristics',['../interface_r_b_t_service.html#a503609009d48c569bacfa0f1f9a96a29',1,'RBTService']]],
  ['discoverallincludedservices',['discoverAllIncludedServices',['../interface_r_b_t_service.html#aa1f1137984d976978b3ebb27b150fbb7',1,'RBTService']]],
  ['discovercharacteristicswithuuids_3a',['discoverCharacteristicsWithUUIDs:',['../interface_r_b_t_service.html#a8409fd7e8b62f62ccd8a5c441b3ed5fc',1,'RBTService']]],
  ['discoverdescriptors',['discoverDescriptors',['../interface_r_b_t_characteristic.html#a026372240c6decde39d72d93fcabcffa',1,'RBTCharacteristic']]],
  ['discoverincludedserviceswithuuids_3a',['discoverIncludedServicesWithUUIDs:',['../interface_r_b_t_service.html#ac7ea98bcd9335fbd32fdadc8de7aab6f',1,'RBTService']]],
  ['discoverservices',['discoverServices',['../interface_r_b_t_peripheral.html#a94d507a37210dddd041356da772d7984',1,'RBTPeripheral']]],
  ['discoverserviceswithuuids_3a',['discoverServicesWithUUIDs:',['../interface_r_b_t_peripheral.html#a8eab9f94b70a26441c5373d235336c61',1,'RBTPeripheral']]]
];
