var searchData=
[
  ['notifysubscribedcentrals',['notifySubscribedCentrals',['../interface_r_b_t_mutable_characteristic.html#a7627a1d735162c7a1efb44034bb7dc7c',1,'RBTMutableCharacteristic']]]
];
