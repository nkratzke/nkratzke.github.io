var searchData=
[
  ['readvalue',['readValue',['../interface_r_b_t_characteristic.html#a6b260f09ac8d5e02fa8e892ae274a746',1,'RBTCharacteristic::readValue()'],['../interface_r_b_t_descriptor.html#a9a5752938130d72a9627b43c12b4f21d',1,'RBTDescriptor::readValue()']]],
  ['removeallservices',['removeAllServices',['../interface_r_b_t_peripheral_module.html#a0fe8a1d83f4638ff6a5068cd767a0ffa',1,'RBTPeripheralModule']]],
  ['removecharacteristic_3a',['removeCharacteristic:',['../interface_r_b_t_mutable_service.html#abf3bad2a9a04322777f729258d669451',1,'RBTMutableService']]],
  ['removecharacteristics_3a',['removeCharacteristics:',['../interface_r_b_t_mutable_service.html#ad27de98f3f065b3d7b5d5439c24d9a68',1,'RBTMutableService']]],
  ['removedescriptor_3a',['removeDescriptor:',['../interface_r_b_t_mutable_characteristic.html#a4b3f2a93b8560dbc1bdf060e7c60b7d9',1,'RBTMutableCharacteristic']]],
  ['removeincludedservice_3a',['removeIncludedService:',['../interface_r_b_t_mutable_service.html#a407774d1147564619966f359e4d3ecea',1,'RBTMutableService']]],
  ['removeincludedservices_3a',['removeIncludedServices:',['../interface_r_b_t_mutable_service.html#af06b49fc44a3baaf5a67c6b7d73980d8',1,'RBTMutableService']]],
  ['removeservice_3a',['removeService:',['../interface_r_b_t_peripheral_module.html#afd0aa0c8d3ad607e13368e3c7cf40e9d',1,'RBTPeripheralModule']]],
  ['removeservices_3a',['removeServices:',['../interface_r_b_t_peripheral_module.html#a0ded155059d1708302d1654ff4fb6e55',1,'RBTPeripheralModule']]],
  ['respondtorequest_3awithresult_3a',['respondToRequest:withResult:',['../interface_r_b_t_peripheral_module.html#a11a7b4eee67fdf358aea795b99b7714d',1,'RBTPeripheralModule']]],
  ['retrieveconnectedperipherals',['retrieveConnectedPeripherals',['../interface_r_b_t_central_module.html#a5f102cf017edd2fb69c3214fbcc3981e',1,'RBTCentralModule']]],
  ['retrievedeviceconnectedperipheralswithservices_3a',['retrieveDeviceConnectedPeripheralsWithServices:',['../interface_r_b_t_central_module.html#a506074e3a811ab4223b55bdf0cbb9f50',1,'RBTCentralModule']]],
  ['retrieveknownperipheralswithidentifiers_3a',['retrieveKnownPeripheralsWithIdentifiers:',['../interface_r_b_t_central_module.html#ac74ebfbd0236fb4f0287a46068c89821',1,'RBTCentralModule']]]
];
