var searchData=
[
  ['scan',['scan',['../interface_r_b_t_central_module.html#a449bd6bef13ce6a99d749e22e7a57b46',1,'RBTCentralModule']]],
  ['scanforperipheralswithservices_3a',['scanForPeripheralsWithServices:',['../interface_r_b_t_central_module.html#a6c060bec85bebb74c36ed3d179dba883',1,'RBTCentralModule']]],
  ['scanforperipheralswithservices_3afortimeinterval_3awithduplicates_3amaxrssi_3a',['scanForPeripheralsWithServices:forTimeinterval:withDuplicates:maxRSSI:',['../interface_r_b_t_central_module.html#ab66bf8106831c15640c6642061eb3b00',1,'RBTCentralModule']]],
  ['scanwithduplicates_3a',['scanWithDuplicates:',['../interface_r_b_t_central_module.html#af01c9c832a7c4f1012af5ed0a20e9875',1,'RBTCentralModule']]],
  ['scanwithduplicatesandmaxrssi_3a',['scanWithDuplicatesAndMaxRSSI:',['../interface_r_b_t_central_module.html#a85d541c43ecb914da7c0162a2a230f17',1,'RBTCentralModule']]],
  ['scanwithmaxrssi_3a',['scanWithMaxRSSI:',['../interface_r_b_t_central_module.html#a1b339a27a50b30723bf6945fe1029739',1,'RBTCentralModule']]],
  ['servicewithuuuid_3a',['serviceWithUUUID:',['../interface_r_b_t_peripheral.html#a7c84e7a969d75b7fc4d2a24b919d5429',1,'RBTPeripheral']]],
  ['setdesiredconnectionlatency_3a',['setDesiredConnectionLatency:',['../interface_r_b_t_central.html#a51a106b04e3efa78509a8a7b7c2457aa',1,'RBTCentral']]],
  ['setnotifyingstatus_3a',['setNotifyingStatus:',['../interface_r_b_t_characteristic.html#abbf64e222f4ae1b3207d9c7d59b652eb',1,'RBTCharacteristic']]],
  ['startadvertising',['startAdvertising',['../interface_r_b_t_peripheral_module.html#a47571bb938d5be310b11510866bc17c5',1,'RBTPeripheralModule']]],
  ['startadvertisingwithservices_3a',['startAdvertisingWithServices:',['../interface_r_b_t_peripheral_module.html#a9306d91678b6f19d360b6a66b1dc7a00',1,'RBTPeripheralModule']]],
  ['stopadvertising',['stopAdvertising',['../interface_r_b_t_peripheral_module.html#ac1f8aa1c11b1bc808761e88710df400e',1,'RBTPeripheralModule']]],
  ['stopscan',['stopScan',['../interface_r_b_t_central_module.html#a8c3c16cc323e5f2d994846760e612bb5',1,'RBTCentralModule']]],
  ['stopupdaterssi',['stopUpdateRSSI',['../interface_r_b_t_peripheral.html#a9e9b7d1b9723dbae97784822c83541c2',1,'RBTPeripheral']]]
];
