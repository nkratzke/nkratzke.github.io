var searchData=
[
  ['updaterssi',['updateRSSI',['../interface_r_b_t_peripheral.html#a955281439fbe234c6c6a6169af4c4b0f',1,'RBTPeripheral']]],
  ['updaterssiwithtimeinterval_3a',['updateRSSIWithTimeInterval:',['../interface_r_b_t_peripheral.html#a09243d703bbcb320bdf03249526cbde2',1,'RBTPeripheral']]]
];
