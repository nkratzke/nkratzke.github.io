var searchData=
[
  ['cbcental',['cbCental',['../interface_r_b_t_central.html#ac04345821b0a746f7447ee479691b561',1,'RBTCentral']]],
  ['cbcentralmanager',['cbCentralManager',['../interface_r_b_t_central_module.html#a9948bca1458f56bf80a6ee9a222689f4',1,'RBTCentralModule']]],
  ['cbcharacteristic',['cbCharacteristic',['../interface_r_b_t_characteristic.html#a921eb407d31c1ffcdbc6591736957ae1',1,'RBTCharacteristic::cbCharacteristic()'],['../interface_r_b_t_mutable_characteristic.html#a5af2fc14fd92c13ca0c351eab3ffb791',1,'RBTMutableCharacteristic::cbCharacteristic()']]],
  ['cbdescriptor',['cbDescriptor',['../interface_r_b_t_descriptor.html#aed0ec2959763e41c21ee8f87680567a7',1,'RBTDescriptor::cbDescriptor()'],['../interface_r_b_t_mutable_descriptor.html#a60f5542e8c1c2ca829ad9dd45b87eb95',1,'RBTMutableDescriptor::cbDescriptor()']]],
  ['cbperipheral',['cbPeripheral',['../interface_r_b_t_peripheral.html#a16c069365ddeebbc6053c3377d8b5454',1,'RBTPeripheral']]],
  ['cbperipheralmanager',['cbPeripheralManager',['../interface_r_b_t_peripheral_module.html#af2fb847af5e81f35c37c409ba9654c07',1,'RBTPeripheralModule']]],
  ['cbservice',['cbService',['../interface_r_b_t_mutable_service.html#ae3b73a1385338694ff2abba6ba751cca',1,'RBTMutableService::cbService()'],['../interface_r_b_t_service.html#a7dd516d721a47e9911003bd3b2bf87ff',1,'RBTService::cbService()']]],
  ['centralmodule',['centralModule',['../interface_r_b_t_peripheral.html#ab0edda1176d55466c18cdbf2154c0149',1,'RBTPeripheral']]],
  ['characteristic',['characteristic',['../interface_r_b_t_descriptor.html#a309b6404df434558a3f1755b9664d1f0',1,'RBTDescriptor::characteristic()'],['../interface_r_b_t_mutable_descriptor.html#a87fed85dea269fb9049b3c2088b57a89',1,'RBTMutableDescriptor::characteristic()']]],
  ['characteristics',['characteristics',['../interface_r_b_t_mutable_service.html#a78e3700a2113e2a3f8fce00a9fbbb321',1,'RBTMutableService::characteristics()'],['../interface_r_b_t_service.html#a9afa43b58289bc2e28b3ed4a8bd03f94',1,'RBTService::characteristics()']]],
  ['characteristicsdictionary',['characteristicsDictionary',['../category_r_b_t_service_07_08.html#a793889dd0eb9bfb7fe7d77c8d6582c3a',1,'RBTService()']]],
  ['connectedperipherals',['connectedPeripherals',['../category_r_b_t_central_module_07_08.html#ac20a331dbcd252111f3357725640dffd',1,'RBTCentralModule()']]],
  ['connectionstate',['connectionState',['../interface_r_b_t_peripheral.html#a2b942ed2ca14c5759b9a88c3973d494b',1,'RBTPeripheral']]]
];
