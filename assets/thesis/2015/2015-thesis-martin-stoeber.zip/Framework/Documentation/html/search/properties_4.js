var searchData=
[
  ['identifier',['identifier',['../interface_r_b_t_central.html#a973ae57739d911abe95957aafb8501e4',1,'RBTCentral::identifier()'],['../interface_r_b_t_peripheral.html#ac0cd4336f267e9b37948952e2f4f9995',1,'RBTPeripheral::identifier()']]],
  ['includedservices',['includedServices',['../interface_r_b_t_mutable_service.html#a998029b0f0391f09269f150f5ddbcf33',1,'RBTMutableService::includedServices()'],['../interface_r_b_t_service.html#af910dee78fd0bc6010aa0d9b47ec8372',1,'RBTService::includedServices()']]],
  ['includedservicesdictionary',['includedServicesDictionary',['../category_r_b_t_service_07_08.html#aa82e34d8cae5fdd37d43553cbdcbff89',1,'RBTService()']]]
];
