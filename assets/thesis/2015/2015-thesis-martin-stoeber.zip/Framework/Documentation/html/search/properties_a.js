var searchData=
[
  ['scanning',['scanning',['../interface_r_b_t_central_module.html#a744b539d273e36beedfc91cebb762587',1,'RBTCentralModule::scanning()'],['../category_r_b_t_central_module_07_08.html#a348d5f0d952dd44f37953b0f667b6b8d',1,'RBTCentralModule()::scanning()']]],
  ['scanstate',['scanState',['../interface_r_b_t_central_module.html#a723e32c066db9fa567acfc9c4f801e6f',1,'RBTCentralModule']]],
  ['scantimer',['scanTimer',['../category_r_b_t_peripheral_07_08.html#afa047420ac232983736a4aa401653bfe',1,'RBTPeripheral()']]],
  ['service',['service',['../interface_r_b_t_characteristic.html#a331c5ad4d0f3eb16e527991a85c932a8',1,'RBTCharacteristic::service()'],['../interface_r_b_t_descriptor.html#a30ab7f779267fb89de28d22664e57cd2',1,'RBTDescriptor::service()'],['../interface_r_b_t_mutable_characteristic.html#a54c11bf9c2707b4b9e16df904208447c',1,'RBTMutableCharacteristic::service()']]],
  ['servicedictionary',['serviceDictionary',['../category_r_b_t_peripheral_07_08.html#a788e8974e229ac0d05ff0cc38238312f',1,'RBTPeripheral()']]],
  ['services',['services',['../interface_r_b_t_peripheral.html#a800d987d84a1a8bc44334e0cf177797b',1,'RBTPeripheral::services()'],['../interface_r_b_t_peripheral_module.html#afd3f9752c4a115ece210d8569d9be47f',1,'RBTPeripheralModule::services()']]],
  ['servicesarray',['servicesArray',['../category_r_b_t_peripheral_module_07_08.html#a7598307e279f87cb54f9f1ae0329bd75',1,'RBTPeripheralModule()']]]
];
