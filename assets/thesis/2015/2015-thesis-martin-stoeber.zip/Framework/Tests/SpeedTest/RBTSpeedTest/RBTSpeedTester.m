//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTSpeedTester.h"
#import <ReactiveBluetoothLE/ReactiveBluetoothLE.h>

@interface RBTSpeedTester ()

@property(nonatomic) RBTCentralModule *centralModule;
@property(nonatomic) RBTPeripheral *peripheral;
@property(nonatomic) RBTService *service;
@property(nonatomic) RBTCharacteristic *characteristic;

@property NSDate *startDate;

@end

@implementation RBTSpeedTester

- (instancetype)init {
    self = [super init];
    if (self) {
        _centralModule = [[RBTCentralModule alloc] init];
        [self initTest];
    }
    return self;
}

- (void)initTest {
    @weakify(self)
    [[self.centralModule.bluetoothState filter:^BOOL(NSNumber *state) {
        return ([state isEqual:@(5)]);
    }] subscribeNext:^(id x) {
        @strongify(self)
        self.startDate = [NSDate date];
        [self startTest];
    }];
}

- (void)startTest {
    CBUUID *testServiceUUID = [CBUUID UUIDWithString:@"AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA"];
    CBUUID *testCharacteristicUUID = [CBUUID UUIDWithString:@"BBBBBBBB-BBBB-BBBB-BBBB-BBBBBBBBBBBB"];
    @weakify(self)

    // scan for peripherals
    [[[self.centralModule scan] take:1] subscribeNext:^(RBTPeripheral *peripheral) {
        @strongify(self)
        self.peripheral = peripheral;

        // conntect to peripheral
        [[self.peripheral connect] subscribeCompleted:^{
            @strongify(self)

            // discover services
            [[self.peripheral discoverServices] subscribeCompleted:^{
                @strongify(self)
                self.service = [self.peripheral serviceWithUUUID:testServiceUUID];

                // discover characteristics
                [[self.service discoverAllCharacteristics] subscribeCompleted:^{
                    @strongify(self)
                    self.characteristic = [self.service characteristicWithUUUID:testCharacteristicUUID];

                    [self readAndWrite];
                }];
            }];
        }];
    }];
}

- (void)readAndWrite {
    @weakify(self)

    // read characteristic
    [[self.characteristic readValue] subscribeCompleted:^{
        @strongify(self)
        NSLog(@"Characteristic Value: %@", self.characteristic.value);

        // write characteristic
        [[self.characteristic writeValue:[@"TEST" dataUsingEncoding:NSUTF8StringEncoding] withResponse:YES] subscribeCompleted:^{
            @strongify(self)
            NSLog(@"%f", [[NSDate date] timeIntervalSinceDate:self.startDate]);

            // disconnect peripheral
            [self.peripheral disconnect];
        }];
    }];
}

@end
