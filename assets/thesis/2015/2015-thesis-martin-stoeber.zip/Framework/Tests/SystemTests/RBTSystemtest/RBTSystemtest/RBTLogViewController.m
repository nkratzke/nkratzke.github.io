//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTLogViewController.h"

@interface RBTLogViewController ()

@property (weak, nonatomic) IBOutlet UITextView *logTextView;

@end



@implementation RBTLogViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.logTextView.text = self.log;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
