//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTTestCaseTableViewController.h"
#import "RBTLogViewController.h"
#import "RBTTestCaseErrors.h"


@interface RBTTestCaseTableViewController ()

// UI
@property (weak, nonatomic) IBOutlet UILabel *descriptionLabel;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activitySpinner;
@property (weak, nonatomic) IBOutlet UILabel *statusLabel;
@property (weak, nonatomic) IBOutlet UILabel *executeLabel;
@property (weak, nonatomic) IBOutlet UITableViewCell *executeCell;
@property (weak, nonatomic) IBOutlet UIImageView *statusImage;

// testcases
@property (nonatomic) BOOL testStarted;
@property (nonatomic) BOOL testFinished;
@property (nonatomic) NSMutableString *log;

@property (nonatomic) RACDisposable *resultDisposable;
@property (nonatomic) RACDisposable *logDisposable;

@property (nonatomic) NSTimer *timeoutTimer;


@end

@implementation RBTTestCaseTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.testStarted = NO;
    self.testFinished = NO;
    self.log = [[NSMutableString alloc]init];
    [self setupTestCase];
    self.timeoutTimer = [NSTimer scheduledTimerWithTimeInterval:30 target:self selector:@selector(timeout:) userInfo:nil repeats:NO];
}

-(void)viewDidDisappear:(BOOL)animated {
    [self.timeoutTimer invalidate];
    [self.testCase reset];
    [super viewDidDisappear:animated];
}

- (void)setupTestCase {
    // update ui
    self.navigationItem.title = self.testCase.testTitle;
    self.descriptionLabel.text = self.testCase.testDescription;
    
    // handle test result
    @weakify(self)
    self.resultDisposable = [self.testCase.testResult subscribeError:^(NSError *error) {
        @strongify(self)
        [self testFailed:error];
    } completed:^{
        @strongify(self)
        [self testSucceeded];
    }];
    
    // handle test log
    self.logDisposable = [self.testCase.testLog subscribeNext:^(NSString *logLine) {
        [self appendLog:logLine];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (self.testStarted) {
        if (self.testFinished) {
            return 4;
        }
        return 3;
    }
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [super tableView:tableView cellForRowAtIndexPath:indexPath];
    return cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (!self.testStarted && indexPath.section == 1 && indexPath.row == 0) {
        [self executeTestCase];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    // update cell height
    if (indexPath.section == 0 && indexPath.row == 0) {
            // description cell
            NSAttributedString *attributedText = [[NSAttributedString alloc] initWithString:self.testCase.testDescription
                                                                                 attributes:@{NSFontAttributeName:self.descriptionLabel.font}];
            CGRect rect = [attributedText boundingRectWithSize:(CGSize){self.descriptionLabel.frame.size.width+50, CGFLOAT_MAX}
                                                       options:NSStringDrawingUsesLineFragmentOrigin
                                                       context:nil];
            return ceil(rect.size.height)+44.f;
    } else if (indexPath.section == 2 && indexPath.row == 0) {
        // status cell
        return 60;
    }
    
    return 44.f;
}


#pragma mark - Test handling

- (void)executeTestCase {
    // update UI
    [self.activitySpinner startAnimating];
    self.statusLabel.text = @"Test is running...";
    self.executeLabel.textColor = [UIColor grayColor];
    self.testStarted = true;
    self.executeCell.selectionStyle =     UITableViewCellSelectionStyleNone;
    [self.tableView reloadData];

    [self appendLog:@"Test started"];
    [self.testCase execute];
}

- (void)testSucceeded {
    // dispose signals

    [self.resultDisposable dispose];
    [self.logDisposable dispose];
    
    // update UI
    self.statusLabel.text = @"Test succeeded!";
    [self appendLog:@"Test succeeded"];
    [self.activitySpinner stopAnimating];
    self.statusImage.image = [UIImage imageNamed:@"tick"];
    self.statusImage.hidden = NO;
    self.testFinished = YES;
    [self.tableView reloadData];
}

- (void)testFailed:(NSError *)error {
    // dispose signals
    [self.resultDisposable dispose];
    [self.logDisposable dispose];
    
    // update UI
    self.statusLabel.text = @"Test failed!";
    [self appendLog:@"Test failed!"];
    [self.log appendFormat:@"\nReason:\n%@",error];
    NSLog(@"\nReason:\n%@",error);
    [self.activitySpinner stopAnimating];
    self.statusImage.image = [UIImage imageNamed:@"error"];
    self.statusImage.hidden = NO;
    self.testFinished = YES;
    [self.tableView reloadData];
}


#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    RBTLogViewController *logViewController = [segue destinationViewController];
    logViewController.log = self.log;
}


#pragma mark - Private helper

- (void)appendLog:(NSString *)logText {
    NSLog(@"[%@] %@\n",[NSDate date],logText);
    [self.log appendFormat:@"[%@] %@\n",[NSDate date],logText];
}

-(void)timeout:(NSTimer *)timer {
    //handle timeout
    [self.testCase.testResult sendError:[RBTTestCaseErrors timeoutError]];
    [self.timeoutTimer invalidate];
}


@end
