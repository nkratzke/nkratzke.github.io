//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTTestCasesController.h"
#import "ReactiveBluetoothLE.h"

#import "RBTTest1.h"
#import "RBTTest2.h"
#import "RBTTest3.h"
#import "RBTTest4.h"
#import "RBTTest5.h"
#import "RBTTest6.h"
#import "RBTTest7.h"
#import "RBTTest8.h"
#import "RBTTest9.h"
#import "RBTTest10.h"
#import "RBTTest11.h"


@interface RBTTestCasesController ()

@property (nonatomic) NSArray *testCaseClasses;

@end



@implementation RBTTestCasesController

- (instancetype)init
{
    self = [super init];
    if (self) {
        //add new testcases here
        _testCaseClasses = @[[RBTTest1 class],
                             [RBTTest2 class],
                             [RBTTest3 class],
                             [RBTTest4 class],
                             [RBTTest5 class],
                             [RBTTest6 class],
                             [RBTTest7 class],
                             [RBTTest8 class],
                             [RBTTest9 class],
                             [RBTTest10 class],
                             [RBTTest11 class]
                             ];
    }
    return self;
}


-(NSArray *)testCases {
    NSMutableArray *testCases = [NSMutableArray array];
    for (Class testCaseClass in self.testCaseClasses) {
        id testCase = [[testCaseClass alloc]init];
        
        // check if valid testcase
        if ([testCase conformsToProtocol:@protocol(RBTTestCase)]) {
            [testCases addObject:testCase];
        }
    }
    return testCases;
}

@end
