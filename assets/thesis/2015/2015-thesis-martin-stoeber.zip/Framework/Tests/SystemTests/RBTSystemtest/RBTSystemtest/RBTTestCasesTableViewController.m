//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTTestCasesTableViewController.h"
#import "RBTTestCaseTableViewController.h"
#import "RBTTestCasesController.h"
#import "RBTTestCase.h"


@interface RBTTestCasesTableViewController ()

@property (nonatomic) NSArray *testCases;

@end



@implementation RBTTestCasesTableViewController

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    RBTTestCasesController *testCasesController = [[RBTTestCasesController alloc]init];
    _testCases = [testCasesController testCases];
    [self.tableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.testCases count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString* testCasesCell= @"TestCasesCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:testCasesCell forIndexPath:indexPath];
    
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:testCasesCell];
    }
    
    id<RBTTestCase> testCase = self.testCases[indexPath.row];
    cell.textLabel.text = testCase.testTitle;
    
    return cell;
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    NSIndexPath *indexPath = [self.tableView indexPathForCell:sender];
    RBTTestCaseTableViewController *testCaseTableViewController = [segue destinationViewController];
    testCaseTableViewController.testCase = self.testCases[indexPath.row];
}


@end
