//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTTest1.h"
#import "RBTTestCaseErrors.h"


@interface RBTTest1 ()

@property(nonatomic) NSString *testTitle;
@property(nonatomic) NSString *testDescription;
@property(nonatomic) RACSubject *testResult;
@property(nonatomic) RACSubject *testLog;


@property(nonatomic) RBTCentralModule *centralModule;
@property(nonatomic) RBTPeripheralModule *peripheralModule;

@end;


@implementation RBTTest1

#pragma mark - TestCase implementation

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}

- (void) setup {
    self.testTitle = @"Systemtest 1: FA01";
    self.testDescription = @"This test should check the bluetooth state of the central and peripheral moudle. \nSucceeded when both modules are ready. \n30 sec timeout.";
    self.testResult = [RACSubject subject];
    self.testLog = [RACSubject subject];
    
    self.centralModule = [[RBTCentralModule alloc]init];
    self.peripheralModule = [[RBTPeripheralModule alloc]init];
}

- (void) execute {    
    @weakify(self)
    [self.centralModule.bluetoothState subscribeNext:^(NSNumber *state) {
        
        @strongify(self)
        if (state.integerValue == 5) {
            [self.testLog sendNext:@"Central state changed to Ready."];
        }
        
    }];
    
    [self.peripheralModule.peripheralState subscribeNext:^(NSNumber *state) {
        @strongify(self)
        if (state.integerValue == 5) {
            [self.testLog sendNext:@"Peripheral state changed to Ready."];
        }
    }];
    
    [[RACSignal combineLatest:@[self.centralModule.bluetoothState, self.peripheralModule.peripheralState] reduce:^id(NSNumber *centralState, NSNumber *peripheralState){
        if (centralState.integerValue == 5 && peripheralState.integerValue == 5) {
            [self.testResult sendCompleted];
        }
        return nil;
    }] subscribeCompleted:^{
        [self.testLog sendNext:@"Test succeded"];

    }];
}

- (void)reset {

}

@end
