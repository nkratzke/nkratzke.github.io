//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTTest11.h"
#import <ReactiveBluetoothLE/RBTPeripheral+Beacon.h>
#import "RBTTestCaseErrors.h"

@interface RBTTest11 ()

@property(nonatomic) NSString *testTitle;
@property(nonatomic) NSString *testDescription;
@property(nonatomic) RACSubject *testResult;
@property(nonatomic) RACSubject *testLog;

@property(nonatomic) RBTCentralModule *centralModule;
@property(nonatomic) RBTPeripheral *peripheral;
@property(nonatomic) RBTService *service;

@end

@implementation RBTTest11

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}

- (void) setup {
    self.testTitle = @"Systemtest 11: FA15";
    self.testDescription = @"Connect and read RSSI and distance from a peripheral. \n30Sec timeout. \nReq: There should be a peripheral within range.";
    self.testResult = [RACSubject subject];
    self.testLog = [RACSubject subject];
    
    self.centralModule = [[RBTCentralModule alloc]init];
}

- (void) execute {
    @weakify(self)
    [self.centralModule.bluetoothState subscribeNext:^(NSNumber *state) {
        
        @strongify(self)
        if (state.integerValue == 5) {
            [self.testLog sendNext:@"Bluetooth state changed to Ready"];
            
            [[[self.centralModule scanWithDuplicates:YES]take:1] subscribeNext:^(RBTPeripheral *peripheral) {
                @strongify(self)
                [self.testLog sendNext:@"Found peripheral"];
                self.peripheral = peripheral;
                [self.testLog sendNext:@"Try to connect to Peripheral"];
                
                [[self.peripheral connect] subscribeCompleted:^{
                    @strongify(self)
                    [self.testLog sendNext:@"Connected successfully"];

                    [self.testLog sendNext:[NSString stringWithFormat:@"Read RSSI: %@", self.peripheral.RSSI]];
                    [self.testLog sendNext:[NSString stringWithFormat:@"Distance: %fm", [self.peripheral calculateDistance].floatValue]];
                    [self.testResult sendCompleted];

                }];
            }];
        }
    }];
}

- (void)reset {
    if (self.peripheral) {
        [self.peripheral disconnect];
    }
}

@end
