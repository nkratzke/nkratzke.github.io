//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ReactiveBluetoothLE/ReactiveBluetoothLE.h>

#import "RBTTestCase.h"

@interface RBTTest2 : NSObject<RBTTestCase>

@end
