//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTTest2.h"
#import "RBTTestCaseErrors.h"


@interface RBTTest2 ()

@property(nonatomic) NSString *testTitle;
@property(nonatomic) NSString *testDescription;
@property(nonatomic) RACSubject *testResult;
@property(nonatomic) RACSubject *testLog;

@property(nonatomic) RBTCentralModule *centralModule;
@property(nonatomic) RBTPeripheral *peripheral;

@end

@implementation RBTTest2

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}

- (void) setup {
    self.testTitle = @"Systemtest 2: FA02";
    self.testDescription = @"Scan for peripherals. \n30sec timeout. Succeeded when a peripheral was found. \nReq: There should be a peripheral within range.";
    self.testResult = [RACSubject subject];
    self.testLog = [RACSubject subject];
    
    self.centralModule = [[RBTCentralModule alloc]init];
}

- (void) execute {
    @weakify(self)
    [self.centralModule.bluetoothState subscribeNext:^(NSNumber *state) {
        
        @strongify(self)
        if (state.integerValue == 5) {
            [self.testLog sendNext:@"Bluetooth state changed to Ready"];
            
            [[[self.centralModule scanWithDuplicates:YES]take:1] subscribeNext:^(RBTPeripheral *peripheral) {
                @strongify(self)
                [self.testLog sendNext:@"Found peripheral"];
                self.peripheral = peripheral;
                if (self.peripheral) {
                    [self.testResult sendCompleted];
                }
            }];
        }
    }];
}

- (void)reset {
    if (self.peripheral) {
        [self.peripheral disconnect];
    }
}

@end
