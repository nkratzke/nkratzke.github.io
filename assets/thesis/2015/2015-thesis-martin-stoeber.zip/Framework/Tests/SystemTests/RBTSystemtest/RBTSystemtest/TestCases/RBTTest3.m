//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTTest3.h"
#import "RBTTestCaseErrors.h"


@interface RBTTest3 ()

@property(nonatomic) NSString *testTitle;
@property(nonatomic) NSString *testDescription;
@property(nonatomic) RACSubject *testResult;
@property(nonatomic) RACSubject *testLog;

@property(nonatomic) RBTCentralModule *centralModule;
@property(nonatomic) RBTPeripheral *peripheral;

@end


@implementation RBTTest3

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}

- (void) setup {
    self.testTitle = @"Systemtest 3: FA04";
    self.testDescription = @"Connect and disconnect to a peripheral. \n30sec timeout. \nReq: There should be a peripheral within range.";
    self.testResult = [RACSubject subject];
    self.testLog = [RACSubject subject];
    
    self.centralModule = [[RBTCentralModule alloc]init];
}

- (void) execute {
    @weakify(self)
    [self.centralModule.bluetoothState subscribeNext:^(NSNumber *state) {
        
        @strongify(self)
        if (state.integerValue == 5) {
            [self.testLog sendNext:@"Bluetooth state changed to Ready"];
            
            [[[self.centralModule scanWithDuplicates:YES]take:1] subscribeNext:^(RBTPeripheral *peripheral) {
                @strongify(self)
                [self.testLog sendNext:@"Found peripheral"];
                self.peripheral = peripheral;
                [self.testLog sendNext:@"Try to connect to Peripheral"];
                
                [[self.peripheral connect] subscribeError:^(NSError *error) {
                    [self.testResult sendError:error];
                }completed:^{
                    @strongify(self)
                    [self.testLog sendNext:@"Connected successfully"];
                    [[self.peripheral disconnect] subscribeError:^(NSError *error) {
                        [self.testResult sendError:error];
                    }completed:^{
                        @strongify(self)
                        [self.testLog sendNext:@"Disconnected successfully"];
                        [self.testResult sendCompleted];
                    }];
                }];
            }];
        }
    }];
}

- (void)reset {
    if (self.peripheral) {
        [self.peripheral disconnect];
    }
}

@end
