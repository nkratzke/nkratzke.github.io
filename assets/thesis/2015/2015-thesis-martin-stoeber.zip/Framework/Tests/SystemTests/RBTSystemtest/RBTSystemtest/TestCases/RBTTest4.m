//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTTest4.h"
#import "RBTTestCaseErrors.h"


@interface RBTTest4 ()

@property(nonatomic) NSString *testTitle;
@property(nonatomic) NSString *testDescription;
@property(nonatomic) RACSubject *testResult;
@property(nonatomic) RACSubject *testLog;

@property(nonatomic) RBTPeripheralModule *peripheralModule;

@end

@implementation RBTTest4

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}

- (void) setup {
    self.testTitle = @"Systemtest 4: FA05";
    self.testDescription = @"Send advertise data to nerby centrals. \n30 sec timeout.";
    self.testResult = [RACSubject subject];
    self.testLog = [RACSubject subject];
    
    self.peripheralModule = [[RBTPeripheralModule alloc]init];
}

- (void) execute {
    @weakify(self)
    [self.peripheralModule.peripheralState subscribeNext:^(NSNumber *state) {
        @strongify(self)
        if (state.integerValue == 5) {
            [self.testLog sendNext:@"Peripheral state changed to Ready"];
            [self.testLog sendNext:@"Going to start Advertising"];
            
            [[self.peripheralModule startAdvertising] subscribeError:^(NSError *error) {
                @strongify(self)
                [self.testResult sendError:error];
            } completed: ^{
                @strongify(self)
                [self.testLog sendNext:@"Advertising started"];
                [self.testResult sendCompleted];
            }];
        }
    }];
}

- (void)reset {
    if (self.peripheralModule) {
        [self.peripheralModule stopAdvertising];
    }
}

@end
