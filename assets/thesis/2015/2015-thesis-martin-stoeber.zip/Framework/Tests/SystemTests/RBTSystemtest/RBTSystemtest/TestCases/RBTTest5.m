//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTTest5.h"
#import "RBTTestCaseErrors.h"


@interface RBTTest5 ()

@property(nonatomic) NSString *testTitle;
@property(nonatomic) NSString *testDescription;
@property(nonatomic) RACSubject *testResult;
@property(nonatomic) RACSubject *testLog;

@property(nonatomic) RBTPeripheralModule *peripheralModule;
@property(nonatomic) RBTMutableService *service;
@property(nonatomic) RBTMutableCharacteristic *characteristic;

@end

@implementation RBTTest5

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}

- (void) setup {
    self.testTitle = @"Systemtest 5: FA09";
    self.testDescription = @"Initalize a peripheral module, add a service and a characteristic and send a Indication to centrals. \n30Sec timeout.";
    self.testResult = [RACSubject subject];
    self.testLog = [RACSubject subject];
    
    self.peripheralModule = [[RBTPeripheralModule alloc]init];
    self.service = [[RBTMutableService alloc]initPrimaryServiceWithUUID:[CBUUID UUIDWithString:@"591F4471-3537-4EFC-9213-DFB52C66A19F"]];
    self.characteristic = [[RBTMutableCharacteristic alloc] initWithUUID:[CBUUID UUIDWithString:@"A4A83025-C5F3-4ACC-BF7A-A7DDF8D52514"]
                                                                                    properties:(CBCharacteristicPropertyRead | CBCharacteristicPropertyIndicate | CBCharacteristicPropertyNotify)
                                                                                         value:nil
                                                                                   permissions:CBAttributePermissionsReadable];
}

- (void) execute {
    @weakify(self)
    [self.peripheralModule.peripheralState subscribeNext:^(NSNumber *state) {
        @strongify(self)
        if (state.integerValue == 5) {
            [self.testLog sendNext:@"Peripheral state changed to Ready"];
            
            [self.service addCharacteristic:self.characteristic];
            [self.testLog sendNext:@"Characteristic added"];

            [[self.peripheralModule addService:self.service] subscribeCompleted:^{
                @strongify(self)
                [self.testLog sendNext:@"Service added"];

                uint8_t initState = 0;
                self.characteristic.value = [NSData dataWithBytes:&initState length:(sizeof(initState))];
                
                [self.testLog sendNext:@"Going to start Advertising"];
                [[self.peripheralModule startAdvertising] subscribeError:^(NSError *error) {
                    @strongify(self)
                    [self.testResult sendError:error];
                } completed: ^{
                    @strongify(self)
                    [self.testLog sendNext:@"Advertising started"];
                    if ([self.characteristic notifySubscribedCentrals]) {
                        [self.testResult sendCompleted];
                    }
                }];
            }];
        }
    }];
}

- (void)reset {
    if (self.peripheralModule) {
        [self.peripheralModule stopAdvertising];
    }
}

@end
