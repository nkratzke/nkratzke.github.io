//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTTest6.h"
#import "RBTTestCaseErrors.h"


@interface RBTTest6 ()

@property(nonatomic) NSString *testTitle;
@property(nonatomic) NSString *testDescription;
@property(nonatomic) RACSubject *testResult;
@property(nonatomic) RACSubject *testLog;

@property(nonatomic) RBTCentralModule *centralModule;
@property(nonatomic) RBTPeripheral *peripheral;
@property(nonatomic) RBTService *service;
@property(nonatomic) RBTCharacteristic *characteristic;

@end



@implementation RBTTest6

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}

- (void) setup {
    self.testTitle = @"Systemtest 6: FA10";
    self.testDescription = @"Connect to a peripheral and search for services. \n30sec timeout. \nReq: There should be an peripheral within range.";
    self.testResult = [RACSubject subject];
    self.testLog = [RACSubject subject];
    
    self.centralModule = [[RBTCentralModule alloc]init];
}

- (void) execute {
    @weakify(self)
    [self.centralModule.bluetoothState subscribeNext:^(NSNumber *state) {
        
        @strongify(self)
        if (state.integerValue == 5) {
            [self.testLog sendNext:@"Bluetooth state changed to Ready"];
            
            [[[self.centralModule scanWithDuplicates:YES]take:1] subscribeNext:^(RBTPeripheral *peripheral) {
                @strongify(self)
                [self.testLog sendNext:@"Found peripheral"];
                self.peripheral = peripheral;
                [self.testLog sendNext:@"Try to connect to Peripheral"];
                
                [[self.peripheral connect] subscribeCompleted:^{
                    @strongify(self)
                    [self.testLog sendNext:@"Connected successfully"];
                    
                    [[self.peripheral discoverServices] subscribeError:^(NSError *error) {
                        @strongify(self)
                        [self.testResult sendError:error];
                    } completed:^{
                        @strongify(self)
                        [self.testLog sendNext:@"Discovered services"];
                        self.service=[self.peripheral serviceWithUUUID:[CBUUID UUIDWithString:@"AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA"]];
                        if (self.service) {
                            [self.testResult sendCompleted];
                        }
                    }];
                }];
            }];
        }
    }];
}

- (void)reset {
    if (self.peripheral) {
        [self.peripheral disconnect];
    }
}

@end
