//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTTest8.h"
#import "RBTTestCaseErrors.h"


@interface RBTTest8 ()

@property(nonatomic) NSString *testTitle;
@property(nonatomic) NSString *testDescription;
@property(nonatomic) RACSubject *testResult;
@property(nonatomic) RACSubject *testLog;

@property(nonatomic) RBTCentralModule *centralModule;
@property(nonatomic) RBTPeripheral *peripheral;
@property(nonatomic) RBTService *service;
@property(nonatomic) RBTCharacteristic *characteristic;

@end

@implementation RBTTest8


- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}

- (void) setup {
    self.testTitle = @"Systemtest 8: FA12";
    self.testDescription = @"Connect to a peripheral and write 'Test' to a characteristic. \n30sec timeout. \nReq: There should be a peripheral within range.";
    self.testResult = [RACSubject subject];
    self.testLog = [RACSubject subject];
    
    self.centralModule = [[RBTCentralModule alloc]init];
}

- (void) execute {
    @weakify(self)
    [self.centralModule.bluetoothState subscribeNext:^(NSNumber *state) {
        
        @strongify(self)
        if (state.integerValue == 5) {
            [self.testLog sendNext:@"Bluetooth state changed to Ready"];
            
            [[[self.centralModule scanWithDuplicates:YES]take:1] subscribeNext:^(RBTPeripheral *peripheral) {
                @strongify(self)
                [self.testLog sendNext:@"Found peripheral"];
                self.peripheral = peripheral;
                [self.testLog sendNext:@"Try to connect to Peripheral"];
                
                [[self.peripheral connect] subscribeCompleted:^{
                    @strongify(self)
                    [self.testLog sendNext:@"Connected successfully"];
                    
                    [[self.peripheral discoverServices] subscribeError:^(NSError *error) {
                        @strongify(self)
                        [self.testResult sendError:error];
                    } completed:^{
                        @strongify(self)
                        [self.testLog sendNext:@"Discovered services"];
                        self.service=[self.peripheral serviceWithUUUID:[CBUUID UUIDWithString:@"AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA"]];
                        if (self.service) {
                            [[self.service discoverAllCharacteristics] subscribeError:^(NSError *error) {
                                @strongify(self)
                                [self.testResult sendError:error];
                            } completed:^{
                                @strongify(self)
                                [self.testLog sendNext:@"Discovered characteristic"];
                                self.characteristic = [self.service characteristicWithUUUID:[CBUUID UUIDWithString:@"BBBBBBBB-BBBB-BBBB-BBBB-BBBBBBBBBBBB"]];
                                if (self.characteristic) {
                                    [self.testLog sendNext:@"Write 'Test' to characteristic"];

                                    [[self.characteristic writeValue:[@"Test" dataUsingEncoding:NSUTF8StringEncoding] withResponse:YES] subscribeError:^(NSError *error) {
                                        @strongify(self)
                                        [self.testResult sendError:error];
                                    } completed:^{
                                        @strongify(self)
                                        [self.testResult sendCompleted];
                                    }];
                                }
                            }];
                        }
                    }];
                }];
            }];
        }
    }];
}

- (void)reset {
    if (self.peripheral) {
        [self.peripheral disconnect];
    }
}

@end
