//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ReactiveCocoa/ReactiveCocoa.h>

@protocol RBTTestCase <NSObject>

@required

/// test title
@property (nonatomic, readonly) NSString *testTitle;

/// test description (should conatin short summery + requiements)
@property (nonatomic, readonly) NSString *testDescription;

/// test result -> sendCompleted for success -> sendError for fail
@property (nonatomic, readonly) RACSubject *testResult;

/// test logging -> sendnext to log to console and to logview
@property (nonatomic, readonly) RACSubject *testLog;


/// setup test case (init etc.)
-(void)setup;

/// test executing method
-(void)execute;

/// cleanup after test method (e.g. to restart)
-(void)reset;

@end
