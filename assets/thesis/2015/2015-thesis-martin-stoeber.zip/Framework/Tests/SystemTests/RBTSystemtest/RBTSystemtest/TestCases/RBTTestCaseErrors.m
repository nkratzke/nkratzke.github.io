//
//  MSTestCaseErrors.m
//  RBTSystemtest
//
//  Created by Martin Stöber on 08.02.15.
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTTestCaseErrors.h"

@implementation RBTTestCaseErrors

+(NSError *)timeoutError {
    return [[NSError alloc]initWithDomain:[[NSBundle mainBundle] bundleIdentifier] code:1 userInfo:@{NSLocalizedDescriptionKey:@"Test timed out."}];
}

@end
