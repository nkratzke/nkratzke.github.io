//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTBluetoothTestHelper.h"


@interface RBTBluetoothTestHelper ()

@property (nonatomic) CBPeripheralManager *peripheralManager;
@property (nonatomic) CBMutableService *testService;
@property (nonatomic) CBMutableCharacteristic *testCharacteristic;
@property (nonatomic) CBMutableDescriptor *testDescriptor;

@end



@implementation RBTBluetoothTestHelper

- (instancetype)init
{
    self = [super init];
    if (self) {
        _peripheralManager = [[CBPeripheralManager alloc] initWithDelegate:self queue:nil];
        [self setupCentralTestHelper];
    }
    return self;
}

- (void)setupCentralTestHelper {
    CBUUID *testServiceUUID = [CBUUID UUIDWithString:@"AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA"];
    CBUUID *testCharacteristicUUID = [CBUUID UUIDWithString:@"BBBBBBBB-BBBB-BBBB-BBBB-BBBBBBBBBBBB"];
    CBUUID *testDescriptorUUID = [CBUUID UUIDWithString:CBUUIDCharacteristicUserDescriptionString];

    self.testService = [[CBMutableService alloc]initWithType:testServiceUUID primary:YES];
    
    self.testCharacteristic = [[CBMutableCharacteristic alloc]initWithType:testCharacteristicUUID properties:(CBCharacteristicPropertyRead | CBCharacteristicPropertyWrite |CBCharacteristicPropertyWriteWithoutResponse | CBCharacteristicPropertyNotify | CBCharacteristicPropertyIndicate) value:nil permissions:(CBAttributePermissionsReadable | CBAttributePermissionsWriteable)];
    
    self.testDescriptor = [[CBMutableDescriptor alloc]initWithType:testDescriptorUUID value:@"testDescriptor"];
    
    self.testCharacteristic.descriptors = @[self.testDescriptor];
    self.testService.characteristics = @[self.testCharacteristic];
}

- (void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral {
    if (peripheral.state == CBPeripheralManagerStatePoweredOn) {
        [self.peripheralManager addService:self.testService];
    }
}

- (void)peripheralManagerDidStartAdvertising:(CBPeripheralManager *)peripheral error:(NSError *)error
{
    NSLog(@"Started advertising");
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral didAddService:(CBService *)service error:(NSError *)error {
    if (error) {
        NSLog(@"Couldn't add Service '%@': %@", service, error);
    }
    self.testCharacteristic.value = [@"TEST" dataUsingEncoding:NSUTF8StringEncoding];

    [self.peripheralManager startAdvertising:@{ CBAdvertisementDataLocalNameKey: @"TEST-DEVICE",
                                                CBAdvertisementDataServiceUUIDsKey: @[self.testService.UUID] }];
}

-(void)peripheralManager:(CBPeripheralManager *)peripheral didReceiveReadRequest:(CBATTRequest *)request {
    if (request.offset > self.testCharacteristic.value.length) {
        [self.peripheralManager respondToRequest:request withResult:CBATTErrorInvalidOffset];
        return;
    }
    request.value = [self.testCharacteristic.value subdataWithRange:NSMakeRange(request.offset,
                                                                                self.testCharacteristic.value.length - request.offset)];
    [self.peripheralManager respondToRequest:request withResult:CBATTErrorSuccess];
}

-(void)peripheralManager:(CBPeripheralManager *)peripheral didReceiveWriteRequests:(NSArray *)requests {
    for (CBATTRequest *request in requests) {
        self.testCharacteristic.value = request.value;
        [self.peripheralManager respondToRequest:request withResult:CBATTErrorSuccess];
    }
}

@end
