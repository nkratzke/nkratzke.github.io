//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTMainViewController.h"
#import <CoreBluetooth/CoreBluetooth.h>
#import "RBTBluetoothTestHelper.h"


@interface RBTMainViewController ()
@property (weak) IBOutlet NSTextField *statusLabel;

@property (nonatomic) RBTBluetoothTestHelper *centralTestHelper;


@end

@implementation RBTMainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
}
- (IBAction)startTestHelper:(id)sender {
    self.centralTestHelper = [[RBTBluetoothTestHelper alloc]init];
    
    if (self.centralTestHelper) {
        [self.statusLabel setStringValue:@"Test Helper Active!"];
    }
}

@end
