//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//


//
// Unit test 1: FA3 Bekannte Bluetooth LE Geräte verwalten
//

#import <XCTest/XCTest.h>
#import <OCMock/OCMock.h>
#import "RBTCentralModule_TestExtensions.h"

#import "RBTPeripheral.h"


@interface RBTUnitTest1 : XCTestCase

@end


@implementation RBTUnitTest1

- (void)setUp {
    [super setUp];
}

- (void)tearDown {
    [super tearDown];
}

-(void)testRetriveConnectedPeripherals {
    RBTCentralModule *centralModule = [[RBTCentralModule alloc]init];
    
    // mock CBPeripheral
    id peripheral = OCMClassMock([CBPeripheral class]);
    OCMStub([peripheral identifier]).andReturn([NSUUID UUID]);
    
    // fake call successful connect
    [centralModule.cbCentralManager.delegate centralManager:centralModule.cbCentralManager didConnectPeripheral:peripheral];
    
    // check retrieving
    XCTAssertTrue([[centralModule retrieveConnectedPeripherals] array].count == 1, "There should be one connected peripheral.");
    
    [peripheral verify];
}

- (void)testRetrivePeripherals {
    RBTCentralModule *centralModule = [[RBTCentralModule alloc]init];

    // mock CBCentralManager
    CBCentralManager *centralManager = [[CBCentralManager alloc]initWithDelegate:centralModule queue:nil];
    id cbCentralModuleMock = OCMPartialMock(centralManager);
    
    // mock CB peripheral
    id peripheral = OCMClassMock([CBPeripheral class]);
    OCMStub([peripheral identifier]).andReturn([NSUUID UUID]);
    
    // check CB retrieving
    OCMStub([cbCentralModuleMock retrieveConnectedPeripheralsWithServices:[OCMArg any]]).andReturn(@[peripheral]);

    centralModule.cbCentralManager = cbCentralModuleMock;
    
    // call RBT retrieving
    [centralModule retrieveDeviceConnectedPeripheralsWithServices:@[[CBUUID UUIDWithString:@"A005B5C7-0E14-4963-8331-50278C368421"]]];
    [centralModule retrieveKnownPeripheralsWithIdentifiers:@[[NSUUID UUID]]];

    [cbCentralModuleMock verify];
}

-(void)testPeripheralWrapping {
    RBTCentralModule *centralModule = [[RBTCentralModule alloc]init];
    
    // mock CBPeripheral
    id peripheral = OCMClassMock([CBPeripheral class]);
    OCMStub([peripheral identifier]).andReturn([NSUUID UUID]);
    
    // test wrapping
    [centralModule wrapPeripherals:@[peripheral]];
    
    // check wrapping
    XCTAssertTrue([centralModule wrapPeripherals:@[peripheral]].count == 1, "There should be one peripheral.");

    [peripheral verify];
}

@end
