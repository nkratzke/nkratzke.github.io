//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//


//
// Unit test 2: FA6  Services hinzufügen und entfernen
//

#import <XCTest/XCTest.h>
#import "RBTPeripheralModule.h"
#import "RBTMutableService.h"

@interface RBTUnitTest2 : XCTestCase


@property (nonatomic) RBTPeripheralModule *peripheralModule;

@end

@implementation RBTUnitTest2

- (void)setUp {
    [super setUp];
    _peripheralModule = [[RBTPeripheralModule alloc]init];
}

- (void)tearDown {
    [super tearDown];
    _peripheralModule = nil;
}

- (void)testAddService {
    RBTMutableService *service = [[RBTMutableService alloc]initPrimaryServiceWithUUID:[CBUUID UUIDWithString:@"DF788729-958B-464C-A4A5-8DA53692FF45"]];
    
    [[self.peripheralModule addService:service] subscribeCompleted:^{
        NSLog(@"completed");
    }];
    
    // mock corebluetooth
    [self.peripheralModule.cbPeripheralManager.delegate peripheralManager:self.peripheralModule.cbPeripheralManager didAddService:service.cbService error:nil];
    
    XCTAssertTrue(self.peripheralModule.services.count == 1, "There should be a service.");
    XCTAssertTrue(service.isPublished == YES, "Service should be published.");
}

- (void)testAddServiceWithIncludedService {
    RBTMutableService *service = [[RBTMutableService alloc]initPrimaryServiceWithUUID:[CBUUID UUIDWithString:@"AF788729-958B-464C-A4A5-8DA53692FF45"]];
    RBTMutableService *includedService = [[RBTMutableService alloc]initWithUUID:[CBUUID UUIDWithString:@"BF788729-958B-464C-A4A5-8DA53692FF45"] primary:NO];
    [service addIncludedService:includedService];
    
    XCTAssertTrue(service.includedServices.count == 1, "There should be a included service.");
    XCTAssertTrue(service.cbService.includedServices.count == 1, "There should be a included service in corebluetooth.");
}

- (void)testRemoveServices {
    RBTMutableService *service = [[RBTMutableService alloc]initPrimaryServiceWithUUID:[CBUUID UUIDWithString:@"CF788729-958B-464C-A4A5-8DA53692FF45"]];
    
    [[self.peripheralModule addService:service] subscribeCompleted:^{
        NSLog(@"completed");
    }];
    
    // mock corebluetooth
    [self.peripheralModule.cbPeripheralManager.delegate peripheralManager:self.peripheralModule.cbPeripheralManager didAddService:service.cbService error:nil];
    
    XCTAssertTrue(self.peripheralModule.services.count == 1, "There should be a service.");
    XCTAssertTrue(service.isPublished == YES, "Service should be published.");
    
    [self.peripheralModule removeService:service];
    
    XCTAssertTrue(self.peripheralModule.services.count == 0, "There should not be a service.");
    XCTAssertTrue(service.isPublished == NO, "Service should not be published.");
}

- (void)testRemoveServicesWithIncludedService {
    RBTMutableService *service = [[RBTMutableService alloc]initPrimaryServiceWithUUID:[CBUUID UUIDWithString:@"DF788729-958B-464C-A4A5-8DA53692FF45"]];
    RBTMutableService *includedService = [[RBTMutableService alloc]initWithUUID:[CBUUID UUIDWithString:@"EF788729-958B-464C-A4A5-8DA53692FF45"] primary:NO];
    [service addIncludedService:includedService];
    
    XCTAssertTrue(service.includedServices.count == 1, "There should be a included service.");
    XCTAssertTrue(service.cbService.includedServices.count == 1, "There should be a included service in corebluetooth.");
    
    [service removeIncludedService:includedService];
    
    XCTAssertTrue(service.includedServices.count == 0, "There should not be a included service.");
    XCTAssertTrue(service.cbService.includedServices.count == 0, "There should not be a included service in corebluetooth.");
}


@end
