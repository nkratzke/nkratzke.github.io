//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//


//
// Unit test 3: FA7 Characerteristics hinzufügen und entfernen
//

#import <XCTest/XCTest.h>
#import "RBTPeripheralModule.h"
#import "RBTMutableService.h"
#import "RBTMutableCharacteristic.h"


@interface RBTUnitTest3 : XCTestCase

@end

@implementation RBTUnitTest3

- (void)setUp {
    [super setUp];
}

- (void)tearDown {
    [super tearDown];
}

- (void)testAddCharacteristic {
    RBTMutableService *service = [[RBTMutableService alloc]initPrimaryServiceWithUUID:[CBUUID UUIDWithString:@"A7357F53-239C-4248-8D6A-B34719DE0879"]];
    RBTMutableCharacteristic *characteristic = [[RBTMutableCharacteristic alloc]initWithUUID:[CBUUID UUIDWithString:@"B7357F53-239C-4248-8D6A-B34719DE0879"] properties:CBCharacteristicPropertyRead value:nil permissions:CBAttributePermissionsReadable];
    
    [service addCharacteristic:characteristic];
    
    XCTAssertTrue(service.characteristics.count == 1, "There should be a characteristic.");
    XCTAssertTrue(service.cbService.characteristics.count == 1, "There should be a characteristic in core bluetooth.");
}

- (void)testPublishedCharacteristic {
    RBTPeripheralModule *peripheralModule = [[RBTPeripheralModule alloc]init];
    RBTMutableService *service = [[RBTMutableService alloc]initPrimaryServiceWithUUID:[CBUUID UUIDWithString:@"A7357F53-239C-4248-8D6A-B34719DE0879"]];
    RBTMutableCharacteristic *characteristic = [[RBTMutableCharacteristic alloc]initWithUUID:[CBUUID UUIDWithString:@"B7357F53-239C-4248-8D6A-B34719DE0879"] properties:CBCharacteristicPropertyRead value:nil permissions:CBAttributePermissionsReadable];
    
    [service addCharacteristic:characteristic];
    
    XCTAssertTrue(service.characteristics.count == 1, "There should be a characteristic.");
    
    [[peripheralModule addService:service] subscribeCompleted:^{
        NSLog(@"completed");
    }];
    
    // mock corebluetooth
    [peripheralModule.cbPeripheralManager.delegate peripheralManager:peripheralModule.cbPeripheralManager didAddService:service.cbService error:nil];
    
    XCTAssertTrue(peripheralModule.services.count == 1, "There should be a service.");
    XCTAssertTrue(characteristic.isPublished == YES, "Service should be published.");
}

- (void)testRemoveCharacteristic {
    RBTMutableService *service = [[RBTMutableService alloc]initPrimaryServiceWithUUID:[CBUUID UUIDWithString:@"A7357F53-239C-4248-8D6A-B34719DE0879"]];
    RBTMutableCharacteristic *characteristic = [[RBTMutableCharacteristic alloc]initWithUUID:[CBUUID UUIDWithString:@"B7357F53-239C-4248-8D6A-B34719DE0879"] properties:CBCharacteristicPropertyRead value:nil permissions:CBAttributePermissionsReadable];
    
    [service addCharacteristic:characteristic];
    
    XCTAssertTrue(service.characteristics.count == 1, "There should be a characteristic.");
    XCTAssertTrue(service.cbService.characteristics.count == 1, "There should be a characteristic in core bluetooth.");
    
    [service removeCharacteristic:characteristic];
    
    XCTAssertTrue(service.characteristics.count == 0, "There should not be a characteristic.");
    XCTAssertTrue(service.cbService.characteristics.count == 0, "There should not be a characteristic in core bluetooth.");
}

@end
