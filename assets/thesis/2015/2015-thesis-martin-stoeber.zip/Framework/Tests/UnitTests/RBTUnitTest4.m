//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//


//
// Unit test 4: FA8 Descriptors hinzufügen und entfernen
//

#import <XCTest/XCTest.h>
#import "RBTPeripheralModule.h"
#import "RBTMutableService.h"
#import "RBTMutableCharacteristic.h"
#import "RBTMutableDescriptor.h"

@interface RBTUnitTest4 : XCTestCase

@end

@implementation RBTUnitTest4

- (void)setUp {
    [super setUp];
}

- (void)tearDown {
    [super tearDown];
}


- (void)testAddDescriptor {
    RBTMutableCharacteristic *characteristic = [[RBTMutableCharacteristic alloc]initWithUUID:[CBUUID UUIDWithString:@"B1357F53-239C-4248-8D6A-B34719DE0879"] properties:CBCharacteristicPropertyRead value:nil permissions:CBAttributePermissionsReadable];
    RBTMutableDescriptor *descriptor = [[RBTMutableDescriptor alloc]initWithUUID:[CBUUID UUIDWithString: CBUUIDCharacteristicUserDescriptionString] value:@"testDescriptor"];
    
    [characteristic addDescriptor:descriptor];

    XCTAssertTrue(characteristic.descriptors.count == 1, "There should be a descriptor.");
    XCTAssertTrue(characteristic.cbCharacteristic.descriptors.count == 1, "There should be a descriptor in core bluetooth.");
}


- (void)testPublishedDescriptor {
    RBTPeripheralModule *peripheralModule = [[RBTPeripheralModule alloc]init];
    RBTMutableService *service = [[RBTMutableService alloc]initPrimaryServiceWithUUID:[CBUUID UUIDWithString:@"A1357F53-239C-4248-8D6A-B34719DE0879"]];
    RBTMutableCharacteristic *characteristic = [[RBTMutableCharacteristic alloc]initWithUUID:[CBUUID UUIDWithString:@"B1357F53-239C-4248-8D6A-B34719DE0879"] properties:CBCharacteristicPropertyRead value:nil permissions:CBAttributePermissionsReadable];
    RBTMutableDescriptor *descriptor = [[RBTMutableDescriptor alloc]initWithUUID:[CBUUID UUIDWithString: CBUUIDCharacteristicUserDescriptionString] value:@"testDescriptor"];
    
    [characteristic addDescriptor:descriptor];
    [service addCharacteristic:characteristic];
    
    XCTAssertTrue(service.characteristics.count == 1, "There should be a characteristic.");
    XCTAssertTrue(characteristic.descriptors.count == 1, "There should be a descriptor.");
    
    [[peripheralModule addService:service] subscribeCompleted:^{
        NSLog(@"completed");
    }];
    
    // mock corebluetooth
    [peripheralModule.cbPeripheralManager.delegate peripheralManager:peripheralModule.cbPeripheralManager didAddService:service.cbService error:nil];
    
    XCTAssertTrue(peripheralModule.services.count == 1, "There should be a service.");
    XCTAssertTrue(characteristic.isPublished == YES, "Characteristic should be published.");
    XCTAssertTrue(descriptor.isPublished == YES, "Descriptor should be published.");
}

- (void)testRemoveDescriptor {
    RBTMutableCharacteristic *characteristic = [[RBTMutableCharacteristic alloc]initWithUUID:[CBUUID UUIDWithString:@"B1357F53-239C-4248-8D6A-B34719DE0879"] properties:CBCharacteristicPropertyRead value:nil permissions:CBAttributePermissionsReadable];
    RBTMutableDescriptor *descriptor = [[RBTMutableDescriptor alloc]initWithUUID:[CBUUID UUIDWithString: CBUUIDCharacteristicUserDescriptionString] value:@"testDescriptor"];
    
    [characteristic addDescriptor:descriptor];
    
    XCTAssertTrue(characteristic.descriptors.count == 1, "There should be a descriptor.");
    XCTAssertTrue(characteristic.cbCharacteristic.descriptors.count == 1, "There should be a descriptor in core bluetooth.");
    
    [characteristic removeDescriptor:descriptor];
    
    XCTAssertTrue(characteristic.descriptors.count == 0, "There should not be a descriptor.");
    XCTAssertTrue(characteristic.cbCharacteristic.descriptors.count == 0, "There should not be a descriptor in core bluetooth.");
}

@end
