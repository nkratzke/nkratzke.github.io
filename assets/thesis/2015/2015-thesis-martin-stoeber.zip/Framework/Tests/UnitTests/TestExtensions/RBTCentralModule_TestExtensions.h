//
//  Created by Martin Stöber on 11.02.15.
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "RBTCentralModule.h"
#import <objc/runtime.h>

@interface RBTCentralModule (TestExtensions)

// only overwrite access rights
@property(nonatomic) CBCentralManager *cbCentralManager;

// only overwrite access rights
- (NSArray *)wrapPeripherals:(NSArray *)cbPeripherals;

@end

#pragma GCC diagnostic ignored "-Wincomplete-implementation"
@implementation RBTCentralModule (TestExtensions)

-(void)setCbCentralManager:(CBCentralManager *)manager {
    objc_setAssociatedObject(self, @selector(cbCentralManager), manager, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

@end
