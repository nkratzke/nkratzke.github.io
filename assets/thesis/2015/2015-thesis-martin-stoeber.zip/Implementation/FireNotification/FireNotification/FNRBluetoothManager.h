//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ReactiveBluetoothLE/ReactiveBluetoothLE.h>


typedef NS_ENUM(NSUInteger, FNRBluetoothConnectionState) {
    FNRBluetoothConnectionStateDisconnected,
    FNRBluetoothConnectionStateConnecting,
    FNRBluetoothConnectionStateConnected
};

@interface FNRBluetoothManager : NSObject

/// connection state to the sender
@property(nonatomic, readonly) FNRBluetoothConnectionState connectionState;

/// message of last notification
@property(nonatomic, readonly) NSString *message;

/// date of last notification
@property(nonatomic, readonly) NSDate *notifiactionDate;


/// trigger download floor plan; completes when finished with UIImage
- (RACSignal *)downloadFloorPlan;

/// measured distance every 2 seconds
- (RACSignal *)updateDistance;

/// stop updating the distance
- (void)stopUpdateDistance;

/// stop download the floor plan; unssubscribe from chracteristic
- (void)stopDownloadFloorPlan;
@end
