//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "FNRBluetoothManager.h"
#import "SharedUUIDs.h"
#import <ReactiveBluetoothLE/RBTPeripheral+Beacon.h>

@interface FNRBluetoothManager ()

@property(nonatomic) RBTCentralModule *centralModule;

@property(nonatomic) NSString *message;
@property(nonatomic) NSDate *notifiactionDate;

@property(nonatomic) RBTPeripheral *senderPeripheral;

@property(nonatomic) RBTService *notificationService;
@property(nonatomic) RBTService *dataService;

@property(nonatomic) RBTCharacteristic *notificatinCharacteristic;
@property(nonatomic) RBTCharacteristic *messageCharacteristic;
@property(nonatomic) RBTCharacteristic *floorPictureCharacteristic;

@property(nonatomic) RACDisposable *registerNotificationDisposable;

@property(nonatomic) FNRBluetoothConnectionState connectionState;

@property(nonatomic) NSTimer *distanceTimer;
@property(nonatomic) RACSubject *distanceSubject;

@property(nonatomic) NSMutableData *image;

@end


@implementation FNRBluetoothManager

- (instancetype)init {
    self = [super init];
    if (self) {
        _centralModule = [[RBTCentralModule alloc] init];
        [self connect];
    }
    return self;
}


#pragma mark - connection

- (void)connect {
    self.connectionState = FNRBluetoothConnectionStateConnecting;

    @weakify(self)
    [[self.centralModule.bluetoothState take:1] subscribeNext:^(NSNumber *state) {
        @strongify(self)
        // Bluetooth ready?
        if (state.integerValue == 5) {
            [[self.centralModule scanForPeripheralsWithServices:@[[CBUUID UUIDWithString:NOTIFICATION_SERVICE_UUID], [CBUUID UUIDWithString:DATA_SERVICE_UUID]] forTimeinterval:0 withDuplicates:YES maxRSSI:nil] subscribeNext:^(RBTPeripheral *peripheral) {
                @strongify(self)
                if (self.senderPeripheral != peripheral) {
                    self.senderPeripheral = peripheral;
                    [self.centralModule stopScan];

                    [[peripheral connect] subscribeCompleted:^{
                        @strongify(self)
                        [self discoverServices];
                    }];
                }
            }];

        } else {
            //bluetooth not enabled / insufficent permissons
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Bluetooth Error!"
                                                            message:@"Bitte stelllen Sie sicher, dass Bluetooth aktiviert ist."
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
            [alert show];
        }
    }];

}

- (void)discoverServices {
    @weakify(self)
    [[self.senderPeripheral discoverServicesWithUUIDs:@[[CBUUID UUIDWithString:NOTIFICATION_SERVICE_UUID], [CBUUID UUIDWithString:DATA_SERVICE_UUID]]] subscribeError:^(NSError *error) {
        @strongify(self)
        [self cleanup];
        [self connect];
    } completed:^{
        @strongify(self)
        self.notificationService = [self.senderPeripheral serviceWithUUUID:[CBUUID UUIDWithString:NOTIFICATION_SERVICE_UUID]];
        self.dataService = [self.senderPeripheral serviceWithUUUID:[CBUUID UUIDWithString:DATA_SERVICE_UUID]];
        [self discoverCharacteristics];
    }];
}

- (void)discoverCharacteristics {
    // check if services discovered
    if (self.notificationService && self.dataService) {
        RACSignal *notificationCharacteristicsDiscovered = [self.notificationService discoverCharacteristicsWithUUIDs:@[[CBUUID UUIDWithString:NOTIFICATION_CHARACTERISTIC_UUID]]];
        RACSignal *dataServiceDiscovered = [self.dataService discoverCharacteristicsWithUUIDs:@[[CBUUID UUIDWithString:DATA_TEXT_CHARACTERISTIC_UUID], [CBUUID UUIDWithString:DATA_FLOOR_CHARACTERISTIC_UUID]]];

        @weakify(self)
        // completes if all characteristics
        [[RACSignal combineLatest:@[notificationCharacteristicsDiscovered, dataServiceDiscovered]] subscribeError:^(NSError *error) {
            @strongify(self)
            [self cleanup];
            [self connect];
        } completed:^{
            @strongify(self)
            self.notificatinCharacteristic = [self.notificationService characteristicWithUUUID:[CBUUID UUIDWithString:NOTIFICATION_CHARACTERISTIC_UUID]];
            self.messageCharacteristic = [self.dataService characteristicWithUUUID:[CBUUID UUIDWithString:DATA_TEXT_CHARACTERISTIC_UUID]];
            self.floorPictureCharacteristic = [self.dataService characteristicWithUUUID:[CBUUID UUIDWithString:DATA_FLOOR_CHARACTERISTIC_UUID]];
            // check if characteristics valid
            if (self.notificatinCharacteristic && self.messageCharacteristic && self.floorPictureCharacteristic) {
                [self registerNotification];
            } else {
                [self cleanup];
                [self connect];
            }
        }];
    } else {
        [self cleanup];
        [self connect];
    }
}

- (void)registerNotification {
    [self.notificatinCharacteristic setNotifying:YES];

    //check for notification
    @weakify(self)
    self.registerNotificationDisposable = [[self.notificatinCharacteristic valueSignal] subscribeNext:^(NSData *data) {
        @strongify(self)
        self.connectionState = FNRBluetoothConnectionStateConnected;

        char status;
        [data getBytes:&status length:sizeof(char)];

        // notification active
        if (status == 1) {
            self.notifiactionDate = [NSDate date];

            [[self.messageCharacteristic readValue] subscribeError:^(NSError *error) {
                self.message = @"NACHRICHT NICHT VERFÜGBAR!";
                [self showNotification];
            } completed:^{
                self.message = [[NSString alloc] initWithData:self.messageCharacteristic.value
                                                     encoding:NSUTF8StringEncoding];
                [self showNotification];
            }];
        }

    }];

    // handle connection error / reconnect
    [self.senderPeripheral.connectionState subscribeNext:^(NSNumber *state) {
        // if disconnected try to connect again
        if (state.integerValue == 0) {
            [self cleanup];
            [self connect];
        }
    }];
}

- (void)cleanup {
    // reset
    self.connectionState = FNRBluetoothConnectionStateDisconnected;
    self.senderPeripheral = nil;
    self.notificationService = nil;
    self.dataService = nil;
    self.floorPictureCharacteristic = nil;
    self.messageCharacteristic = nil;
    self.notificatinCharacteristic = nil;
    [self.registerNotificationDisposable dispose];
}

#pragma mark - notification data

- (void)showNotification {
    UILocalNotification *notification = [[UILocalNotification alloc] init];
    notification.alertBody = [NSString stringWithFormat:@"Feueralarm!"];
    notification.soundName = UILocalNotificationDefaultSoundName;
    [[UIApplication sharedApplication] scheduleLocalNotification:notification];
}

- (RACSignal *)downloadFloorPlan {
    self.image = [NSMutableData data];

    @weakify(self)
    RACSignal *downloadSignal = [RACSignal createSignal:^RACDisposable *(id <RACSubscriber> subscriber) {
        __block RACDisposable *valueDisposable;
        @strongify(self)
        [[self.floorPictureCharacteristic setNotifyingStatus:YES] subscribeError:^(NSError *error) {
            [subscriber sendError:error];
        }];

        valueDisposable = [[self.floorPictureCharacteristic.valueSignal skip:1] subscribeNext:^(NSData *data) {
            @strongify(self)

            uint8_t databytes[20];
            [data getBytes:&databytes length:sizeof(databytes)];

            for (int i = 0; i < 20; i++) {
                if (databytes[i] == 0xFF && databytes[i + 1] == 0xD9) { // check EOF of jpg
                    [self.image appendBytes:(databytes + i) length:2];
                    [self stopDownloadFloorPlan];
                    // send image
                    [subscriber sendNext:self.image];
                    [subscriber sendCompleted];
                    break;
                } else {
                    // add new bytes to image
                    [self.image appendBytes:(databytes + i) length:1];
                }
            }

        }];

        // cancel subscription on premature close
        return [RACDisposable disposableWithBlock:^{
            [valueDisposable dispose];
        }];
    }];
    return downloadSignal;
}

- (void)stopDownloadFloorPlan {
    [[self.floorPictureCharacteristic setNotifyingStatus:NO] subscribeError:^(NSError *error) {
        NSLog(@"Couldn't unsubscribe from image");
    }];
}

- (RACSignal *)updateDistance {
    if (!self.distanceSubject) {
        self.distanceSubject = [RACSubject subject];
    }

    // timer to update ui
    self.distanceTimer = [NSTimer timerWithTimeInterval:2
                                                 target:self
                                               selector:@selector(calculateDistance:)
                                               userInfo:nil
                                                repeats:YES];
    [self.distanceTimer fire];
    [[NSRunLoop mainRunLoop] addTimer:self.distanceTimer forMode:NSRunLoopCommonModes];

    return self.distanceSubject;
}

- (void)stopUpdateDistance {
    [self.distanceTimer invalidate];
    self.distanceTimer = nil;
}

- (void)calculateDistance:(NSTimer *)timer {
    [self.distanceSubject sendNext:self.senderPeripheral.calculateDistance];
};


@end