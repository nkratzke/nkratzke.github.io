//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "FNRConnectionViewController.h"


@interface FNRConnectionViewController ()

@property(weak, nonatomic) IBOutlet UILabel *statusLabel;
@property(weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;

@end


@implementation FNRConnectionViewController

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];

    // update ui
    [RACObserve(self.bluetoothManager, connectionState) subscribeNext:^(NSNumber *state) {
        switch (state.integerValue) {
            case FNRBluetoothConnectionStateConnected:
                self.statusLabel.text = @"Verbunden";
                self.statusLabel.textColor = [UIColor greenColor];
                [self.activityIndicator stopAnimating];
                break;
            case FNRBluetoothConnectionStateConnecting:
                self.statusLabel.text = @"Verbinde...";
                self.statusLabel.textColor = [UIColor yellowColor];
                [self.activityIndicator startAnimating];
                break;
            case FNRBluetoothConnectionStateDisconnected:
            default:
                self.statusLabel.text = @"Nicht Verbunden";
                self.statusLabel.textColor = [UIColor redColor];
                [self.activityIndicator stopAnimating];
                break;
        }
    }];
}


@end
