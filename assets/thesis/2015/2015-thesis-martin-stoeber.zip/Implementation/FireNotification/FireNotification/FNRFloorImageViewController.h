//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FNRBluetoothManager.h"


@interface FNRFloorImageViewController : UIViewController

@property FNRBluetoothManager *bluetoothManager;

@end
