//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "FNRFloorImageViewController.h"


@interface FNRFloorImageViewController ()

@property(weak, nonatomic) IBOutlet UIImageView *floorImageView;
@property(weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property(weak, nonatomic) IBOutlet UILabel *errorLabel;
@property(weak, nonatomic) IBOutlet UIButton *backButton;

@end


@implementation FNRFloorImageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.activityIndicator startAnimating];

    self.backButton.layer.cornerRadius = 5.0;
    self.backButton.layer.masksToBounds = YES;
    self.backButton.layer.borderWidth = 1.5f;
    self.backButton.layer.borderColor = [[UIColor whiteColor] CGColor];

    @weakify(self)
    [[self.bluetoothManager downloadFloorPlan] subscribeNext:^(NSData *floorimageData) {
        @strongify(self)
        // show image
        self.floorImageView.image = [UIImage imageWithData:floorimageData];
        [self.activityIndicator stopAnimating];
    } error:^(NSError *error) {
        @strongify(self)
        [self.activityIndicator stopAnimating];
        self.errorLabel.hidden = NO;
    }];
}


- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [self.bluetoothManager stopDownloadFloorPlan];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)closeView:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
