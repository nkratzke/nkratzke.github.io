//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "FNRNotificationViewController.h"
#import "FNRFloorImageViewController.h"
#import "AppDelegate.h"


@interface FNRNotificationViewController ()

@property(weak, nonatomic) IBOutlet UIButton *callHelpButton;
@property(weak, nonatomic) IBOutlet UIButton *showFloorButton;
@property(weak, nonatomic) IBOutlet UIButton *dismissButton;
@property(weak, nonatomic) IBOutlet UILabel *dateLabel;
@property(weak, nonatomic) IBOutlet UILabel *distanceLabel;
@property(weak, nonatomic) IBOutlet UITextView *messageTextView;

@end


@implementation FNRNotificationViewController

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];

    self.callHelpButton.layer.cornerRadius = 5.0;
    self.callHelpButton.layer.masksToBounds = YES;
    self.showFloorButton.layer.cornerRadius = 5.0;
    self.showFloorButton.layer.masksToBounds = YES;
    self.dismissButton.layer.cornerRadius = 5.0;
    self.dismissButton.layer.masksToBounds = YES;
    self.dismissButton.layer.borderWidth = 1.5f;
    self.dismissButton.layer.borderColor = [[UIColor whiteColor] CGColor];

    self.messageTextView.text = [NSString stringWithString:self.bluetoothManager.message];
    self.messageTextView.textAlignment = NSTextAlignmentCenter;
    self.messageTextView.textColor = [UIColor whiteColor];
    self.messageTextView.font = [UIFont fontWithName:@"Helvetica Neue" size:15.0f];

    // date label
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"dd.MM.yyyy hh:mm"];
    self.dateLabel.text = [formatter stringFromDate:self.bluetoothManager.notifiactionDate];

    // distance label
    [[self.bluetoothManager updateDistance] subscribeNext:^(NSNumber *distance) {
        self.distanceLabel.text = [NSString stringWithFormat:@"ca. %.1f m", distance.floatValue];
    }];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [self.bluetoothManager stopUpdateDistance];
}


#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // show floor plan
    if ([[segue identifier] isEqualToString:@"FloorImageSegue"]) {
        FNRFloorImageViewController *floorImageViewController = (FNRFloorImageViewController *) [segue destinationViewController];
        floorImageViewController.bluetoothManager = self.bluetoothManager;
    }
}


#pragma mark - Buttons

- (IBAction)callHelp:(id)sender {
    // open tel app
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel:0"]]];
}

- (IBAction)dismissMessage:(id)sender {
    // show connectionVC again
    AppDelegate *appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    appDelegate.window.rootViewController = appDelegate.connectionViewController;
    [appDelegate.window makeKeyAndVisible];
}


@end
