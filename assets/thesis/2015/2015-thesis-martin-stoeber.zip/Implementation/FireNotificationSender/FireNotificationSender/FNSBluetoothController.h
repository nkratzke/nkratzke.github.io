//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface FNSBluetoothController : NSObject

// true if bluetooth device is ready
@property(nonatomic, readonly) BOOL bluetoothReady;

// send the notification
- (void)sendNotification;

// set the notification text
- (void)updateTextMessage:(NSString *)text;

/// the floor image
- (void)updateImage:(UIImage *)image;


@end
