//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "FNSBluetoothController.h"
#import "ReactiveBluetoothLE.h"
#import "SharedUUIDs.h"

@interface FNSBluetoothController ()

@property(nonatomic) BOOL bluetoothReady;

@property(nonatomic) RBTPeripheralModule *peripheral;

@property(nonatomic) RBTMutableService *notificationService;
@property(nonatomic) RBTMutableService *dataService;

@property(nonatomic) RBTMutableCharacteristic *notificationState;
@property(nonatomic) RBTMutableCharacteristic *notificationText;
@property(nonatomic) RBTMutableCharacteristic *floorPicture;

@property(nonatomic) BOOL shouldSendImage;
@property(nonatomic) NSData *imagedata;
@property(nonatomic) NSInteger sendIndex;

@end


@implementation FNSBluetoothController

- (instancetype)init {
    self = [super init];
    if (self) {
        self.shouldSendImage = NO;

        // init peripheral + services + characteristics
        _peripheral = [[RBTPeripheralModule alloc] init];

        _notificationService = [[RBTMutableService alloc] initPrimaryServiceWithUUID:[CBUUID UUIDWithString:NOTIFICATION_SERVICE_UUID]];
        _dataService = [[RBTMutableService alloc] initPrimaryServiceWithUUID:[CBUUID UUIDWithString:DATA_SERVICE_UUID]];

        _notificationState = [[RBTMutableCharacteristic alloc] initWithUUID:[CBUUID UUIDWithString:NOTIFICATION_CHARACTERISTIC_UUID]
                                                                 properties:(CBCharacteristicPropertyRead | CBCharacteristicPropertyIndicate | CBCharacteristicPropertyNotify)
                                                                      value:nil
                                                                permissions:CBAttributePermissionsReadable];

        _notificationText = [[RBTMutableCharacteristic alloc] initWithUUID:[CBUUID UUIDWithString:DATA_TEXT_CHARACTERISTIC_UUID]
                                                                properties:(CBCharacteristicPropertyRead)
                                                                     value:nil
                                                               permissions:CBAttributePermissionsReadable];

        _floorPicture = [[RBTMutableCharacteristic alloc] initWithUUID:[CBUUID UUIDWithString:DATA_FLOOR_CHARACTERISTIC_UUID]
                                                            properties:(CBCharacteristicPropertyRead | CBCharacteristicPropertyIndicate | CBCharacteristicPropertyNotify)
                                                                 value:nil
                                                           permissions:CBAttributePermissionsReadable];
        _bluetoothReady = NO;

        [self setupController];
    }
    return self;
}

- (void)setupController {

    @weakify(self)
    [self.peripheral.peripheralState subscribeNext:^(NSNumber *state) {
        @strongify(self)
        if (state.integerValue == 5) {
            self.bluetoothReady = YES;

            [self.notificationService addCharacteristic:self.notificationState];
            [[self.peripheral addService:self.notificationService] subscribeCompleted:^{
                @strongify(self)
                uint8_t initState = 0;
                self.notificationState.value = [NSData dataWithBytes:&initState length:(sizeof(initState))];
                [self.peripheral startAdvertising];
            }];
            [self.dataService addCharacteristic:self.notificationText];
            [self.dataService addCharacteristic:self.floorPicture];
            [[self.peripheral addService:self.dataService] subscribeCompleted:^{
                self.notificationText.value = [@"" dataUsingEncoding:NSUTF8StringEncoding];
                self.floorPicture.value = [@"" dataUsingEncoding:NSUTF8StringEncoding];
            }];
        } else {
            self.bluetoothReady = NO;
        }
    }];

    // send image if subscribed to floor plan
    [[self.peripheral.didSubscribeToCharacteristicSignal filter:^BOOL(CBUUID *uuid) {
        @strongify(self)
        return ([uuid isEqual:self.floorPicture.UUID]);
    }] subscribeNext:^(id x) {
        @strongify(self)
        [self sendFloorPlan];
        self.shouldSendImage = YES;
    }];


    [self.peripheral.readyToUpdateSubscribersSignal subscribeNext:^(id x) {
        @strongify(self)
        if (self.shouldSendImage) {
            // send next chunk when ready again
            [self sendFloorPlan];
        }
    }];


}

- (void)sendNotification {
    char state = 1;
    self.notificationState.value = [NSData dataWithBytes:&state length:(sizeof(state))];
    if ([self.notificationState notifySubscribedCentrals]) {
        // success
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Gesendet!"
                                                        message:@"Der Alarm wurde gesendet."
                                                       delegate:self
                                              cancelButtonTitle:nil
                                              otherButtonTitles:@"OK", nil];
        [alert show];
    } else {
        // try to send until success
        [self sendNotification];
    }

    state = 0;
    self.notificationState.value = [NSData dataWithBytes:&state length:(sizeof(state))];
    [self.notificationState notifySubscribedCentrals];
}

- (void)updateTextMessage:(NSString *)text {
    self.notificationText.value = [text dataUsingEncoding:NSUTF8StringEncoding];
}

- (void)sendFloorPlan {
    static BOOL sendingEOF = NO;
    if (sendingEOF) {
        self.floorPicture.value = [NSData data];
        BOOL didSend = [self.floorPicture notifySubscribedCentrals];

        if (didSend) {
            sendingEOF = NO;
            self.sendIndex = 0;
            self.shouldSendImage = NO;
        }

        return;
    }

    if (self.sendIndex >= self.imagedata.length) {
        return;
    }

    BOOL didSend = YES;

    while (didSend) {
        // send size
        NSUInteger amountToSend = self.imagedata.length - self.sendIndex;
        if (amountToSend > 20) amountToSend = 20;

        // send
        self.floorPicture.value = [NSData dataWithBytes:self.imagedata.bytes + self.sendIndex length:amountToSend];
        didSend = [self.floorPicture notifySubscribedCentrals];

        if (!didSend) {
            // wait for bluetooth is ready agein
            return;
        }

        self.sendIndex += amountToSend;

        if (self.sendIndex >= self.imagedata.length) {
            sendingEOF = YES;
            self.floorPicture.value = [NSData data];
            BOOL eomSent = [self.floorPicture notifySubscribedCentrals];
            if (eomSent) {
                sendingEOF = NO;
                self.sendIndex = 0;
                self.shouldSendImage = NO;
            }

            return;
        }
    }
}

- (void)updateImage:(UIImage *)image {
    self.imagedata = UIImageJPEGRepresentation(image, 0.35);
}


@end
