//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import "ViewController.h"
#import "FNSBluetoothController.h"

@interface ViewController ()

@property(weak, nonatomic) IBOutlet UITextView *descriptionText;
@property(weak, nonatomic) IBOutlet UISegmentedControl *floorControl;
@property(weak, nonatomic) IBOutlet UIButton *sendButton;

@property(nonatomic) FNSBluetoothController *bluetoothController;

@property(nonatomic) NSInteger floorNumber;

@end



@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.sendButton.layer.cornerRadius = 5.0;
    self.sendButton.layer.masksToBounds = YES;

    self.bluetoothController = [[FNSBluetoothController alloc] init];
    self.floorNumber = 0;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)sendButtonClicked:(id)sender {
    if (self.bluetoothController.bluetoothReady) {
        [self.bluetoothController updateTextMessage:self.descriptionText.text];
        [self.bluetoothController sendNotification];
        [self.bluetoothController updateImage:[UIImage imageNamed:[NSString stringWithFormat:@"plan_%ld", (long)self.floorNumber]]];
    } else {
        // Bluetooth not enabled or supported
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Fehler!"
                                                        message:@"Bitte stellen Sie sicher, dass Bluetooth auf ihrem Gerät aktiviert ist und wiederholen sie den Vorgang!"
                                                       delegate:self
                                              cancelButtonTitle:nil
                                              otherButtonTitles:@"Ok", nil];
        [alert show];
    }
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    // hide keyboard
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }

    return YES;
}

- (IBAction)changeFloor:(id)sender {
    switch (self.floorControl.selectedSegmentIndex) {
        case 0:
            self.floorNumber = 0;
            break;
        case 1:
            self.floorNumber = 1;
            break;
        case 2:
            self.floorNumber = 2;
            break;
        default:
            break;
    }
}

@end
