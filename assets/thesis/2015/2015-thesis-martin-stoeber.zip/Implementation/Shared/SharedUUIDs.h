//
//  Created by Martin Stöber
//  Copyright (c) 2015 ma design GmbH & Co. KG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SharedUUIDs : NSObject

extern NSString *const NOTIFICATION_SERVICE_UUID;
extern NSString *const DATA_SERVICE_UUID;
extern NSString *const NOTIFICATION_CHARACTERISTIC_UUID;
extern NSString *const DATA_TEXT_CHARACTERISTIC_UUID;
extern NSString *const DATA_FLOOR_CHARACTERISTIC_UUID;

@end
