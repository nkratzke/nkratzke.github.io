- (RACSignal *)connect {
    [self.centralModule.cbCentralManager connectPeripheral:self.cbPeripheral options:nil];

    @weakify(self)
    RACSignal *connectSignal = [RACSignal createSignal:^RACDisposable *(id <RACSubscriber> subscriber) {
        @strongify(self)

        // Check for error
        RACDisposable *failDisposable =
                [[[self.centralModule.peripheralConnectionFailedSignal filter:^BOOL(RACTuple *failedTuple) {
                    @strongify(self)
                    RACTupleUnpack(CBCentralManager *manager, CBPeripheral *failedPeripheral) = failedTuple;
                    return (manager == self.centralModule.cbCentralManager && failedPeripheral == self.cbPeripheral);
                }] take:1] subscribeNext:^(RACTuple *failedTuple) {
                    NSError *error = [failedTuple third];
                    [subscriber sendError:error];
                }];

        // Check for success
        RACDisposable *successDisposable =
                [[[self.centralModule.peripheralConnectedSignal filter:^BOOL(RACTuple *connectedTuple) {
                    @strongify(self)
                    RACTupleUnpack(CBCentralManager *manager, CBPeripheral *connectedPeripheral) = connectedTuple;
                    return (manager == self.centralModule.cbCentralManager && connectedPeripheral == self.cbPeripheral);
                }] take:1] subscribeNext:^(RACTuple *connectedTuple) {
                    [subscriber sendCompleted];
                }];

        return [RACDisposable disposableWithBlock:^{
            // cleanup signals
            [failDisposable dispose];
            [successDisposable dispose];
        }];
    }];

    return connectSignal;
}