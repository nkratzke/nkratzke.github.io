@implementation RBTTest3
//[...]
- (void) setup {
    self.testTitle = @"Systemtest 3: FA04";
    self.testDescription = @"Connect and disconnect to a peripheral. 30sec timeout. Req: There should be a peripheral within range.";
    //[...]
}
- (void) execute {
    @weakify(self)
    [self.centralModule.bluetoothState subscribeNext:^(NSNumber *state) {
        @strongify(self)
        if (state.integerValue == 5) {
            [self.testLog sendNext:@"Bluetooth state changed to Ready"];
            [[[self.centralModule scanWithDuplicates:YES]take:1] subscribeNext:^(RBTPeripheral *peripheral) {
                @strongify(self)
                [self.testLog sendNext:@"Found peripheral"];
                self.peripheral = peripheral;
                [self.testLog sendNext:@"Try to connect to Peripheral"];
                [[self.peripheral connect] subscribeError:^(NSError *error) {
                    [self.testResult sendError:error];
                }completed:^{
                    @strongify(self)
                    [self.testLog sendNext:@"Connected successfully"];
                    //[...]
                }];
            }];
        }
    }];
}
- (void)reset {
    if (self.peripheral) {
        [self.peripheral disconnect];
    }
}
@end