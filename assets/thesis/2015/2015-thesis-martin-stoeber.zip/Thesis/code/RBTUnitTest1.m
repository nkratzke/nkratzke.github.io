-(void)testRetriveConnectedPeripherals {
    RBTCentralModule *centralModule = [[RBTCentralModule alloc]init];
    
    // mock CBPeripheral
    id peripheral = OCMClassMock([CBPeripheral class]);
    OCMStub([peripheral identifier]).andReturn([NSUUID UUID]);
    
    // fake call successful connect
    [centralModule.cbCentralManager.delegate centralManager:centralModule.cbCentralManager didConnectPeripheral:peripheral];
    
    // check retrieving
    XCTAssertTrue([[centralModule retrieveConnectedPeripherals] array].count == 1, "There should be one connected peripheral.");
    [peripheral verify];
}