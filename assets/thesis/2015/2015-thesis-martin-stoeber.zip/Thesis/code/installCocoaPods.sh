[sudo] gem install cocoapods
pod setup