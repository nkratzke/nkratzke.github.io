#!/bin/bash

echo creating admin user \"$1\"
java -jar jenkins-cli.jar groovy utils/create_admin_user.groovy $1 $2 $3

./login.sh $1 $2

echo setting smtp server details
java -jar jenkins-cli.jar groovy utils/set_smtp_details.groovy $3 $4 $5 $6 $7 $8

echo restart required to refresh smtp settings
echo restarting server...
java -jar jenkins-cli.jar restart
