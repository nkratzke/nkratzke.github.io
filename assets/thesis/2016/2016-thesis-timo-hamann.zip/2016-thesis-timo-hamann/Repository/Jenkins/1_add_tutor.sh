#!/bin/bash

java -jar jenkins-cli.jar groovy utils/create_users.groovy true $1
