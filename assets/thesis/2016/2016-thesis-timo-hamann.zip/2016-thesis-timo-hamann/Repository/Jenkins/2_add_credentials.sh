#!/bin/bash

echo adding credentials \"$3\"
java -jar jenkins-cli.jar groovy utils/add_global_credentials.groovy $1 $2 $3
