#!/bin/bash

IFS=";"
while read prefix file
do
	jobname="$prefix Muster"
	echo creating job \"$jobname\"
	java -jar jenkins-cli.jar create-job $jobname < $file
done < musterloesungen_jobs.csv
