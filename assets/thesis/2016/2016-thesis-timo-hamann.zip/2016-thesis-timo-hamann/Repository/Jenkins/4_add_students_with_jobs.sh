#!/bin/bash

emails=()
usernames=()

while read email
do
	emails=("${emails[@]}" "$email")
	usernames=("${usernames[@]}" "${email%@*}")
done < students.txt

java -jar jenkins-cli.jar groovy utils/create_users.groovy false ${emails[*]}

while IFS=";" read prefix file
do
	jobname="$prefix - ${usernames[0]}"
	echo creating job \"$jobname\"
	java -jar jenkins-cli.jar create-job "$jobname" < $file
done < student_jobs.csv

java -jar jenkins-cli.jar groovy utils/preparing_jobs_for_students.groovy ${usernames[*]}