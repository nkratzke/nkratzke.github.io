#!/bin/bash

java -jar jenkins-cli.jar groovy utils/set_jobs_enabled.groovy $1 $2
