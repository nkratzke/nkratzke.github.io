#!/bin/bash

java -jar jenkins-cli.jar login --username $1 --password $2
java -jar jenkins-cli.jar who-am-i
