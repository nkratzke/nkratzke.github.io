#!/bin/bash

java -jar jenkins-cli.jar logout
